<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/intranet/public/services/index.php");
$APPLICATION->SetTitle(GetMessage("SERVICES_TITLE"));
// if ($_GET["meeting_id"] == '1240') $APPLICATION->SetTitle("Бронирование cитуационного центра");
?><p>
<? $APPLICATION->IncludeComponent(
    "bitrix:intranet.reserve_meeting",
    "tempDan",
    Array(
        "COMPONENT_TEMPLATE" => "tempDan",
        "DATE_TIME_FORMAT" => "d.m.Y H:i:s",
        "IBLOCK_ID" => "14",
        "IBLOCK_TYPE" => "events",
        "NAME_TEMPLATE" => "",
        "PATH_TO_CONPANY_DEPARTMENT" => "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#",
        "PATH_TO_USER" => "/company/personal/user/#USER_ID#/",
        "PM_URL" => "/company/personal/messages/chat/#USER_ID#/",
        "SEF_MODE" => "N",
        "SET_NAVCHAIN" => "Y",
        "SET_TITLE" => "N",
        "SHOW_LOGIN" => "Y",
        "SHOW_YEAR" => "Y",
        "USERGROUPS_CLEAR" => array(0 => "1",),
        "USERGROUPS_MODIFY" => array(0 => "1",),
        "USERGROUPS_RESERVE" => array(0 => "1", 1 => "9", 2 => "10", 3 => "11", 4 => "12",),
        "VARIABLE_ALIASES" => array("meeting_id" => "meeting_id", "item_id" => "item_id", "page" => "page",),
        "WEEK_HOLIDAYS" => array(0 => "5", 1 => "6",)
    )
); ?>
    </p>
<?
$curID = $USER->GetID();
if ((CUser::GetByID($curID))->Fetch()['UF_POPUP_1'] == !1) {
    //$view=$_COOKIE["kaznaServicesPopup" . $curID];
    //if(empty($view)) {
    setcookie("kaznaServicesPopup" . $curID, "1", time() + 86400, "/", "vp.fsfk.local");
    include("../requests/popup1.php");
    //}
} ?>

<?
/*<p>
    <a href="/services/res_c.php"><?=GetMessage("SERVICES_LINK")?></a><br>
</p>*/
// $APPLICATION->SetTitle(GetMessage("SERVICES_TITLE"));
?>
    <br><? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php"); ?>
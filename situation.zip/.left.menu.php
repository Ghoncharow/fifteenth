<?
$aMenuLinks = Array(
	Array(
		"Электронные заявки", 
		"/services/requests/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Графики переговорных", 
		"/services/bron/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Отчет по переговорным", 
		"/services/bron/report.php", 
		Array(), 
		Array(), 
		"" 
	)
);
if ($_GET["meeting_id"] == '1240') $aMenuLinks[1] = Array(
	"Ситуационный центр", 
	"/services/bron/index.php?page=meeting&meeting_id=1240", 
	Array(), 
	Array(), 
	"" 
);
?>
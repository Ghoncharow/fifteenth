<?
$MESS["INTASK_C25T_FLOOR"] = "Floor";
$MESS["INTASK_C25T_PLACE"] = "Seats";
$MESS["INTASK_C25T_PHONE"] = "Phone";
$MESS["INTASK_C25T_PRIOR_WEEK"] = "Previous Week";
$MESS["INTASK_C25T_SET"] = "Set";
$MESS["INTASK_C25T_NEXT_WEEK"] = "Next Week";
$MESS["INTASK_C25T_D1"] = "Monday";
$MESS["INTASK_C25T_D2"] = "Tuesday";
$MESS["INTASK_C25T_D3"] = "Wednesday";
$MESS["INTASK_C25T_D4"] = "Thursday";
$MESS["INTASK_C25T_D5"] = "Friday";
$MESS["INTASK_C25T_D6"] = "Saturday";
$MESS["INTASK_C25T_D7"] = "Sunday";
$MESS["INTASK_C25T_TIME"] = "Time";
$MESS["INTASK_C25T_RESERVED_BY"] = "Booked by";
$MESS["INTASK_C25T_CLEAR_CONF"] = "The reservation will be canceled! Continue?";
$MESS["INTASK_C25T_EDIT"] = "Edit";
$MESS["INTASK_C25T_CLEAR"] = "Cancel Reservation";
$MESS["INTASK_C25T_DBL_CLICK"] = "Double-click to book the meeting room";
?>
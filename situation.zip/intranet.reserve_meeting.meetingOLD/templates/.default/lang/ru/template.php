<?
$MESS["INTASK_C25T_FLOOR"] = "Этаж";
$MESS["INTASK_C25T_PLACE"] = "Мест";
$MESS["INTASK_C25T_PHONE"] = "Телефон";
$MESS["INTASK_C25T_PRIOR_WEEK"] = "Предыдущая неделя";
$MESS["INTASK_C25T_SET"] = "Установить";
$MESS["INTASK_C25T_NEXT_WEEK"] = "Следующая неделя";
$MESS["INTASK_C25T_D1"] = "Понедельник";
$MESS["INTASK_C25T_D2"] = "Вторник";
$MESS["INTASK_C25T_D3"] = "Среда";
$MESS["INTASK_C25T_D4"] = "Четверг";
$MESS["INTASK_C25T_D5"] = "Пятница";
$MESS["INTASK_C25T_D6"] = "Суббота";
$MESS["INTASK_C25T_D7"] = "Воскресенье";
$MESS["INTASK_C25T_TIME"] = "Время";
$MESS["INTASK_C25T_RESERVED_BY"] = "Зарезервировал";
$MESS["INTASK_C25T_CLEAR_CONF"] = "Бронь будет снята! Продолжить?";
$MESS["INTASK_C25T_EDIT"] = "Изменить";
$MESS["INTASK_C25T_CLEAR"] = "Освободить";
$MESS["INTASK_C25T_EXPIRED_TIME"] = "Бронировать ситуационный центр необходимо заблаговременно";
$MESS["INTASK_C25T_DBL_CLICK"] = "Двойной щелчок левой кнопкой мыши для бронирования ситуационного центра";
?>
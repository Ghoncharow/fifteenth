<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<?
$APPLICATION->SetTitle("Бронирование cитуационного центра");
// echo '<script type="text/javascript">console.log('.json_encode($arResult).');</script>';

if (strlen($arResult["FatalError"]) > 0) {
    ?>
    <span class='errortext'><?= $arResult["FatalError"] ?></span><br/><br/>
    <?
}
else {
    if (strlen($arResult["ErrorMessage"]) > 0) {
        ?>
        <span class='errortext'><?= $arResult["ErrorMessage"] ?></span><br/><br/>
        <?
    }
    ?>


    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td align="left" valign="bottom"><a
                        href="<?= $arResult["PRIOR_WEEK_URI"] ?>">&lt;&lt; <?= GetMessage("INTASK_C25T_PRIOR_WEEK") ?></a>
            </td>
            <form method="GET" action="<?= $arResult["MEETING_URI"] ?>" name="meeting_date_select">
                <input type="hidden" name="<?= $arParams["PAGE_VAR"] ?>" value="meeting">
                <input type="hidden" name="<?= $arParams["MEETING_VAR"] ?>" value="<?= $arResult["MEETING"]["ID"] ?>">
                <td align="center"><?
                    $GLOBALS["APPLICATION"]->IncludeComponent(
                        'bitrix:main.calendar',
                        '',
                        array(
                            'SHOW_INPUT' => 'Y',
                            'FORM_NAME' => "meeting_date_select",
                            'INPUT_NAME' => "week_start",
                            'INPUT_VALUE' => $arResult["WEEK_START"],
                            'SHOW_TIME' => 'N',
                            'INPUT_ADDITIONAL_ATTR' => $strAdd,
                        ),
                        null,
                        array('HIDE_ICONS' => 'Y')
                    );
                    ?> &nbsp;<input type="submit" value="<?= GetMessage("INTASK_C25T_SET") ?>"></td>
            </form>
            <td align="right" valign="bottom"><a
                        href="<?= $arResult["NEXT_WEEK_URI"] ?>"><?= GetMessage("INTASK_C25T_NEXT_WEEK") ?> &gt;&gt;</a>
            </td>
        </tr>
    </table>
    <br>

    <table cellpadding="0" cellspacing="0" border="0" width="100%" class="intask-main data-table">
        <thead>
        <tr class="intask-row">
            <th class="intask-cell" align="center" width="0%">&nbsp;</th>
            <?
            $ar = array(GetMessage("INTASK_C25T_D1"), GetMessage("INTASK_C25T_D2"), GetMessage("INTASK_C25T_D3"), GetMessage("INTASK_C25T_D4"), GetMessage("INTASK_C25T_D5"), GetMessage("INTASK_C25T_D6"), GetMessage("INTASK_C25T_D7"));

            $time = new DateTime($arResult["WEEK_START"]);
            $curDOTW = $time->format('w') - 1;

            if (in_array($curDOTW, $arParams["WEEK_HOLIDAYS"]))
                $curDOTW = 0;

            for ($i = 0; $i < 7; $i++) {
                if (In_Array($i, $arParams["WEEK_HOLIDAYS"]))
                    continue;
                ?>
                <th class="intask-cell" align="center" width="<?= 100 / 5 ?>%"><?= $ar[$curDOTW] ?></th>
                <?
                $curDOTW++;
                if (in_array($curDOTW, $arParams["WEEK_HOLIDAYS"]) || $curDOTW > 7)
                    $curDOTW = 0;
            } ?>
            <?/*
            $ar = array(GetMessage("INTASK_C25T_D1"), GetMessage("INTASK_C25T_D2"), GetMessage("INTASK_C25T_D3"), GetMessage("INTASK_C25T_D4"), GetMessage("INTASK_C25T_D5"), GetMessage("INTASK_C25T_D6"), GetMessage("INTASK_C25T_D7"));
            ?>
            <?
            $curDOTW = date("N")*1;

            for ($i = 0; $i < 7; $i++){
                if (In_Array($i, $arParams["WEEK_HOLIDAYS"]))
                    continue;
                ?>
                <th class="intask-cell" align="center" width="<?= IntVal(100 / (7 - Count($arParams["WEEK_HOLIDAYS"]))) ?>%"><?= $ar[$i] ?></th>
            <?}*/
            ?>
        </tr>
        <tr class="intask-row">
            <th align="center" class="intask-cell"><?= GetMessage("INTASK_C25T_TIME") ?></th>
            <?//for ($i = 0; $i < 7; $i++){
            ?>
            <?//
            //            if (In_Array($i, $arParams["WEEK_HOLIDAYS"]))
            //                    continue;
            //
            ?>
            <!--                <th align="center" class="intask-cell">-->
            <?//= FormatDate($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), MkTime(0, 0, 0, $arResult["WEEK_START_ARRAY"]["m"], $arResult["WEEK_START_ARRAY"]["d"] + $i, $arResult["WEEK_START_ARRAY"]["Y"]))
            ?><!--</th>-->
            <?//}
            ?>

            <?
            $time = new DateTime($arResult["WEEK_START"]);
            $time->sub(new DateInterval("P1D"));
            $curDOTW = $time->format("w") * 1;
            for ($i = 0; $i < 5; $i++) {
                $skipDays = $curDOTW > 4 ? 3 : 1;
                $time->add(new DateInterval("P{$skipDays}D"));
                ?>
                <th align="center"
                    class="intask-cell"><?= $time->format("d") . "." . $time->format("m") . "." . $time->format("Y") ?></th>
                <?
                $curDOTW++;
                if ($curDOTW > 6)
                    $curDOTW = 0;
            }
            ?>
        </tr>
        </thead>
        <tbody>
        <?
        $time = new DateTime($arResult["WEEK_START"]);
        $time->sub(new DateInterval("P1D"));
        $curDOTW = $time->format("w") * 1;

        for ($i = $arResult["LIMITS"]["FROM"]; $i < $arResult["LIMITS"]["TO"]; $i++) {
            ?>
            <tr class="intask-row">
                <td class="intask-cell selected" nowrap><?= __RM_MkT($i) ?></td>
                <?
                $time = new DateTime($arResult["WEEK_START"]);
                $time->sub(new DateInterval("P1D"));
                $curDOTW = $time->format("w") * 1;
                for ($j = 1; $j <= 5; $j++) { // `
                    $time->add(new DateInterval("P1D"));
                    $currentDay = ($time == new DateTime(date("d.m.Y")));
                    $expiredDay = ($time < new DateTime(date("d.m.Y")));
                    $time->sub(new DateInterval("P1D"));

//                $skipDays = $curDOTW > 4 ? 3 : 1;
                    $skipDays = $curDOTW > 4 ? 3 : 1;
                    $time->add(new DateInterval("P{$skipDays}D"));
                    $curDOTW++;
                    if ($curDOTW > 6)
                        $curDOTW = 0;

                    if ($arResult["ITEMS_MATRIX"][$j][$i]) {
                        if ($i == 0 || !$arResult["ITEMS_MATRIX"][$j][$i - 1] || $arResult["ITEMS_MATRIX"][$j][$i - 1] != $arResult["ITEMS_MATRIX"][$j][$i]) {
                            $cnt = 0;
                            for ($k = $i; $k < 48; $k++) {
                                if ($arResult["ITEMS_MATRIX"][$j][$i] == $arResult["ITEMS_MATRIX"][$j][$k])
                                    $cnt++;
                                else
                                    break;
                            } ?>
                        <td class="intask-cell reserved<?= $currentDay ? ' current' : '' ?>" valign="top"
                            rowspan="<?= $cnt ?>">
                            <a href="<?= $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["VIEW_ITEM_URI"] ?>"><b><?= $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["NAME"] ?></b></a>
                            <br/>
                            (<?= $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["DATE_ACTIVE_FROM_TIME"] ?> -
                            <?= $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["DATE_ACTIVE_TO_TIME"] ?>)<br/>
                            <?= GetMessage("INTASK_C25T_RESERVED_BY") ?>:
                            <?
                            $APPLICATION->IncludeComponent("bitrix:main.user.link",
                                '',
                                array(
                                    "ID" => $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY"],
                                    "HTML_ID" => "reserve_meeting_meeting" . $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY"],
                                    "NAME" => htmlspecialcharsback($arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY_FIRST_NAME"]),
                                    "LAST_NAME" => htmlspecialcharsback($arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY_LAST_NAME"]),
                                    "SECOND_NAME" => htmlspecialcharsback($arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY_SECOND_NAME"]),
                                    "LOGIN" => htmlspecialcharsback($arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY_LOGIN"]),
                                    "USE_THUMBNAIL_LIST" => "N",
                                    "INLINE" => "Y",
                                    "PATH_TO_SONET_USER_PROFILE" => $arParams["~PATH_TO_USER"],
                                    "PATH_TO_SONET_MESSAGES_CHAT" => $arParams["~PM_URL"],
                                    "PATH_TO_VIDEO_CALL" => $arParams["~PATH_TO_VIDEO_CALL"],
                                    "PATH_TO_CONPANY_DEPARTMENT" => $arParams["~PATH_TO_CONPANY_DEPARTMENT"],
                                    "DATE_TIME_FORMAT" => $arParams["DATE_TIME_FORMAT"],
                                    "SHOW_YEAR" => $arParams["SHOW_YEAR"],
                                    "NAME_TEMPLATE" => $arParams["NAME_TEMPLATE_WO_NOBR"],
                                    "SHOW_LOGIN" => $arParams["SHOW_LOGIN"],
                                ),
                                false,
                                array("HIDE_ICONS" => "Y")
                            ); ?>
                            <br/>
                            <?
                            if (StrLen($arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["EDIT_ITEM_URI"]) > 0) { ?>
                                <br/>
                                <a href="<?= $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["EDIT_ITEM_URI"] ?>"><?= GetMessage("INTASK_C25T_EDIT") ?></a>
                            <? }
                            if (StrLen($arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CLEAR_URI"]) > 0) {
                                ?>
                                <?
                                $params = "&CREATED_BY_NAME={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CREATED_BY_NAME"]
                                }&DATE_ACTIVE_FROM_TIME={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["DATE_ACTIVE_FROM_TIME"]
                                }&DATE_ACTIVE_TO_TIME={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["DATE_ACTIVE_TO_TIME"]
                                }&NAME={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["NAME"]
                                }&PROPERTY_UF_OPTION_1_VALUE={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_1_VALUE"]
                                }&PROPERTY_UF_OPTION_2_VALUE={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_2_VALUE"]
                                }&PROPERTY_UF_OPTION_3_VALUE={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_3_VALUE"]
                                }&PROPERTY_PERIOD_TYPE_VALUE={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_PERIOD_TYPE"]
                                }&PROPERTY_EVENT_LENGTH={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_EVENT_LENGTH"]
                                }&DATE_ACTIVE_FROM={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["DATE_ACTIVE_FROM"]
                                }&DETAIL_TEXT={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["DETAIL_TEXT"]
                                }&PROPERTY_UF_RES_TYPE_VALUE={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_RES_TYPE_VALUE"]
                                }&PERSONS={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_PERSONS_VALUE"]
                                }&PROPERTY_UF_RESP_TEXT_VALUE={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_RESP_TEXT_VALUE"]
                                }
								";
                                /*&PROPERTY_UF_OPTION_3={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_3"]
                                }&PROPERTY_UF_OPTION_3={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_3"]
                                }&PROPERTY_UF_OPTION_3={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_3"]
                                }&PROPERTY_UF_OPTION_3={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_3"]
                                }&PROPERTY_UF_OPTION_3={$arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["PROPERTY_UF_OPTION_3"]
                                }"*/
                                ?>
                                <br/>
                                <a onclick="if(confirm('<?= GetMessage("INTASK_C25T_CLEAR_CONF") ?>'))window.location='<?= $arResult["ITEMS"][$arResult["ITEMS_MATRIX"][$j][$i]]["CLEAR_URI"] . pararms ?>';"
                                   href="javascript:void(0)"><?= GetMessage("INTASK_C25T_CLEAR") ?></a>
                            <? } ?>
                            </td><?
                        }
                    }
                    else { ?>
                    <td class="intask-cell notreserved<?= $currentDay ? ' current' : '' ?><?= $expiredDay ? ' expired' : '' ?>"
                        <?if(!$currentDay && !$expiredDay):?>
                            title="<?= GetMessage("INTASK_C25T_DBL_CLICK") ?>"
                            ondblclick="window.location='<?= CUtil::addslashes($arResult["CellClickUri"]) ?>start_date=<?= $time->format("d") . "." . $time->format("m") . "." . $time->format("Y") ?>&amp;start_time=<?
                            $h1 = IntVal($i / 2);
                            if ($h1 < 10) $h1 = "0" . $h1;
                            $i1 = ($i % 2 != 0 ? "30" : "00");
                            echo $h1 . ":" . $i1;?>'"
                        <?else:?>
                            title="<?= GetMessage("INTASK_C25T_EXPIRED_TIME") ?>"
                        <?endif;?>
                    >&nbsp;</td><?
                    }

                } ?>
            </tr>
        <? } ?>
        </tbody>
    </table>
    <br/>
    <?
}
CModule::IncludeModule("bizproc");
CModule::IncludeModule("iblock");
$arErrorsTmp = [];
if (isset($_GET['clear_id'])) {
    $curpath = GetPagePath();
    $arErrorsTmp = [];

    if ($_GET['clear_id'] > 0)
        $getDoc = CBPVirtualDocument::GetDocument($_GET['clear_id'] + 1);
    else
        var_dump(getDoc);

    try {
        CBPVirtualDocument::UpdateDocument($_GET['clear_id'] + 1, ["PROPERTY_DELETE" => 1]);
    } catch (Exception $exception) {
    }
    $arWorkflowTemplates = CBPDocument::GetWorkflowTemplatesForDocumentType(array("lists", "BizprocDocument", "iblock_34"));
    CBPDocument::StartWorkflow(
        23,
        array("lists", "BizprocDocument", $_GET['clear_id'] + 1),
        array_merge($arWorkflowParameters, array("TargetUser" => "user_" . intval($GLOBALS["USER"]->GetID()))),
        $arErrorsTmp
    );
    LocalRedirect("{$curpath}?page={$_GET['page']}&meeting_id={$_GET['meeting_id']}");
}
elseif (isset($_GET['create'])) {
    // create
//    $last = 0;
//    $arSelect = Array("ID", "NAME", "PROPERTY_SID");
//    $arFilter = Array("IBLOCK_ID" => 34, "ACTIVE_DATE" => "Y", "ACTIVE" => "Y");
//    $res = CIBlockElement::GetList(Array("SORT" => "ASC"), $arFilter, false, false, $arSelect);
//    while ($ob = $res->GetNextElement()) {
//        $arFields = $ob->GetFields();
//        $last = $arFields["ID"];
//    }
//    if ($last == 0) {
//        $last = -1;
//        $next = -1;
//    }//если нет ни одного инфоблока, то нет возможности получить последний ID.
//    else
//        $next = $last + 2;

    $lastItem = end($arResult['ITEMS']);
    // $lastItem["ID"]
    $maxID = -1;
    foreach ($arResult['ITEMS'] as $aritem) {
        if ($aritem["ID"] > $maxID) {
            $maxID = $aritem["ID"];
            $lastItem = $aritem;
        }
    }

    $startDate = $lastItem['DATE_ACTIVE_FROM_TIME'];
    $endDate = $lastItem['DATE_ACTIVE_TO_TIME'];

    $stmpStart = strtotime($startDate);
    $stmpEnd = strtotime($endDate);

    $stmpTemp = $stmpEnd - $stmpStart;
    $stmpTemp /= 60;
    //$stmpTemp = date("H:i", $stmpTemp);
    $ar = [
        "IBLOCK_ID" => "34",
        "NAME" => "Ознакомление о бронировании",
        "CREATED_BY" => "user_" . $GLOBALS["USER"]->GetID(),
        "PROPERTY_DATA" => $lastItem['DATE_ACTIVE_FROM'],
        "PROPERTY_ZAYAVITEL" => $lastItem['CREATED_BY_NAME'],
        "PROPERTY_DLITELNOST" => $stmpTemp,
        "PROPERTY_VREMYA_NACHALA" => $startDate,
        "PROPERTY_VREMYA_OKONCHANIYA" => $endDate,
        "PROPERTY_NAZVANIE_REZERVIROVANIYA" => $lastItem["NAME"],
        "PROPERTY_KOLICHESTVO_UCHASTNIKOV" => $lastItem['PROPERTY_UF_PERSONS_VALUE'],
        "PROPERTY_TIP_VSTRECHI" => $lastItem['PROPERTY_UF_RES_TYPE_VALUE'],
        "PROPERTY_OPISANIE" => $lastItem['DETAIL_TEXT'],
        "PROPERTY_POVTOR" => GetMessage("INTASK_C29T_REGULARITY_" . $lastItem['PROPERTY_PERIOD_TYPE_VALUE']),
        "PROPERTY_OPTSIYA_1" => $lastItem['PROPERTY_UF_OPTION_1_VALUE'],
        "PROPERTY_OPTSIYA_2" => $lastItem['PROPERTY_UF_OPTION_2_VALUE'],
        "PROPERTY_OPTSIYA_3" => $lastItem['PROPERTY_UF_OPTION_3_VALUE'],
        "PROPERTY_IMYA_PEREGOVORNOY" => $arResult["MEETING"]["NAME"],
        "PROPERTY_ID_PEREGOVORNOY" => $arResult["MEETING"]["ID"],
        "PROPERTY_SID" => $lastItem["ID"],/*-666,*/
        "PROPERTY_RESP" => $lastItem["PROPERTY_UF_RESP_TEXT_VALUE"],
        "PROPERTY_RESP_ID" => $lastItem["PROPERTY_UF_RESP_TEXT_VALUE"],
    ];

    $documentIdCreate = CBPVirtualDocument::CreateDocument(
        0, $ar
    );
    CBPVirtualDocument::UpdateDocument($documentIdCreate, [
        "PROPERTY_SID" => $lastItem["ID"],
        "PROPERTY_RESP" => $lastItem["PROPERTY_UF_RESP_TEXT_VALUE"],
    ]);

//    $arSelect = Array("ID", "NAME", "PROPERTY_UF_OPTION_1", "PROPERTY_SID", "PROPERTY_RESP"); // Указываем список параметров, которые будем использовать
//    $arFilter = Array("IBLOCK_ID" => 34, "ACTIVE_DATE" => "Y", "ACTIVE" => "Y"); // Указываем параметры фильтра, по которым будем выводить элементы
//    $res = CIBlockElement::GetList(Array("SORT" => "ASC"), $arFilter, false, false, $arSelect); // Вызов
//    $debugVar = [];
//    while ($ob = $res->GetNextElement()) {
//        $arFields = $ob->GetFields();
//        $debugVar = $arFields;
//        $last = $arFields["ID"];
//        //echo $last . " ";
//        //debug($arFields);
//
//    }
//    debug($debugVar);
//    var_dump($lastItem["PROPERTY_UF_RESP_TEXT_VALUE"]);
//
//
//    $updated = CBPVirtualDocument::UpdateDocument($documentIdCreate, [
//        "PROPERTY_SID" => $last,
//        "PROPERTY_RESP" => $lastItem["PROPERTY_UF_RESP_TEXT_VALUE"],
//
//    ]);
//    while ($ob = $res->GetNextElement()) {
//        $arFields = $ob->GetFields();
//        $debugVar = $arFields;
//        //last = $arFields["ID"];
//        //echo $last . " ";
//        //debug($arFields);
//
//    }
//    debug($debugVar);


    $arWorkflowTemplates = CBPDocument::GetWorkflowTemplatesForDocumentType(array("lists", "BizprocDocument", "iblock_34"));
    foreach ($arWorkflowTemplates as $arTemplate) {
        if ($arTemplate['AUTO_EXECUTE'] == 1) {
            $wfId = CBPDocument::StartWorkflow
            (
                $arTemplate['ID'],
                array("lists", "BizprocDocument", $documentIdCreate),
                array_merge($arWorkflowParameters, array("TargetUser" => "user_" . intval($GLOBALS["USER"]->GetID()))),
                $arErrorsTmp
            );
        }
    }


    LocalRedirect("{$curpath}?page={$_GET['page']}&meeting_id={$_GET['meeting_id']}");
}
elseif (isset($_GET['change'])) {
    // если меняем
//                    $checkedID = -1;
//                $documentId = [];
//                $arSelect = Array("ID", "NAME", "PROPERTY_SID", "PROPERTY_VREMYA_NACHALA", "PROPERTY_VREMYA_OKONCHANIYA", "PROPERTY_DATA"); // Указываем список параметров, которые будем использовать
//                $arFilter = Array("IBLOCK_ID"=>34, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y"); // Указываем параметры фильтра, по которым будем выводить элементы
//                $res = CIBlockElement::GetList(Array("SORT"=>"ASC"), $arFilter, false, false, $arSelect); // Вызов
//                while($ob = $res->GetNextElement())
//                {
//                    $arFields = $ob->GetFields();
//                    if($arFields["PROPERTY_VREMYA_NACHALA_VALUE"] == $arResult['Item']['StartTime'] &&
//                        $arFields["PROPERTY_VREMYA_OKONCHANIYA_VALUE"] ==  $stmp &&
//                        $arFields["PROPERTY_DATA_VALUE"] == $arResult['Item']['StartDate']){
//                    $checkedID = $arFields["ID"];
//                    }
//                    debug($arFields);
//
//                }
    $lastItem = $arResult['ITEMS'][$_GET['item_id']];
    $startDate = $lastItem['DATE_ACTIVE_FROM_TIME'];
    $endDate = $lastItem['DATE_ACTIVE_TO_TIME'];

    $stmpStart = strtotime($startDate);
    $stmpEnd = strtotime($endDate);

    $stmpTemp = $stmpEnd - $stmpStart;
    $stmpTemp /= 60;
//    $stmpTemp = date("H:i", $stmpTemp);
    debug($arResult['ITEMS']);

    if ($_GET['item_id'] > 0)
        $getDoc = CBPVirtualDocument::GetDocument($_GET['item_id'] + 1);
    else
        var_dump(getDoc);

    //LocalRedirect($p."&error=CheckedIDequals-1");

    //var_dump(getDoc);
    $arWorkflowTemplates = CBPDocument::GetWorkflowTemplatesForDocumentType(array("lists", "BizprocDocument", "iblock_34"));
    CBPDocument::StartWorkflow(
        23,
        array("lists", "BizprocDocument", $_GET['item_id'] + 1),
        array_merge($arWorkflowParameters, array("TargetUser" => "user_" . intval($GLOBALS["USER"]->GetID()))),
        $arErrorsTmp
    );
    if (count($arErrorsTmp) > 0) {
        foreach ($arErrorsTmp as $e)
            $errorMessage .= "[" . $e["code"] . "] " . $e["message"] . "";
        echo $errorMessage;
    }


    $updated = CBPVirtualDocument::UpdateDocument($_GET['item_id'] + 1, [
        "PROPERTY_DATA" => $lastItem['DATE_ACTIVE_FROM'],
        "PROPERTY_ZAYAVITEL" => $lastItem['CREATED_BY_NAME'],
        "PROPERTY_DLITELNOST" => $stmpTemp,
        "PROPERTY_VREMYA_NACHALA" => $startDate,
        "PROPERTY_VREMYA_OKONCHANIYA" => $endDate,
        "PROPERTY_NAZVANIE_REZERVIROVANIYA" => $lastItem["NAME"],
        "PROPERTY_KOLICHESTVO_UCHASTNIKOV" => $lastItem['PROPERTY_UF_PERSONS_VALUE'],
        "PROPERTY_TIP_VSTRECHI" => $lastItem['PROPERTY_UF_RES_TYPE_VALUE'],
        "PROPERTY_OPISANIE" => $lastItem['DETAIL_TEXT'],
        "PROPERTY_POVTOR" => GetMessage("INTASK_C29T_REGULARITY_" . $lastItem['PROPERTY_PERIOD_TYPE_VALUE']),
        "PROPERTY_OPTSIYA_1" => $lastItem['PROPERTY_UF_OPTION_1_VALUE'],
        "PROPERTY_OPTSIYA_2" => $lastItem['PROPERTY_UF_OPTION_2_VALUE'],
        "PROPERTY_OPTSIYA_3" => $lastItem['PROPERTY_UF_OPTION_3_VALUE'],
        "PROPERTY_RESP" => $lastItem['PROPERTY_UF_RESP_TEXT_VALUE'],
    ]);
    //debug($getDoc);
    LocalRedirect("{$curpath}?page={$_GET['page']}&meeting_id={$_GET['meeting_id']}");
}
?>
<?
$curPath = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];//$APPLICATION->GetCurPage();
$isAuto = strpos($curPath, "Auto");
$MESS ['EC_INTRANET_MODULE_NOT_INSTALLED'] = "Модуль интранета не установлен";
$MESS ['EC_IBLOCK_MODULE_NOT_INSTALLED'] = "Модуль информационных блоков не установлен";
$MESS ['INTS_NO_IBLOCK_PERMS'] = $isAuto ? "У вас нет прав на просмотр информационного блока резервирования автомобилей"  : "У вас нет прав на просмотр информационного блока переговорных";

$MESS ['INTASK_C36_PAGE_TITLE'] = $isAuto ? "График резервирования автомобиля" : "График переговорной";//DAN "График переговорной";
$MESS ['INTASK_C36_PAGE_TITLE1'] = $isAuto ? "Резервирование автомобилей":"Резервирование переговорных";
$MESS ['INAF_F_ID'] = "ID";
$MESS ['INAF_F_NAME'] = "Название";
$MESS ['INAF_F_DESCRIPTION'] = "Описание";
$MESS ['INAF_F_FLOOR'] = "Этаж";
$MESS ['INAF_F_PLACE'] = "Мест";
$MESS ['INAF_F_PHONE'] = "Телефон";
$MESS ['INAF_MEETING_NOT_FOUND'] = $isAuto ? "Автомобиль не найден" : "Переговорная не найдена.";
$MESS ['INTASK_C25_CONFLICT1'] = "Конфликт по времени в период #TIME# между \"#RES1#\" и \"#RES2#\"";
$MESS ['INTASK_C25_CONFLICT2'] = "Конфликт по времени в период #TIME# между \"#RES1#\" и \"#RES2#\"";
$MESS ['INTR_IRMM_NAME_TEMPLATE_DEFAULT'] = "#NOBR##LAST_NAME# #NAME##/NOBR#";
?>
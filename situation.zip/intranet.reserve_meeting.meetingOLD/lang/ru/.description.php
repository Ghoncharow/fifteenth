<?
$MESS ['INTR_GROUP_NAME'] = "Корпоративный портал";
$MESS ['INTRANET_RESMIT'] = "Бронирование переговорных";
$MESS ['INTRANET_RESMIT_ITEM'] = "Переговорная";
$MESS ['INTRANET_RESMIT_ITEM_DESCRIPTION'] = "Компонент для отображения переговорной";
?>
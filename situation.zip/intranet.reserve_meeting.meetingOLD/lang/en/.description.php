<?
$MESS ['INTR_GROUP_NAME'] = "Intranet Portal";
$MESS ['INTRANET_RESMIT'] = "Meeting Room Booking";
$MESS ['INTRANET_RESMIT_ITEM'] = "Meeting Room";
$MESS ['INTRANET_RESMIT_ITEM_DESCRIPTION'] = "Shows a meeting room.";
?>
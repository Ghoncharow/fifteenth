<?
$MESS["EC_INTRANET_MODULE_NOT_INSTALLED"] = "The Intranet module is not installed.";
$MESS["EC_IBLOCK_MODULE_NOT_INSTALLED"] = "The Information Blocks module is not installed.";
$MESS["INTASK_C36_PAGE_TITLE"] = "Meeting Room Schedule";
$MESS["INTASK_C36_PAGE_TITLE1"] = "Meeting Room Booking";
$MESS["INAF_F_ID"] = "ID";
$MESS["INAF_F_NAME"] = "Title";
$MESS["INAF_F_DESCRIPTION"] = "Description";
$MESS["INAF_F_FLOOR"] = "Floor";
$MESS["INAF_F_PLACE"] = "Seats";
$MESS["INAF_F_PHONE"] = "Phone";
$MESS["INAF_MEETING_NOT_FOUND"] = "The meeting room was not found.";
$MESS["INTASK_C25_CONFLICT1"] = "Time conflict during #TIME# between \"#RES1#\" and \"#RES2#\"";
$MESS["INTASK_C25_CONFLICT2"] = "Time conflict during #TIME# between \"#RES1#\" and \"#RES2#\"";
$MESS["INTR_IRMM_NAME_TEMPLATE_DEFAULT"] = "#NOBR##NAME# #LAST_NAME##/NOBR#";
$MESS["INTS_NO_IBLOCK_PERMS"] = "You don't have permission to view the meeting room information block.";
?>
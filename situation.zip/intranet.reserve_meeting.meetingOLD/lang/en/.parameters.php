<?
$MESS["INTL_VARIABLE_ALIASES"] = "Variable Aliases";
$MESS["INTL_IBLOCK_TYPE"] = "Information Block Type";
$MESS["INTL_IBLOCK"] = "Information Block";
$MESS["INTL_MEETING_VAR"] = "Variable for Meeting Room ID";
$MESS["INTL_ITEM_VAR"] = "Booking ID variable";
$MESS["INTL_PAGE_VAR"] = "Page Variable";
$MESS["INTL_MEETING_ID"] = "Meeting Room ID";
$MESS["INTL_PATH_TO_MEETING"] = "Booking Room Schedule Page";
$MESS["INTL_PATH_TO_MEETING_LIST"] = "Meeting Room Booking Main Page";
$MESS["INTL_PATH_TO_RESERVE_MEETING"] = "Meeting Room Booking Page";
$MESS["INTL_PATH_TO_MODIFY_MEETING"] = "Meeting Room Parameters Editor Page";
$MESS["INTL_SET_NAVCHAIN"] = "Set Breadcrumbs";
$MESS["INTL_USERGROUPS_CLEAR"] = "User Groups Allowed to Cancel Booked Meeting Rooms";
$MESS["INTL_P_WEEK_HOLIDAYS"] = "Weekend Days";
$MESS["INTL_P_MON_F"] = "Monday";
$MESS["INTL_P_TUE_F"] = "Tuesday";
$MESS["INTL_P_WEN_F"] = "Wednesday";
$MESS["INTL_P_THU_F"] = "Thursday";
$MESS["INTL_P_FRI_F"] = "Friday";
$MESS["INTL_P_SAT_F"] = "Saturday";
$MESS["INTL_P_SAN_F"] = "Sunday";
$MESS["INTL_PATH_TO_VIEW_ITEM"] = "Meeting room reservation view page";
?>
<?
$MESS ['INTR_GROUP_NAME'] = "Intranet Portal";
$MESS ['INTRANET_RESMIT'] = "Meeting Room Booking";
$MESS ['INTRANET_RESMITVI_ITEM'] = "Meeting Room Booking Details";
$MESS ['INTRANET_RESMITVI_ITEM_DESCRIPTION'] = "A component to view Meeting Room Booking Details";
?>
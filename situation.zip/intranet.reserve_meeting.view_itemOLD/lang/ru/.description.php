<?
$MESS ['INTR_GROUP_NAME'] = "Корпоративный портал";
$MESS ['INTRANET_RESMIT'] = "Бронирование переговорных";
$MESS ['INTRANET_RESMITVI_ITEM'] = "Просмотр резервирования";
$MESS ['INTRANET_RESMITVI_ITEM_DESCRIPTION'] = "Компонент для просмотра резервирования";
?>
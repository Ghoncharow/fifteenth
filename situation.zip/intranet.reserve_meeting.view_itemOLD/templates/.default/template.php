<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$APPLICATION->SetTitle("Бронирование cитуационного центра");
echo '<script type="text/javascript">console.log('.json_encode($arResult).');</script>';

if (strlen($arResult["FatalError"]) > 0)
{
    ?>
    <span class='errortext'><?=$arResult["FatalError"]?></span><br /><br />
    <?
}
else
{
    if (strlen($arResult["ErrorMessage"]) > 0)
    {
        ?>
        <span class='errortext'><?=$arResult["ErrorMessage"]?></span><br /><br />
        <?
    }
    ?>


    <? $partiZafks = [];
    $rsParentSection = CIBlockSection::GetByID(1128);
    if ($arParentSection = $rsParentSection->GetNext()) {
        $arFilter = array('ACTIVE' => "Y", '%NAME' => "управление", 'IBLOCK_ID' => $arParentSection['IBLOCK_ID'], '>LEFT_MARGIN' => $arParentSection['LEFT_MARGIN'], '<RIGHT_MARGIN' => $arParentSection['RIGHT_MARGIN'], '>DEPTH_LEVEL' => $arParentSection['DEPTH_LEVEL']);
        $rsSect = CIBlockSection::GetList(array('UF_INDEX' => 'asc'), $arFilter, false, array("UF_*"));
        while ($arSect = $rsSect->GetNext()) {
            $partiZafks[] = array(
                "VALUE" => $arSect["NAME"],
                "ID" => $arSect["ID"],
                "UF_INDEX" => $arSect["UF_INDEX"]
            );
        }
    } 
    $partiZafks[0]["UF_INDEX"] = "9";
    function array_multisort_value() {
        $args = func_get_args();
        $data = array_shift($args);
        foreach ($args as $n => $field) {
            if (is_string($field)) {
                $tmp = array();
                foreach ($data as $key => $row) {
                    $tmp[$key] = $row[$field];
                }
                $args[$n] = $tmp;
            }
        }
        $args[] = &$data;
        call_user_func_array('array_multisort', $args);
        return array_pop($args);
    }
    $partiZafks = array_multisort_value($partiZafks, 'UF_INDEX', SORT_ASC);                    
    foreach ($partiZafks as $item) { 
        $pos = strpos($item["VALUE"], " - ");
        if ($pos === false || $pos > 90) $pos = 90;
        if ($item["ID"] == $arResult["ITEM"]["PROPERTY_UF_ZAFK_VALUE_VALUE"]) {
            $itemResult = ($item["UF_INDEX"] ? $item["UF_INDEX"].'. ' : '').substr($item["VALUE"], 0, $pos);
        }
    }

    $partiTofks = [];
    $rsParentSection1 = CIBlockSection::GetByID(609);
    if ($arParentSection1 = $rsParentSection1->GetNext()) {
        $arFilter1 = array('%NAME'=>"УФК", '!%NAME'=>["руководитель","помощник"], 'IBLOCK_ID' => $arParentSection1['IBLOCK_ID'],'>LEFT_MARGIN' => $arParentSection1['LEFT_MARGIN'],'<RIGHT_MARGIN' => $arParentSection1['RIGHT_MARGIN'],'>DEPTH_LEVEL' => $arParentSection1['DEPTH_LEVEL']);
        $rsSect1 = CIBlockSection::GetList(array( 'name'=>'asc'), $arFilter1);

        while ($arSect1 = $rsSect1->GetNext()) {
            if (in_array($arSect1["ID"], $arResult["ITEM"]["~PROPERTY_UF_PARTIS_LIST_VALUE"])) $partiTofks[] = $arSect1["NAME"];
        }
    }
    // echo '<script type="text/javascript">console.log('.json_encode($partiTofks).');</script>';

    $tableArr = [
        [
            "TYPE" => "D",
            "NAME" => GetMessage("INTASK_C29T_DATE_FROM"),
            "VALUE" => $arResult['ITEM']['DATE_ACTIVE_FROM'],
        ],
        [
            "TYPE" => "D",
            "NAME" => GetMessage("INTASK_C29T_DATE_TO"),
            "VALUE" => $arResult['ITEM']['DATE_ACTIVE_TO'],
        ],
        [
            "TYPE" => "U",
            "NAME" => GetMessage("INTASK_C29T_AUTHOR"),
            "VALUE" => $arResult["ITEM"]["CREATED_BY_ID"],
        ],
        [
            "TYPE" => "S",
            "NAME" => $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_ZAFK_VALUE"]["NAME"],
            "VALUE" => $itemResult,
        ],
        [
            "TYPE" => "S",
            "NAME" => "Тема мероприятия",
            "VALUE" => $arResult["ITEM"]["~NAME"],
        ],
        [
            "TYPE" => "S",
            "NAME" => "Количество участников",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_PERSONS_VALUE"],
        ],
        [
            "TYPE" => "F",
            "NAME" => "Перечень участников (файлы)",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_MEMBERS_FILE_VALUE"],
            "HIDE" => empty($arResult["ITEM"]["~PROPERTY_UF_MEMBERS_FILE_VALUE"]),
            "INPUT_NAME" => "members_file"
        ],
        [
            "TYPE" => "S",
            "NAME" => $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["NAME"],
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_INFORMATION_LIST_VALUE"],
        ],
        [
            "TYPE" => "F",
            "NAME" => "Материалы (презентации, таблицы)",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_PRESENTATION_FILE_VALUE"],
            "HIDE" => empty($arResult["ITEM"]["~PROPERTY_UF_PRESENTATION_FILE_VALUE"]),
            "INPUT_NAME" => "presentation_file"
        ],
        [
            "TYPE" => "S",
            "NAME" => "Необходимость протокольного сопровождения",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_2_VALUE"] == "Y" ? "Да" : "Нет",
        ],
        [
            "TYPE" => "F",
            "NAME" => $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_EVENTS_PLAN"]["NAME"].' (файлы)',
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_EVENTS_PLAN_VALUE"],
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_2_VALUE"] != "Y" || empty($arResult["ITEM"]["~PROPERTY_UF_EVENTS_PLAN_VALUE"]),
            "INPUT_NAME" => "events_plan"
        ],
        [
            "TYPE" => "F",
            "NAME" => $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_SEATING_PLAN"]["NAME"].' (файлы)',
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_SEATING_PLAN_VALUE"],
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_2_VALUE"] != "Y" || empty($arResult["ITEM"]["~PROPERTY_UF_SEATING_PLAN_VALUE"]),
            "INPUT_NAME" => "seating_plan"
        ],
        [
            "TYPE" => "S",
            "NAME" => "Настройка ВКС",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] == "Y" ? "Да" : "Нет",
        ],
        [
            "TYPE" => "S",
            "NAME" => "Тип сеанса АВКС",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_OTHER_AVKS_VALUE"],
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y"
        ],
        [
            "TYPE" => "S",
            "NAME" => $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_VIDEO"]["NAME"],
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_MAKE_VIDEO_VALUE"],
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y" || $arResult["ITEM"]["~PROPERTY_UF_OTHER_AVKS_ENUM_ID"] != '164'
        ],
        [
            "TYPE" => "S",
            "NAME" => $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_AUDIO"]["NAME"],
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_MAKE_AUDIO_VALUE"],
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y" || $arResult["ITEM"]["~PROPERTY_UF_OTHER_AVKS_ENUM_ID"] != '165'
        ],
        [
            "TYPE" => "S",
            "NAME" => "Перечень участников (список)",
            "VALUE" => nl2br(htmlspecialchars($arResult["ITEM"]["~PROPERTY_UF_MEMBERS_LIST_VALUE"])),
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y" || $arResult["ITEM"]["~PROPERTY_UF_OTHER_AVKS_ENUM_ID"] != '166',
            "INPUT_NAME" => "partis_file"
        ],
        [
            "TYPE" => "S",
            "NAME" => "Площадки, с которыми потребуется настроить связь (ЦАФК, ЦОКР)",
            "VALUE" => nl2br(htmlspecialchars(implode(",\n", $arResult["ITEM"]["~PROPERTY_UF_CONNECTION_LIST_VALUE"]))),
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y" || $arResult["ITEM"]["~PROPERTY_UF_OTHER_AVKS_ENUM_ID"] == '166' || empty($arResult["ITEM"]["~PROPERTY_UF_CONNECTION_LIST_VALUE"]),
        ],
        [
            "TYPE" => "S",
            "NAME" => "Площадки, с которыми потребуется настроить связь (ТОФК)",
            "VALUE" => nl2br(htmlspecialchars(implode(",\n", $partiTofks))),
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y" || $arResult["ITEM"]["~PROPERTY_UF_OTHER_AVKS_ENUM_ID"] == '166' || empty($partiTofks),
        ],
        [
            "TYPE" => "F",
            "NAME" => "Список площадок (файл)",
            "VALUE" => $arResult["ITEM"]["~PROPERTY_UF_PARTIS_FILE_VALUE"],
            "HIDE" => $arResult["ITEM"]["~PROPERTY_UF_OPTION_1_VALUE"] != "Y" || empty($arResult["ITEM"]["~PROPERTY_UF_PARTIS_FILE_VALUE"]),
            "INPUT_NAME" => "partis_file"
        ],
    ]; ?>
    <table class="view_table table table-striped">
        <tbody>
        <?foreach ($tableArr as $item) {
            if ($item["HIDE"]) continue;?>
            <tr>
                <td align="left" valign="top"><?= $item["NAME"] ?>:</td>
                <?
                if(is_array($item["VALUE"])){
                    switch ($item["TYPE"]) {
                        default:
                        case "S":?>
                            <td><?=implode(", ", $item["VALUE"])?></td>
                            <?break;
                        case "F":?>
                            <td valign="top"><?$APPLICATION->IncludeComponent(
                                "bitrix:main.file.input",
                                "",
                                array(
                                    "INPUT_NAME" => $item["INPUT_NAME"],
                                    "MULTIPLE" => "Y",
                                    "MODULE_ID" => "iblock",
                                    "MAX_FILE_SIZE" => "",
                                    "ALLOW_UPLOAD" => "N",
                                    "ALLOW_UPLOAD_EXT" => "",
                                    "INPUT_VALUE" => $item["VALUE"],
                                ),
                                false
                            ); ?></td><?
                            break;
                        case "D": ?><td width="60%"><?= formatDate($arParams['DATE_TIME_FORMAT'], makeTimeStamp($item["VALUE"][0])) ?></td><?
                            break;
                        case "U":
                            foreach ($item["VALUE"] as $user) {
                                ?>
                                <td>
                                <?
                                $APPLICATION->IncludeComponent("bitrix:main.user.link", "", Array(
                                    "CACHE_TYPE" => "A",
                                    "CACHE_TIME" => "7200",
                                    "ID" => $user,
                                    "NAME_TEMPLATE" => "#NOBR##LAST_NAME# #NAME##/NOBR#",
                                    "SHOW_LOGIN" => "N",
                                    "THUMBNAIL_LIST_SIZE" => "30",
                                    "THUMBNAIL_DETAIL_SIZE" => "100",
                                    "USE_THUMBNAIL_LIST" => "Y",
                                    "SHOW_FIELDS" => Array("PERSONAL_BIRTHDAY", "PERSONAL_ICQ", "PERSONAL_PHOTO", "PERSONAL_CITY", "WORK_COMPANY", "WORK_POSITION"),
                                    "USER_PROPERTY" => Array("UF_USER_CAR_DEMO"),
                                    "PATH_TO_SONET_USER_PROFILE" => "",
                                    "PROFILE_URL" => "",
                                    "DATE_TIME_FORMAT" => "d.m.Y H:i:s",
                                    "SHOW_YEAR" => "Y"
                                )); ?>
                                </td><?
                            }
                            break;
                    }
                }
                else {
                    switch ($item["TYPE"]) {
                        default:
                        case "S":?>
                            <td><?=$item["VALUE"]?></td>
                            <?break;
                        case "F":?>
                            <td valign="top"><?$APPLICATION->IncludeComponent(
                                "bitrix:main.file.input",
                                "",
                                array(
                                    "INPUT_NAME" => "partis_file",
                                    "MULTIPLE" => "N",
                                    "MODULE_ID" => "iblock",
                                    "MAX_FILE_SIZE" => "",
                                    "ALLOW_UPLOAD" => "N",
                                    "ALLOW_UPLOAD_EXT" => "",
                                    "INPUT_VALUE" => $item["VALUE"],
                                ),
                                false
                            ); ?></td><?
                            break;
                        case "D": ?><td width="60%"><?= formatDate($arParams['DATE_TIME_FORMAT'], makeTimeStamp($item["VALUE"])) ?></td><?
                            break;
                        case "U":
                            ?>
                            <td><?// $arResult["ITEM"]["PROPERTY_UF_RESP_TEXT_VALUE"] ?>
                            <?
                            $APPLICATION->IncludeComponent("bitrix:main.user.link", "", Array(
                                "CACHE_TYPE" => "A",
                                "CACHE_TIME" => "7200",
                                "ID" => $item["VALUE"],
                                "NAME_TEMPLATE" => "#NOBR##LAST_NAME# #NAME##/NOBR#",
                                "SHOW_LOGIN" => "N",
                                "THUMBNAIL_LIST_SIZE" => "30",
                                "THUMBNAIL_DETAIL_SIZE" => "100",
                                "USE_THUMBNAIL_LIST" => "Y",
                                "SHOW_FIELDS" => Array("PERSONAL_BIRTHDAY", "PERSONAL_ICQ", "PERSONAL_PHOTO", "PERSONAL_CITY", "WORK_COMPANY", "WORK_POSITION"),
                                "USER_PROPERTY" => Array("UF_USER_CAR_DEMO"),
                                "PATH_TO_SONET_USER_PROFILE" => "",
                                "PROFILE_URL" => "",
                                "DATE_TIME_FORMAT" => "d.m.Y H:i:s",
                                "SHOW_YEAR" => "Y"
                            )); ?>
                            </td><?
                            break;
                    }
                }?>
            </tr>
        <?}?>
        </tbody>
    </table>

    <br />
    <?
}
?>
<?
$MESS ['INTR_GROUP_NAME'] = "Корпоративный портал";
$MESS ['INTRANET_RESMIT'] = "Бронирование переговорных";
$MESS ['INTRANET_RESMITR_ITEM'] = "Резервирование переговорной";
$MESS ['INTRANET_RESMITR_ITEM_DESCRIPTION'] = "Компонент для резервирования переговорной";
?>
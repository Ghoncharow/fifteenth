<?
$MESS ['INTL_VARIABLE_ALIASES'] = "Псевдонимы переменных";
$MESS ['INTL_IBLOCK_TYPE'] = "Тип инфоблока";
$MESS ['INTL_IBLOCK'] = "Инфоблок";
$MESS ['INTL_MEETING_VAR'] = "Имя переменной для идентификатора переговорной";
$MESS ['INTL_ITEM_VAR'] = "Имя переменной для идентификатора резервирования";
$MESS ['INTL_PAGE_VAR'] = "Имя переменной для страницы";
$MESS ['INTL_PATH_TO_MEETING'] = "Путь к графику переговорной";
$MESS ['INTL_PATH_TO_MEETING_LIST'] = "Путь к главной странице резервирования переговорных";
$MESS ['INTL_PATH_TO_RESERVE_MEETING'] = "Путь к странице резервирования переговорных";
$MESS ['INTL_PATH_TO_MODIFY_MEETING'] = "Путь к странице изменения переговорной";
$MESS ['INTL_SET_NAVCHAIN'] = "Устанавливать навигационную цепочку";
$MESS ['INTL_USERGROUPS_MODIFY'] = "Группы пользователей, которые могут изменять переговорные";
$MESS ['INTL_USERGROUPS_RESERVE'] = "Группы пользователей, которые могут резервировать переговорные";
$MESS ['INTL_USERGROUPS_CLEAR'] = "Группы пользователей, которые могут снимать резервирование переговорных";
$MESS ['INTL_MEETING_ID'] = "Код переговорной";
$MESS ['INTL_ITEM_ID'] = "Код резервирования";
?>
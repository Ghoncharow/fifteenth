<?
$MESS ['INTL_VARIABLE_ALIASES'] = "Variable Aliases";
$MESS ['INTL_IBLOCK_TYPE'] = "Information Block Type";
$MESS ['INTL_IBLOCK'] = "Information Block";
$MESS ['INTL_MEETING_VAR'] = "Variable for Meeting Room ID";
$MESS ['INTL_ITEM_VAR'] = "Booking ID variable";
$MESS ['INTL_PAGE_VAR'] = "Page Variable";
$MESS ['INTL_PATH_TO_MEETING'] = "Booking Room Schedule Page";
$MESS ['INTL_PATH_TO_MEETING_LIST'] = "Meeting Room Booking Main Page";
$MESS ['INTL_PATH_TO_RESERVE_MEETING'] = "Meeting Room Booking Page";
$MESS ['INTL_PATH_TO_MODIFY_MEETING'] = "Meeting Room Parameters Editor Page";
$MESS ['INTL_SET_NAVCHAIN'] = "Set Breadcrumbs";
$MESS ['INTL_USERGROUPS_MODIFY'] = "User Groups Allowed to Edit Meeting Room Schedule";
$MESS ['INTL_USERGROUPS_RESERVE'] = "User Groups Allowed to Book Meeting Rooms";
$MESS ['INTL_USERGROUPS_CLEAR'] = "User Groups Allowed to Cancel Booked Meeting Rooms";
$MESS ['INTL_MEETING_ID'] = "Meeting Room ID";
$MESS ['INTL_ITEM_ID'] = "Booking ID";
?>
<?
$MESS ['INTR_GROUP_NAME'] = "Intranet Portal";
$MESS ['INTRANET_RESMIT'] = "Meeting Room Booking";
$MESS ['INTRANET_RESMITR_ITEM'] = "Meeting Room Booking";
$MESS ['INTRANET_RESMITR_ITEM_DESCRIPTION'] = "A component to book meeting rooms.";
?>
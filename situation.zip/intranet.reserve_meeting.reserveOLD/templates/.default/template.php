<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
    die(); ?>
<?
$debug = false;
CJSCore::Init(array('jquery2'));
$APPLICATION->SetTitle("Бронирование cитуационного центра");
echo '<script type="text/javascript">console.log('.json_encode($arResult).');</script>';
?>

<link rel="stylesheet" href="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/jquery-ui.css">
<script src="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/jquery-ui.js"></script>
<link rel="stylesheet" href="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/jsgrid/jsgrid.min.css">
<link rel="stylesheet" href="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/jsgrid/jsgrid-theme.min.css">
<script src="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/jsgrid/jsgrid.min.js"></script>
<script src="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/jsgrid/i18n/jsgrid-ru.js"></script>
<link rel="stylesheet" href="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/toastr.css">
<script src="/bitrix/components/custom/intranet.reserve_meeting.reserveOLD/templates/.default/toastr.js"></script>
<link rel="stylesheet" href="/bitrix/templates/bitrix24/select2.min.css">
<script src="/bitrix/templates/bitrix24/select2.min.js"></script>
<?

if (strlen($arResult["ErrorMessage"]) > 0) {?>
    <span style="color: red;" class='errortext'><?= $arResult["ErrorMessage"] ?></span>
<?}

if (strlen($arResult["FatalError"]) > 0) {?>
    <span class='errortext'><?= $arResult["FatalError"] ?></span><br/><br/>
<?} else {?>

    <form method="post" action="<?= POST_FORM_ACTION_URI ?>" enctype="multipart/form-data" name="meeting_reserve">
        <table cellpadding="0" cellspacing="0" border="0" width="100%" class="intask-main data-table">
            <tbody id="bron-content">
            <tr>
                <td align="left"><!--span class="red_star">*</span--><?= GetMessage("INTASK_C29T_DATE") ?>:</td>
                <td><?
                    $GLOBALS["APPLICATION"]->IncludeComponent('bitrix:main.calendar', '', array('SHOW_INPUT' => 'Y', 'FORM_NAME' => "meeting_reserve", 'INPUT_NAME' => "start_date", 'INPUT_VALUE' => $arResult["Item"]["StartDate"], 'SHOW_TIME' => 'N', 'INPUT_ADDITIONAL_ATTR' => $strAdd,), null, array('HIDE_ICONS' => 'Y'));
                    ?>
                </td>
            </tr>
            <tr>
                <td align="left"><?= GetMessage("INTASK_C29T_AUTHOR") ?>:</td>
                <td><?
                    $APPLICATION->IncludeComponent("bitrix:main.user.link", '', array("ID" => $arResult["Item"]["Author_ID"], "HTML_ID" => "reserve_meeting_reserve" . $arResult["Item"]["Author_ID"], "NAME" => htmlspecialcharsback($arResult["Item"]["Author_NAME"]), "LAST_NAME" => htmlspecialcharsback($arResult["Item"]["Author_LAST_NAME"]), "SECOND_NAME" => htmlspecialcharsback($arResult["Item"]["Author_SECOND_NAME"]), "LOGIN" => htmlspecialcharsback($arResult["Item"]["Author_LOGIN"]), "USE_THUMBNAIL_LIST" => "Y", "THUMBNAIL_LIST_SIZE" => 30, "PATH_TO_SONET_USER_PROFILE" => $arParams["~PATH_TO_USER"], "PATH_TO_SONET_MESSAGES_CHAT" => $arParams["~PM_URL"], "PATH_TO_VIDEO_CALL" => $arParams["~PATH_TO_VIDEO_CALL"], "PATH_TO_CONPANY_DEPARTMENT" => $arParams["~PATH_TO_CONPANY_DEPARTMENT"], "DATE_TIME_FORMAT" => $arParams["DATE_TIME_FORMAT"], "SHOW_YEAR" => $arParams["SHOW_YEAR"], "NAME_TEMPLATE" => $arParams["NAME_TEMPLATE"], "SHOW_LOGIN" => $arParams["SHOW_LOGIN"],), false, array("HIDE_ICONS" => "Y"));
                    ?>
                </td>
            </tr>
                <tr>
                    <td align="left"><?=$arResult["ALLOWED_ITEM_PROPERTIES"]["UF_ZAFK_VALUE"]["NAME"]?>:</td>
                    <td>
                    <? $partiZafks = [];
                    $rsParentSection = CIBlockSection::GetByID(1128);
                    if ($arParentSection = $rsParentSection->GetNext()) {
                        $arFilter = array('ACTIVE' => "Y", '%NAME' => "управление", 'IBLOCK_ID' => $arParentSection['IBLOCK_ID'], '>LEFT_MARGIN' => $arParentSection['LEFT_MARGIN'], '<RIGHT_MARGIN' => $arParentSection['RIGHT_MARGIN'], '>DEPTH_LEVEL' => $arParentSection['DEPTH_LEVEL']);
                        $rsSect = CIBlockSection::GetList(array('UF_INDEX' => 'asc'), $arFilter, false, array("UF_*"));
                        while ($arSect = $rsSect->GetNext()) {
                            $partiZafks[] = array(
                                "VALUE" => $arSect["NAME"],
                                "ID" => $arSect["ID"],
                                "UF_INDEX" => $arSect["UF_INDEX"]
                            );
                        }
                    } 
                    $partiZafks[0]["UF_INDEX"] = "9";
                    function array_multisort_value() {
                        $args = func_get_args();
                        $data = array_shift($args);
                        foreach ($args as $n => $field) {
                            if (is_string($field)) {
                                $tmp = array();
                                foreach ($data as $key => $row) {
                                    $tmp[$key] = $row[$field];
                                }
                                $args[$n] = $tmp;
                            }
                        }
                        $args[] = &$data;
                        call_user_func_array('array_multisort', $args);
                        return array_pop($args);
                    }
                    $partiZafks = array_multisort_value($partiZafks, 'UF_INDEX', SORT_ASC);
                    // echo '<script type="text/javascript">console.log('.json_encode($partiZafks).');</script>';
                    ?>                    
                    <select name="zafk_value" id="zafk_value">
                        <option value="">Выберите управление</option>
                        <? foreach ($partiZafks as $item) { 
                            $pos = strpos($item["VALUE"], " - ");
                            if ($pos === false || $pos > 90) $pos = 90; ?>
                            <option value="<?= $item["ID"] ?>" <?= ($item["ID"] == $arResult["Item"]["Zafk_value"]) ? "selected" : "" ?>>
                            <?= ($item["UF_INDEX"] ? $item["UF_INDEX"].'. ' : '').substr($item["VALUE"], 0, $pos); ?></option>
                        <? } ?>

                    </select>
                    </td>
                </tr>
            <tr>
                <td align="left"><!--span class="red_star">*</span--><?= GetMessage("INTASK_C29T_FROM_TIME") ?>:</td>
                <td>
                    <select name="start_time" onchange="RMR_CalcEndTime()">
                        <?
                        $aMpM = IsAmPmMode();
                        $s = (StrLen($arResult["Item"]["StartTime"]) > 0 ? $arResult["Item"]["StartTime"] : "08:00");
                        for ($i = 9 * 2; $i < 18 * 2 + 1; $i++) {
                            $t = IntVal($i / 2);
                            if ($aMpM) {
                                if ($t >= 12) {
                                    $mt = 'pm';
                                    if ($t > 12) {
                                        $t -= 12;
                                    }
                                } else {
                                    if ($t == 0) {
                                        $t = 12;
                                    }
                                    $mt = 'am';
                                }
                            } else {
                                if ($t < 10) {
                                    $t = "0" . $t;
                                }
                            }
                            $t .= ":";
                            if ($i % 2 == 0)
                                $t .= "00";
                            else
                                $t .= "30";
                            if (!empty($mt)) {
                                $t .= ' ' . $mt;
                            }
                            ?>
                            <option value="<?= $t ?>"<?= ($s == $t ? " selected" : "") ?>><?= $t ?></option><?
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td align="left"><!--span class="red_star">*</span--><?= GetMessage("INTASK_C29T_DURATION") ?>:</td>
                <td>
                    <select name="timeout_time" onchange="RMR_CalcEndTime()">
                        <option value="0:45"<?= ($arResult["Item"]["TimeoutTime"] == "0:45" ? " selected" : "") ?>>45 минут</option>
                        <option value="1:00"<?= ($arResult["Item"]["TimeoutTime"] == "1:00" ? " selected" : "") ?>>1 час</option>
                        <option value="1:30"<?= ($arResult["Item"]["TimeoutTime"] == "1:30" ? " selected" : "") ?>>1 час 30 минут</option>                        
                    </select>
                </td>
            </tr>
            <tr>
                <td align="left"><?= GetMessage("INTASK_C29T_TO_TIME") ?>:</td>
                <td>
                    <input type="text" name="end_time" readonly value="" size="5">
                    <script language="JavaScript">
                        <!--
                        function RMR_CalcEndTime() {
                            var aMpM = BX.isAmPmMode();
                            if (!document.meeting_reserve.start_time || !document.meeting_reserve.timeout_time)
                                return;
                            var s = document.meeting_reserve.start_time[document.meeting_reserve.start_time.selectedIndex].value;
                            var t = document.meeting_reserve.timeout_time[document.meeting_reserve.timeout_time.selectedIndex].value;
                            var h = s.split(":");
                            if (aMpM) {
                                h[1] = h[1].split(' ');
                                var mt = h[1][1];
                                h[1] = h[1][0];
                                if (h[0] < 12 && mt == 'pm') {
                                    h[0] = parseInt(h[0], 10) + 12;
                                } else if (h[0] == 12 && mt == 'am') {
                                    h[0] = 0;
                                }
                            }
                            var r = t.split(":");
                            var n1 = parseInt(h[0], 10) + parseInt(r[0], 10);
                            var n2 = parseInt(h[1], 10) + parseInt(r[1], 10);
                            while (n2 >= 60) {
                                n1 = n1 + 1;
                                n2 = n2 - 60;
                            }
                            n2 = (n2 < 10) ? '0'+n2 : n2;
                            // console.log(h, r);
                            if (n1 > 23)
                                n1 = n1 - 24;
                            if (n1 < 10 && !aMpM)
                                n1 = "0" + n1;
                            if (aMpM) {
                                if (n1 >= 12) {
                                    mt = 'pm';
                                    if (n1 > 12) {
                                        n1 = n1 - 12;
                                    }
                                } else {
                                    mt = 'am';
                                }
                                if (n1 == 0) {
                                    n1 = 12;
                                }
                            }
                            document.meeting_reserve.end_time.value = n1 + ":" + n2 + (mt != undefined ? ' ' + mt : '');
                        }

                        var RMR_Transs = {
                            "DAILY1": "<?= GetMessage("INTASK_C29T_TRANSS_D1") ?>",
                            "DAILY2": "<?= GetMessage("INTASK_C29T_TRANSS_D2") ?>",
                            "WEEKLY1": "<?= GetMessage("INTASK_C29T_TRANSS_W1") ?>",
                            "WEEKLY2": "<?= GetMessage("INTASK_C29T_TRANSS_W2") ?>",
                            "MONTHLY1": "<?= GetMessage("INTASK_C29T_TRANSS_M1") ?>",
                            "MONTHLY2": "<?= GetMessage("INTASK_C29T_TRANSS_M2") ?>",
                            "YEARLY1": "<?= GetMessage("INTASK_C29T_TRANSS_Y1") ?>",
                            "YEARLY2": "<?= GetMessage("INTASK_C29T_TRANSS_Y2") ?>"
                        };

                        function RMR_RegularityChange(val) {
                            try {
                                var drc = document.getElementById('div_regularity_common');
                                var drw = document.getElementById('div_regularity_weekly');
                                if (val != "NONE") {
                                    drc.style.display = 'block';
                                    if (val == "WEEKLY")
                                        drw.style.display = 'block';
                                    else
                                        drw.style.display = 'none';
                                    document.getElementById('span_regularity_count_pref').innerText = RMR_Transs[val + "1"];
                                    document.getElementById('span_regularity_count_postf').innerText = RMR_Transs[val + "2"];
                                } else {
                                    drc.style.display = 'none';
                                    drw.style.display = 'none';
                                }

                            } catch (exception) {

                            }
                        }

                        //-->
                    </script>
                </td>
            </tr>
            <tr>
                <td align="left"><!--span class="red_star">*</span--><?= GetMessage("INTASK_C29T_NAME") ?>:</td>
                <td><input class="thema" type="text" name="name" value="<?= $arResult["Item"]["Name"] ?>" size="50"></td>
            </tr>
            <tr>
                <td align="left"><?= GetMessage("INTASK_C29T_PERSONS") ?> (от 2 до 30):</td>
                <td><input type="text" name="persons" value="<?= $arResult["Item"]["Persons"] ?>" size="5"/>
                    <span id="error"
                          style="color:red;margin-left:10px;display:none;">Максимальное количество участников: <?= $arResult["MEETING"]["UF_PLACE"]; ?></span>
                </td>
                <script>
                    $('input[name=persons]').on('change', function () {
                        var inpvalue = $(this).val() * 1;
                        var number = <?=strlen($arResult["MEETING"]["UF_PLACE"]) > 0 ? $arResult["MEETING"]["UF_PLACE"] : "0"?>;
                        if (number === "0")
                            return;

                        if (inpvalue > number) {
                            $(this).addClass('is-invalid').next().css('display', 'inline');
                            $('input[name="save"]').prop('disabled', true);
                        } else if (inpvalue <= 1) {
                            inpvalue = 0;
                            $(this).val(inpvalue).addClass('is-invalid').next().css('display', 'none');
                            $('input[name="save"]').prop('disabled', true);
                        } else {
                            $(this).removeClass('is-invalid').next().css('display', 'none');
                            $('input[name="save"]').prop('disabled', false);
                        }
                        //$(this).val(inpvalue);
                    })
                    ;
                </script>
            </tr>            
            <tr>
                <td align="left"><?=$arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MEMBERS_FILE"]["NAME"]?> (файл):</td>
                    <td>
                        <? $APPLICATION->IncludeComponent(
                            "bitrix:main.file.input",
                            "",
                            array(
                                "INPUT_NAME" => "members_file",
                                "MULTIPLE" => "Y",
                                "MODULE_ID" => "iblock",
                                "MAX_FILE_SIZE" => "",
                                "ALLOW_UPLOAD" => "A",
                                "ALLOW_UPLOAD_EXT" => "",
                                "INPUT_VALUE" => $arResult["Item"]['Members_file'],
                            ),
                            false
                        ); ?>
                    </td>
            </tr>
            
            <tr>
                    <td align="left"><?=$arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["NAME"]?>:</td>
                    <td>                        
                        <select name="information_list[]" id="information_list" class="multi-select" multiple="multiple">
                            <? asort($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["VALUES"]);
                            foreach ($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["VALUES"] as $item) { ?>
                                <option value="<?= $item["ID"] ?>" <?= key_exists($item["ID"], $arResult["Item"]["Information_list"]) ? "selected" : "" ?>><?= $item["VALUE"] ?></option>
                                <?
                            } ?>
                        </select>
                        <?if($GLOBALS['USER']->IsAdmin() || $GLOBALS["USER"]->GetId() == '1887'):?>
                            <div id="userlink" data-toggle="modal" data-target="#warning_lks">Редактировать перечень</div>
                        <?endif;?>
                        <script>
                            $('.multi-select').select2({
                                language: 'ru',
                                placeholder: "Выберите информационные ресурсы",
                            });
                            $('#information_list option').mousedown(function (e) {
                                e.preventDefault();
                                var originalScrollTop = $(this).parent().scrollTop();
                                // console.log(originalScrollTop);
                                $(this).prop('selected', $(this).prop('selected') ? false : true);
                                var self = this;
                                $(this).parent().focus();
                                setTimeout(function () {
                                    $(self).parent().scrollTop(originalScrollTop);
                                }, 0);

                                return false;
                            });
                        </script>
                    </td>
                </tr>
                <tr>
                    <td align="left">Материалы (презентации, таблицы):</td>
                    <td>
                        <? $APPLICATION->IncludeComponent(
                            "bitrix:main.file.input",
                            "",
                            array(
                                "INPUT_NAME" => "presentation_file",
                                "MULTIPLE" => "Y",
                                "MODULE_ID" => "iblock",
                                "MAX_FILE_SIZE" => "",
                                "ALLOW_UPLOAD" => "A",//count($arResult["Item"]['Presentation_file']) > 0 ? "N" :"A",
                                "ALLOW_UPLOAD_EXT" => "",
                                "INPUT_VALUE" => $arResult["Item"]['Presentation_file'],
                            ),
                            false
                        ); ?>
                    </td>
                </tr>
                <tr>
                    <td align="left"><?= GetMessage("INTASK_C29T_OPT2") ?>:</td>
                    <td><input type="checkbox" name="option_2" id="vks_trigger_2" class="check"
                               value="Y" <?= ("Y" == $arResult["Item"]["Option_2"] ? "checked" : "") ?>>
                    </td>
                </tr>           
            <tr class="vks_support_2">
                <td align="left"><?=$arResult["ALLOWED_ITEM_PROPERTIES"]["UF_EVENTS_PLAN"]["NAME"]?>:</td>
                    <td>
                        <? $APPLICATION->IncludeComponent(
                            "bitrix:main.file.input",
                            "",
                            array(
                                "INPUT_NAME" => "events_plan",
                                "MULTIPLE" => "Y",
                                "MODULE_ID" => "iblock",
                                "MAX_FILE_SIZE" => "",
                                "ALLOW_UPLOAD" => "A",
                                "ALLOW_UPLOAD_EXT" => "",
                                "INPUT_VALUE" => $arResult["Item"]['Events_plan'],
                            ),
                            false
                        ); ?>
                    </td>
            </tr>           
            <tr class="vks_support_2">
                <td align="left"><?=$arResult["ALLOWED_ITEM_PROPERTIES"]["UF_SEATING_PLAN"]["NAME"]?>:</td>
                    <td>
                        <? $APPLICATION->IncludeComponent(
                            "bitrix:main.file.input",
                            "",
                            array(
                                "INPUT_NAME" => "seating_plan",
                                "MULTIPLE" => "Y",
                                "MODULE_ID" => "iblock",
                                "MAX_FILE_SIZE" => "",
                                "ALLOW_UPLOAD" => "A",
                                "ALLOW_UPLOAD_EXT" => "",
                                "INPUT_VALUE" => $arResult["Item"]['Seating_plan'],
                            ),
                            false
                        ); ?>
                    </td>
            </tr>
                <tr>
                    <td align="left"><?= GetMessage("INTASK_C29T_OPT1") ?>:</td>
                    <td><input type="checkbox" name="option_1" data-toggle="modal" data-target="#warning_lks1"
                        id="vks_trigger_1" class="check" value="Y" <?= ("Y" == $arResult["Item"]["Option_1"] ? "checked" : "") ?>>
                    </td>
                </tr>
                <script> 
                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": true,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": true,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "swing",
                        "showMethod": "show",
                        "hideMethod": "hide"
                    }
                    toastr.success("<br />Для подготовки кабинета к видеоконференцсвязи выберите поле «Настройка ВКС».<br /><br />", "Ситуационный центр");
                    $(document).ready(function () {
                        var trigger1 = $('#vks_trigger_1');
                        if (trigger1.prop('checked')) {
                            $(".vks_support").show();
                        } else {
                            $(".vks_support").hide();
                        }
                        trigger1.on('change', function () {
                                if (trigger1.prop('checked')) {
                                    $(".vks_support").show();
                                } else {
                                    $(".vks_support").hide();
                                }
                            }
                        );
                        var trigger2 = $('#vks_trigger_2');
                        if (trigger2.prop('checked')) {
                            $(".vks_support_2").show();
                        } else {
                            $(".vks_support_2").hide();
                        }
                        trigger2.on('change', function () {
                                if (trigger2.prop('checked')) {
                                    $(".vks_support_2").show();
                                } else {
                                    $(".vks_support_2").hide();
                                }
                            }
                        );
                    });

                </script>
                

                <tr class="vks_support">
                    <td align="left"><?= GetMessage("INTASK_C29T_AVKS") ?>:</td>
                    <td>
                        <select name="other_avks" id="other_avks">
                            <?
                            foreach ($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_OTHER_AVKS"]["VALUES"] as $item) { ?>
                                <option value="<?= $item["ID"] ?>" <?= $arResult["Item"]["Other_avks"] == $item["ID"] ? "selected" : "" ?>><?= $item["VALUE"] ?></option>
                                <?
                            } ?>
                        </select>
                    </td>
                </tr>
                <script>
                    function switchConfAudio(vsksType) {
                        $(".video, .audio, .external").addClass("hide");
                        switch (vsksType.val()) {
                        case '164':
                            $(".video").toggleClass("hide");
                            break;
                        case '165':
                            $(".audio").toggleClass("hide");
                            break;
                        case '166':
                            $(".external").toggleClass("hide");
                            break;
                        default:
                            console.log(vsksType);
                        }
                    }

                    $(document).ready(function () {
                        var vsksType = $("#other_avks");
                        switchConfAudio(vsksType);
                        vsksType.change(function () {
                            switchConfAudio(vsksType);
                        });
                    });

                </script>
                
                <tr class="vks_support video">
                    <td align="left"><?= $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_VIDEO"]["NAME"] ?>:</td>
                    <td>
                        <select name="make_video" id="make_video">
                            <?
                            foreach ($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_VIDEO"]["VALUES"] as $item) { ?>
                                <option value="<?= $item["ID"] ?>" <?= $arResult["Item"]["Make_video"] == $item["ID"] ? "selected" : "" ?>><?= $item["VALUE"] ?></option>
                                <?
                            } ?>
                        </select>
                    </td>
                </tr>
                
                <tr class="vks_support audio">
                    <td align="left"><?= $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_AUDIO"]["NAME"] ?>:</td>
                    <td>
                        <select name="make_audio" id="make_audio">
                            <? foreach ($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_AUDIO"]["VALUES"] as $item) { ?>
                                <option value="<?= $item["ID"] ?>" <?= $arResult["Item"]["Make_audio"] == $item["ID"] ? "selected" : "" ?>><?= $item["VALUE"] ?></option>
                            <? } ?>
                        </select>
                    </td>
                </tr>

                <tr class="vks_support external">
                    <td align="left" style="vertical-align: top; padding-top: 18px !important;">Перечень участников (список):</td>
                    <td>
                        <textarea rows="7" cols="50" class="thema" type="text" name="members_list"><?=$arResult["Item"]["Members_list"]?></textarea>
                    </td>
                </tr>
           
                <tr class="vks_support audio video">
                    <td align="left">Выбор площадок, с которыми потребуется настроить связь (ЦАФК, ЦОКР):</td>
                    <td>
                        <select name="connection_list[]" id="connection_list" class="multi-select" multiple>
                            <?
                            asort($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CONNECTION_LIST"]["VALUES"]);
                            foreach ($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CONNECTION_LIST"]["VALUES"] as $item) { ?>
                                <option value="<?= $item["ID"] ?>" <?= key_exists($item["ID"], $arResult["Item"]["Connection_list"]) ? "selected" : "" ?>><?= $item["VALUE"] ?></option>
                                <?
                            } ?>
                        </select>
                        <script>
                            $('#connection_list').select2({
                                language: 'ru',
                                placeholder: "Выберите переговорную",
                            });
                            $('#connection_list option').mousedown(function (e) {
                                e.preventDefault();
                                var originalScrollTop = $(this).parent().scrollTop();
                                // console.log(originalScrollTop);
                                $(this).prop('selected', $(this).prop('selected') ? false : true);
                                var self = this;
                                $(this).parent().focus();
                                setTimeout(function () {
                                    $(self).parent().scrollTop(originalScrollTop);
                                }, 0);

                                return false;
                            });
                        </script>
                    </td>
                </tr>

                <tr class="vks_support audio video">
                    <td align="left">Выбор площадок, с которыми потребуется настроить связь (ТОФК):</td>

                    <? $partiTofks = [];
                    $rsParentSection = CIBlockSection::GetByID(609);
                    if ($arParentSection = $rsParentSection->GetNext()) {
                        $arFilter = array('%NAME' => "УФК", '!%NAME' => ["руководитель", "помощник"], 'IBLOCK_ID' => $arParentSection['IBLOCK_ID'], '>LEFT_MARGIN' => $arParentSection['LEFT_MARGIN'], '<RIGHT_MARGIN' => $arParentSection['RIGHT_MARGIN'], '>DEPTH_LEVEL' => $arParentSection['DEPTH_LEVEL']);
                        $rsSect = CIBlockSection::GetList(array('name' => 'asc'), $arFilter);

                        while ($arSect = $rsSect->GetNext()) {
                            $partiTofks[] = [
                                "VALUE" => $arSect["NAME"],
                                "ID" => $arSect["ID"],
                                "DEF" => "N"
                            ];
                        }
                    } ?>

                    <td>
                        <select name="partis_list_select[]" id="partis_list_select" multiple class="multi-select">
                            <? foreach ($partiTofks as $item) {?>
                                <option value="<?= $item["ID"] ?>" 
                                <?= in_array($item["ID"], $arResult["Item"]["Partis_list"]) ? "selected" : "" ?>><?= $item["VALUE"] ?></option>
                            <? } ?>
                        </select>
                        <div>
                            <input type="checkbox" id="selectAll" class="check">
                            <label for="selectAll">Выбрать все</label>
                        </div>
                    </td>
                    <script>
                        $("#partis_list_select").select2({
                            language: 'ru',
                            placeholder: "Выберите необходимые управления",
                        });

                        $("#selectAll").on('click', function () {
                            var select = document.getElementById("partis_list_select");
                            if ($("#selectAll").is(':checked')) {
                                $("#partis_list_select > option").prop("selected", "selected");
                                select.dispatchEvent(new Event('change'));
                            } else {
                                $("#partis_list_select > option").prop("selected", "");
                                select.dispatchEvent(new Event('change'));
                            }
                        });
                    </script>
                </tr>

                <tr class="vks_support">
                    <td align="left">Список площадок (файл):</td>
                    <td>
                        <? $APPLICATION->IncludeComponent(
                            "bitrix:main.file.input",
                            "",
                            array(
                                "INPUT_NAME" => "partis_file",
                                "MULTIPLE" => "Y",
                                "MODULE_ID" => "iblock",
                                "MAX_FILE_SIZE" => "",
                                "ALLOW_UPLOAD" => "A",
                                "ALLOW_UPLOAD_EXT" => "",
                                "INPUT_VALUE" => $arResult["Item"]['Partis_file'],
                            ),
                            false
                        ); ?>
                    </td>
                </tr>
                
            <script>
                window.onload = function () {
                    try {
               

                    } catch (e) {
                        console.log(e);
                    }
                };
            </script>
            </tbody>
        </table>
        <br>
        <input type="submit" name="save" value="<?= GetMessage("INTASK_C29T_SAVE") ?>" class="button_blue">
        <?= bitrix_sessid_post() ?>
    </form>
    <br/>
    <script language="JavaScript">
        RMR_CalcEndTime();
        RMR_RegularityChange("<?= (StrLen($arResult["Item"]["Regularity"]) <= 0 ? "NONE" : $arResult["Item"]["Regularity"]) ?>");
    </script>
    <?
}
?>
<div id="debug-result" style=""><?
    if ($debug) {
        $rsUsers = CUser::GetList($by = "last_name", $order = "asc", []);
        $namesArr = [];
        while ($arItem = $rsUsers->GetNext()) {
            $namesArr[] = $arItem["LAST_NAME"] . " " . $arItem["NAME"] . " " . $arItem["SECOND_NAME"] . " (" . $arItem["ID"] . ")";
        }
        debug($namesArr);
        debug($arResult["Item"]);
    } ?>
</div>

<div class="modal fade" id="warning_lks" tabindex="-1" role="dialog" aria-labelledby="warningTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="warningModalLongTitle" style="font-size: 16px; margin-left: 10px;">
                <?=$arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["NAME"]?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?
                    unset($infoList);
                    foreach ($arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["VALUES"] as $item) {
                        $itemIntermediate["Номер"] = $item["ID"];
                        $itemIntermediate["Название"] = $item["VALUE"];
                        $infoList[] = $itemIntermediate;
                    } 
                ?>
                    <div id="jsGrid"></div>
                    <script>                        
                        var informationList = <?=json_encode($infoList)?>;
                        var pathToAjax = "<?=str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);?>/ajax.php"; 
                        jsGrid.locale("ru");
                                    
                        $("#jsGrid").jsGrid({
                            width: "100%",
                            height: "377px",
                            data: informationList,                    
                            inserting: true,
                            editing: true,
                            sorting: true,
                            paging: true,
                            pageSize: 6,
                    
                            deleteConfirm: function(item) {
                                return "Информационный ресурс \"" + item["Номер"] + " - " + item["Название"] + "\" будет удалён. Вы уверены?";
                            },
                            onItemInserted: function(args) {
                                var thatGrid = this;
                                $.post(pathToAjax, { METHOD: '@INSERT', NUMBER: args.item["Номер"], NAME: args.item["Название"] }, function (data) {
                                    args.item["Номер"] = data.number;
                                    thatGrid.refresh();
                                    // console.log(data);
                                }, "json");
                            },
                            onItemUpdated: function(args) {
                                var thatGrid = this;
                                $.post(pathToAjax, { METHOD: '@UPDATE', NUMBER: args.previousItem["Номер"], NAME: args.item["Название"] }, function (data) {
                                    args.item["Номер"] = data.number;
                                    thatGrid.refresh();
                                    // console.log(data);
                                }, "json");
                            },
                            onItemDeleted: function(args) {
                                $.post(pathToAjax, { METHOD: '@DELETE', NUMBER: args.item["Номер"], NAME: args.item["Название"] }, function (data) {
                                    // console.log(data);
                                }, "json");
                            },
                    
                            fields: [
                                { name: "Номер", type: "number", width: 50 },
                                { name: "Название", type: "text", width: 150, validate: "required" },
                                { type: "control" }
                            ]
                        });
                        setTimeout(function() {                            
                            $('.jsgrid .jsgrid-mode-button').trigger('click');
                            $('.jsgrid-grid-body').css({'height': '247px', 'overflow': 'hidden'});
                            $('.jsgrid-grid-header.jsgrid-header-scrollbar').css({'overflow': 'hidden'});
                        }, 400);
                    </script>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Закрыть</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="warning_lks1" tabindex="-1" role="dialog" aria-labelledby="warningTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="warningModalLongTitle" style="font-size: 24px: ">Внимание!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p style="font-size: 20px;">В настоящее время информация о возможности проведения ВКС на площадках ЦАФК,
                    ЦОКР и ТОФК не обновляется в реальном времени. Просим уточнять возможность проведения
                    ВКС по телефону (ВТС 5238, 5024, 5613) перед бронированием.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Понятно</button>
            </div>
        </div>
    </div>
</div>
<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

$queryResult = array( "method" => $_POST["METHOD"], "number" => $_POST["NUMBER"], "name" => $_POST["NAME"] );

switch ($_POST["METHOD"]) {
    case '@INSERT':
        $ibpenum = new CIBlockPropertyEnum;
        $PropID = $ibpenum->Add(Array('PROPERTY_ID' => '346', 'VALUE' => $_POST["NAME"]));
        if ($PropID) $queryResult["number"] = $PropID;
        break;
    case '@UPDATE':
        $ibpenum = new CIBlockPropertyEnum;
        $ibpenum->Update($_POST["NUMBER"], Array("VALUE" => $_POST["NAME"]));
        break;
    case '@DELETE':
        CIBlockPropertyEnum::delete($_POST["NUMBER"]);
        break;
    default:
        $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);
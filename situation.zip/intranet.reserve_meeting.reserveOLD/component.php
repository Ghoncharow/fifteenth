<?if(!Defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!CModule::IncludeModule("intranet"))
    ShowError(GetMessage("EC_INTRANET_MODULE_NOT_INSTALLED"));
if (!CModule::IncludeModule("iblock"))
    ShowError(GetMessage("EC_IBLOCK_MODULE_NOT_INSTALLED"));


$iblockId = IntVal($arParams["IBLOCK_ID"]);

$arParams["PAGE_VAR"] = Trim($arParams["PAGE_VAR"]);
if (StrLen($arParams["PAGE_VAR"]) <= 0)
    $arParams["PAGE_VAR"] = "page";

$arParams["MEETING_VAR"] = Trim($arParams["MEETING_VAR"]);
if (StrLen($arParams["MEETING_VAR"]) <= 0)
    $arParams["MEETING_VAR"] = "meeting_id";

$arParams["ITEM_VAR"] = Trim($arParams["ITEM_VAR"]);
if (StrLen($arParams["ITEM_VAR"]) <= 0)
    $arParams["ITEM_VAR"] = "item_id";

$meetingId = IntVal($arParams["MEETING_ID"]);
if ($meetingId <= 0)
    $meetingId = IntVal($_REQUEST[$arParams["MEETING_VAR"]]);

$itemId = IntVal($arParams["ITEM_ID"]);
if ($itemId <= 0)
    $itemId = IntVal($_REQUEST[$arParams["ITEM_VAR"]]);

$arParams["PATH_TO_MEETING"] = Trim($arParams["PATH_TO_MEETING"]);
if (StrLen($arParams["PATH_TO_MEETING"]) <= 0)
    $arParams["PATH_TO_MEETING"] = HtmlSpecialCharsbx($APPLICATION->GetCurPage()."?".$arParams["PAGE_VAR"]."=meeting&".$arParams["MEETING_VAR"]."=#meeting_id#");

$arParams["PATH_TO_MEETING_LIST"] = Trim($arParams["PATH_TO_MEETING_LIST"]);
if (StrLen($arParams["PATH_TO_MEETING_LIST"]) <= 0)
    $arParams["PATH_TO_MEETING_LIST"] = HtmlSpecialCharsbx($APPLICATION->GetCurPage());

$arParams['NAME_TEMPLATE'] = $arParams['NAME_TEMPLATE'] ? $arParams['NAME_TEMPLATE'] : CSite::GetNameFormat(false);
$bUseLogin = $arParams['SHOW_LOGIN'] != "N" ? true : false;

//$arParams["SET_TITLE"] = ($arParams["SET_TITLE"] == "Y" ? "Y" : "N");
$arParams["SET_TITLE"] =  "Y";
$arParams["SET_NAVCHAIN"] = ($arParams["SET_NAVCHAIN"] == "Y" ? "Y" : "N");

if (!Is_Array($arParams["USERGROUPS_RESERVE"]))
{
    if (IntVal($arParams["USERGROUPS_RESERVE"]) > 0)
        $arParams["USERGROUPS_RESERVE"] = array($arParams["USERGROUPS_RESERVE"]);
    else
        $arParams["USERGROUPS_RESERVE"] = array();
}


$arResult["FatalError"] = "";

if (!CIBlockRights::UserHasRightTo($iblockId, $iblockId, 'element_read'))
    $arResult["FatalError"] .= GetMessage("INTS_NO_IBLOCK_PERMS").".";

include_once($_SERVER['DOCUMENT_ROOT']."/bitrix/components/bitrix/intranet.reserve_meeting/init.php");

$ar = __IRM_InitReservation($iblockId);

$arResult["ALLOWED_FIELDS"] = $ar["ALLOWED_FIELDS"];
$arResult["ALLOWED_ITEM_PROPERTIES"] = $ar["ALLOWED_ITEM_PROPERTIES"];

if ($arParams["SET_TITLE"] == "Y")
    $APPLICATION->SetTitle(GetMessage("INTASK_C36_PAGE_TITLE"));

if ($arParams["SET_NAVCHAIN"] == "Y")
    $APPLICATION->AddChainItem(GetMessage("INTASK_C36_PAGE_TITLE1"), CComponentEngine::MakePathFromTemplate($arParams["PATH_TO_MEETING_LIST"], array()));

if (!$GLOBALS["USER"]->IsAuthorized())
    $arResult["FatalError"] = GetMessage("INTASK_C29_NEED_AUTH").". ";
if (StrLen($arResult["FatalError"]) <= 0)
{
    if (!$GLOBALS["USER"]->IsAdmin()
        && Count(Array_Intersect($GLOBALS["USER"]->GetUserGroupArray(), $arParams["USERGROUPS_RESERVE"])) <= 0)
    {
        $arResult["FatalError"] = GetMessage("INTASK_C29_NO_RPERMS").". ";
    }
}


if (StrLen($arResult["FatalError"]) <= 0)
{
    $arSelectFields = array("IBLOCK_ID");
    foreach ($arResult["ALLOWED_FIELDS"] as $key => $value)
        $arSelectFields[] = $key;

    $dbMeeting = CIBlockSection::GetList(
        array(),
        array("ID" => $meetingId, "ACTIVE" => "Y", "IBLOCK_ID" => $iblockId),
        false,
        $arSelectFields
    );
    $arMeeting = $dbMeeting->GetNext();

    if (!$arMeeting)
        $arResult["FatalError"] = GetMessage("INAF_MEETING_NOT_FOUND")." ";
}


if (StrLen($arResult["FatalError"]) <= 0)
{
    $arItem = false;

    if ($itemId > 0)
    {
        $arSelectFields = array("ID", "NAME", "IBLOCK_ID", "CREATED_BY", "DATE_ACTIVE_FROM", "DATE_ACTIVE_TO", "DETAIL_TEXT",);
        foreach ($arResult["ALLOWED_ITEM_PROPERTIES"] as $key => $value)
            $arSelectFields[] = "PROPERTY_".$key;
        $dbElements = CIBlockElement::GetList(
            array(),
            array(
                "ACTIVE" => "Y",
                "IBLOCK_ID" => $iblockId,
                "SECTION_ID" => $meetingId,
                "ID" => $itemId,
            ),
            false,
            false,
            $arSelectFields
        );

        $arItem = $dbElements->GetNext();
        if (!$arItem)
            $arResult["FatalError"] .= GetMessage("INAF_ITEM_NOT_FOUND")." ";
    }
}


if (StrLen($arResult["FatalError"]) <= 0)
{
    if ($arItem)
    {
        if (!$GLOBALS["USER"]->IsAdmin() && $GLOBALS["USER"]->GetID() != $arItem["CREATED_BY"])
            $arResult["FatalError"] .= GetMessage("INTASK_C29_NO_RPERMS_MODIFY").". ";
    }
}


if (StrLen($arResult["FatalError"]) <= 0)
{
    $bVarsFromForm = false;
    if ($_SERVER["REQUEST_METHOD"] == "POST" && StrLen($_POST["save"]) > 0 && check_bitrix_sessid())
    {
        $errorMessage = "";

        $startDateV = $_REQUEST["start_date"];
        $startTimeV = $_REQUEST["start_time"];
        $endTimeV = $_REQUEST["end_time"];
        $timeoutTimeV = $_REQUEST["timeout_time"];
        $personsV = $_REQUEST["persons"];
        $members_listV = $_REQUEST["members_list"];
        $resTypeV = $_REQUEST["res_type"];
        $descriptionV = $_REQUEST["description"];
        $prepareRoomV = $_REQUEST["prepare_room"];

        $cafk = $_REQUEST["CAFK"];
        $resp = $_REQUEST["resp"];
        $ext_resp = $_REQUEST["ext_resp"];
        $chairman = $_REQUEST["chairman"];

        $department = $_REQUEST["department"];
        $other_avks = $_REQUEST["other_avks"];



        $presentation_file = $_REQUEST["presentation_file"];
        $members_file = $_REQUEST["members_file"];
        $events_plan = $_REQUEST["events_plan"];
        $seating_plan = $_REQUEST["seating_plan"];
        $partis_list = $_POST["partis_list_select"];
        $zafk_value = $_REQUEST["zafk_value"];
        $partis_file = $_REQUEST["partis_file"];


        $make_video = $_REQUEST["make_video"];
        $make_audio = $_REQUEST["make_audio"];
        $connection_list = $_POST["connection_list"];
        $information_list = $_POST["information_list"];
        AddMessage2Log("HEADS<script>console.log(".json_encode($connection_list).");</script><br>", '', 0);


        $cafkText = $_REQUEST["CAFK_text"];
        $deptText = $_REQUEST["dept_text"];

        $respText = $_REQUEST["resp_text"];
        $chairmanText = $_REQUEST["chairman_text"];

        $option_1V = $_REQUEST["option_1"];
        $option_2V = $_REQUEST["option_2"];
        // AddMessage2Log("HEADS<script>console.log(".json_encode($option_2V).");</script><br>", '', 0);
        $option_3V = $_REQUEST["option_3"];
        $doneV = $_REQUEST["done"];

        $nameV = $_REQUEST["name"];

        $regularityV = $_REQUEST["regularity"];
        $regularityCountV = $_REQUEST["regularity_count"];
        $regularityEndV = $_REQUEST["regularity_end"];
        $regularityAdditionalV = $_REQUEST["regularity_additional"];

        if (StrLen($startDateV) <= 0)
        {
            $errorMessage .= GetMessage("INTASK_C29_EMPTY_DATE").". ";
        }
        else
        {
            $startDateVTmp = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), MakeTimeStamp($startDateV, FORMAT_DATE));
            if ($startDateVTmp != $startDateV)
                $errorMessage .= Str_Replace("#FORMAT#", $GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), GetMessage("INTASK_C29_WRONG_DATE")).". ";
        }

        $numberOfWeekDay = date("N", (new DateTime($startDateV))->getTimestamp());
        if ($numberOfWeekDay == '6' || $numberOfWeekDay == '7')
        {
            $errorMessage .= GetMessage("INTASK_C29_WEEKEND_DAY").". ";
        }

        if (StrLen($zafk_value) <= 0)
        {
            $errorMessage .= GetMessage("INTASK_C29_EMPTY_DEPT").". ";
        }

        if (StrLen($startTimeV) <= 0)
        {
            $errorMessage .= GetMessage("INTASK_C29_EMPTY_TIME").". ";
        }
        else
        {
            if (IsAmPmMode())
            {
                $startTimeV = str_replace(':', ' ', $startTimeV);
                $arStartTimeVTmp = Explode(" ", $startTimeV);
                if ($arStartTimeVTmp[0] < 12 && $arStartTimeVTmp[2] == 'pm')
                {
                    $arStartTimeVTmp[0] += 12;
                }
                elseif ($arStartTimeVTmp[0] == 12 && $arStartTimeVTmp[2] == 'am')
                {
                    $arStartTimeVTmp[0] = 0;
                }
                unset($arStartTimeVTmp[2]);
            }
            else
            {
                $arStartTimeVTmp = Explode(":", $startTimeV);
            }
            if (Count($arStartTimeVTmp) != 2 || IntVal($arStartTimeVTmp[0]) > 23 || IntVal($arStartTimeVTmp[0]) < 0
                || $arStartTimeVTmp[1] != "00" && $arStartTimeVTmp[1] != "30")
                $errorMessage .= Str_Replace("#FORMAT#", GetMessage("INTASK_C29_HM"), GetMessage("INTASK_C29_WRONG_TIME")).". ";
        }

        if (StrLen($timeoutTimeV) <= 0)
        {
            $errorMessage .= GetMessage("INTASK_C29_EMPTY_DURATION").". ";
        }
        else
        {
            $arTimeoutTimeVTmp = Explode(":", $timeoutTimeV);
            $arEndTimeVTmp = Explode(":", $endTimeV);
            if (Count($arTimeoutTimeVTmp) != 2 || IntVal($arTimeoutTimeVTmp[0]) > 23 || IntVal($arTimeoutTimeVTmp[0]) < 0
                || IntVal($arTimeoutTimeVTmp[1]) > 59 || IntVal($arTimeoutTimeVTmp[1]) < 0)
                $errorMessage .= GetMessage("INTASK_C29_WRONG_DURATION").". ";
        }

        if (StrLen($nameV) <= 0)
            $errorMessage .= GetMessage("INTASK_C29_EMPTY_NAME").". ";
        else if(StrLen($nameV) > 300)
            $errorMessage .= GetMessage("INTASK_C29_NAME_OVERFLOW").". ";
		
        if (($personsV*1) > $arMeeting["UF_PLACE"])
            $errorMessage .= "Допустимое количество участников не более {$arMeeting["UF_PLACE"]}";
        else if(($personsV*1) <= 0)
            $errorMessage .= "Количество мест не может быть меньше 2 или больше 30. ";
            
        if (empty($information_list)) $errorMessage .= "Не выбраны один или несколько пунктов перечня используемых информационных ресурсов. ";

        if (StrLen($errorMessage) <= 0)
        {
            $regularityV = StrToUpper($regularityV);
            if (!In_Array($regularityV, array("NONE", "WEEKLY", "DAILY", "MONTHLY", "YEARLY")))
                $regularityV = "NONE";

            if ($regularityV != "NONE")
            {
                $regularityCountV = IntVal($regularityCountV);
                if ($regularityCountV <= 0)
                    $regularityCountV = 1;

                if (StrLen($regularityEndV) > 0)
                {
                    $regularityEndVTmp = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), MakeTimeStamp($regularityEndV, FORMAT_DATE));
                    if ($regularityEndVTmp != $regularityEndV)
                        $regularityEndV = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), 2145938400);
                }
                else
                {
                    $regularityEndV = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), 2145938400);
                }

                $regularityAdditionalVString = "";
                if ($regularityV == "WEEKLY" && Is_Array($regularityAdditionalV) && Count($regularityAdditionalV) > 0)
                {
                    foreach ($regularityAdditionalV as $v)
                    {
                        $v = IntVal($v);
                        if ($v >= 0 && $v <= 6)
                        {
                            if (StrLen($regularityAdditionalVString) > 0)
                                $regularityAdditionalVString .= ",";
                            $regularityAdditionalVString .= $v;
                        }
                    }
                }
            }
            else
            {
                $regularityCountV = "";
                $regularityEndV = "";
                $regularityAdditionalV = "";
                $regularityAdditionalVString = "";
            }
        }

        if (StrLen($errorMessage) <= 0)
        {
            if ($regularityV == "NONE")
            {
                $t = MakeTimeStamp($startDateV, FORMAT_DATE);
                $fromDateTime = MkTime($arStartTimeVTmp[0], $arStartTimeVTmp[1], 0, Date("m", $t), Date("d", $t), Date("Y", $t));
                $toDateTime = MkTime($arEndTimeVTmp[0], $arEndTimeVTmp[1], 0, Date("m", $t), Date("d", $t), Date("Y", $t));

                $arFilter = array(
                    "ACTIVE" => "Y",
                    "IBLOCK_ID" => $arMeeting["IBLOCK_ID"],
                    "SECTION_ID" => $arMeeting["ID"],
                    "<DATE_ACTIVE_FROM" => Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATETIME), $toDateTime),
                    ">DATE_ACTIVE_TO" => Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATETIME), $fromDateTime),
                    "PROPERTY_PERIOD_TYPE" => "NONE",
                );

                if ($arItem)
                    $arFilter["!ID"] = $arItem["ID"];

                $dbElements = CIBlockElement::GetList(
                    array("DATE_ACTIVE_FROM" => "ASC"),
                    $arFilter,
                    false,
                    false,
                    array()
                );
                while ($arElements = $dbElements->GetNext())
                {
                    $ft1 = MakeTimeStamp($arElements["DATE_ACTIVE_FROM"], FORMAT_DATETIME);
                    $ft2 = MakeTimeStamp($arElements["DATE_ACTIVE_TO"], FORMAT_DATETIME);

                    $errorMessage .= Str_Replace(
                        array("#TIME1#", "#TIME2#", "#RES#"),
                        array("<b>".Date("H:i", $ft1)."</b> ".Date("d.m", $ft1), "<b>".Date("H:i", $ft2)."</b> ".Date("d.m", $ft2), $arElements["NAME"]),
                        GetMessage("INTASK_C29_CONFLICT").". "
                    );
                }

                $arPeriodicElements = __IRM_SearchPeriodic($fromDateTime, $toDateTime, $arMeeting["IBLOCK_ID"], $arMeeting["ID"], $arItem ? $arItem["ID"] : 0);
                foreach ($arPeriodicElements as $pe)
                {
                    $errorMessage .= Str_Replace(
                        array("#TIME1#", "#TIME2#", "#RES#"),
                        array("<b>".Date("H:i", $pe["DATE_ACTIVE_FROM_TIME"])."</b> ".Date("d.m", $pe["DATE_ACTIVE_FROM_TIME"]), "<b>".Date("H:i", $pe["DATE_ACTIVE_TO_TIME"])."</b> ".Date("d.m", $pe["DATE_ACTIVE_TO_TIME"]), $pe["NAME"]),
                        GetMessage("INTASK_C29_CONFLICT").". "
                    );
                }
            }
            else
            {
                $t = MakeTimeStamp($startDateV, FORMAT_DATE);
                $fromDateTime = MkTime($arStartTimeVTmp[0], $arStartTimeVTmp[1], 0, Date("m", $t), Date("d", $t), Date("Y", $t));
                $toDateTime = MkTime($arEndTimeVTmp[0], $arEndTimeVTmp[1], 0, Date("m", $t), Date("d", $t), Date("Y", $t));

                $regularityLength = $toDateTime - $fromDateTime;
                $toDateTime = MakeTimeStamp($regularityEndV, FORMAT_DATE);
            }
        }

        if (StrLen($errorMessage) <= 0)
        {

            $propValues = array(
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_PERSONS"]["ID"] => array(
                    $personsV
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MEMBERS_LIST"]["ID"] => array(
                    $members_listV
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_RES_TYPE"]["ID"] => array(
                    $resTypeV
                ),

                //newest
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_DEPARTMENT"]["ID"] => array(
                    $department
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_OTHER_AVKS"]["ID"] => array(
                    $other_avks
                ),
//
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_PRESENTATION_FILE"]["ID"] => $presentation_file,
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MEMBERS_FILE"]["ID"] => $members_file,                
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_EVENTS_PLAN"]["ID"] => $events_plan,
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_SEATING_PLAN"]["ID"] => $seating_plan,                
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_PARTIS_LIST"]["ID"] => $partis_list,

                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_ZAFK_VALUE"]["ID"] => array(
                    $zafk_value
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_PARTIS_FILE"]["ID"] =>
                    $partis_file
                ,
                //
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_VIDEO"]["ID"] => array(
                    $make_video
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_MAKE_AUDIO"]["ID"] => array(
                    $make_audio
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CONNECTION_LIST"]["ID"] => $connection_list,
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_INFORMATION_LIST"]["ID"] => $information_list,

                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CAFK"]["ID"] => array(
                    $chairman
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_RESP"]["ID"] => array(
                    $resp
                ),

                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CHAIRMAN"]["ID"] => array(
                    $chairman
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CAFK_TEXT"]["ID"] => array(
                    $cafkText
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_DEPT_TEXT"]["ID"] => array(
                    $deptText
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_RESP_TEXT"]["ID"] => array(
                    $respText
                ),

                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_CHAIRMAN_TEXT"]["ID"] => array(
                    $chairmanText
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_EXT_RESP"]["ID"] => array(
                    $ext_resp
                ),

                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_PREPARE_ROOM"]["ID"] => array(
                    $prepareRoomV
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_OPTION_1"]["ID"] => array(
                    $option_1V
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_OPTION_2"]["ID"] => array(
                    $option_2V
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_OPTION_3"]["ID"] => array(
                    $option_3V
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["UF_DONE"]["ID"] => array(
                    $doneV
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["PERIOD_TYPE"]["ID"] => array(
                    $regularityV
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["PERIOD_COUNT"]["ID"] => array(
                    $regularityCountV
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["EVENT_LENGTH"]["ID"] => array(
                    $regularityLength
                ),
                $arResult["ALLOWED_ITEM_PROPERTIES"]["PERIOD_ADDITIONAL"]["ID"] => array(
                    $regularityAdditionalVString
                ),
            );
            $arFields = array(
                "NAME" => $nameV,
                "DATE_ACTIVE_FROM" => Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATETIME), $fromDateTime),
                "DATE_ACTIVE_TO" => Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATETIME), $toDateTime),
                "CREATED_BY" => $GLOBALS["USER"]->GetID(),
                "DETAIL_TEXT" => $descriptionV,
                "PROPERTY_VALUES" => $propValues,
                "ACTIVE" => "Y",
            );
            $iblockElementObject = new CIBlockElement;
            if ($arItem)
            {
                $res = $iblockElementObject->Update($arItem["ID"], $arFields);
            }
            else
            {
                $arFields["IBLOCK_ID"] = $arMeeting["IBLOCK_ID"];
                $arFields["IBLOCK_SECTION_ID"] = $arMeeting["ID"];

                $idTmp = $iblockElementObject->Add($arFields);
                $res = ($idTmp > 0);
            }

            if (!$res) {
                $errorMessage .= $iblockElementObject->LAST_ERROR." ";
            } else {
                CEventCalendar::clearEventsCache($arMeeting["IBLOCK_ID"]);
                if (IsModuleInstalled("im") && CModule::IncludeModule("im")) {
                    $arMessageFieldsToChat = array(
                        // получатель
                       "TO_USER_ID" => '1887',
                       // отправитель
                       "FROM_USER_ID" => $GLOBALS["USER"]->GetID(), 
                       // тип уведомления
                       "NOTIFY_TYPE" => IM_NOTIFY_FROM, 
                       // модуль запросивший отправку уведомления
                       "NOTIFY_MODULE" => "calendar",
                       // текст уведомления на сайте
                       "NOTIFY_MESSAGE" => 'В ситуационном центре казначейства планируется проведение мероприятия "'.$nameV.'". '."Время начала: $startDateV в $startTimeV.", 
                       // текст уведомления для отправки на почту (или XMPP), если различий нет - не задаем параметр
                       "NOTIFY_MESSAGE_OUT" => 'В ситуационном центре казначейства планируется проведение мероприятия "'.$nameV.'". '."Время начала: $startDateV в $startTimeV." 
                    );
                    // Кузнецов Константин Леонтьевич user/1887/
                    CIMNotify::Add($arMessageFieldsToChat);
                    if (!empty($option_2V)) {
                        $arMessageFieldsToChat["TO_USER_ID"] = '3270';
                        // Серенко Виталий Алексеевич user/3270/
                        CIMNotify::Add($arMessageFieldsToChat);
                    }
                    if (!empty($option_1V)) {
                        $arMessageFieldsToChat["TO_USER_ID"] = '1742';
                        // Бахарев Андрей Анатольевич user/1742/
                        CIMNotify::Add($arMessageFieldsToChat);
                        $arMessageFieldsToChat["TO_USER_ID"] = '2830';
                        // Пономарев Алексей Валерьевич user/2830/
                        CIMNotify::Add($arMessageFieldsToChat);
                    }
                }
            }
                
        }

        if (StrLen($errorMessage) <= 0)
        {
            $p = CComponentEngine::MakePathFromTemplate($arParams["PATH_TO_MEETING"], array("meeting_id" => $arMeeting["ID"]));
            $p = $p.(StrPos($p, "?") === false ? "?" : "&")."week_start=".Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), $fromDateTime);
            //LocalRedirect($p);
        }
        else
        {
            $arResult["ErrorMessage"] .= $errorMessage;
            $bVarsFromForm = true;

            $arResult["Item"]["StartDate"] = HtmlSpecialCharsbx($_REQUEST["start_date"]);
            $arResult["Item"]["StartTime"] = HtmlSpecialCharsbx($_REQUEST["start_time"]);
            $arResult["Item"]["TimeoutTime"] = HtmlSpecialCharsbx($_REQUEST["timeout_time"]);
            $arResult["Item"]["Name"] = HtmlSpecialCharsbx($_REQUEST["name"]);
            $arResult["Item"]["Persons"] = HtmlSpecialCharsbx($_REQUEST["persons"]);
            $arResult["Item"]["Members_list"] = HtmlSpecialCharsbx($_REQUEST["members_list"]);
            $arResult["Item"]["ResType"] = HtmlSpecialCharsbx($_REQUEST["res_type"]);

            $arResult["Item"]["CAFK"] = HtmlSpecialCharsbx($_REQUEST["cafk"]);
            $arResult["Item"]["Resp"] = HtmlSpecialCharsbx($_REQUEST["resp"]);
            $arResult["Item"]["Ext_resp"] = HtmlSpecialCharsbx($_REQUEST["ext_resp"]);
            $arResult["Item"]["Chairman"] = HtmlSpecialCharsbx($_REQUEST["chairman"]);

            $arResult["Item"]["Department"] = HtmlSpecialCharsbx($_REQUEST["department"]);
            $arResult["Item"]["Other_avks"] = HtmlSpecialCharsbx($_REQUEST["other_avks"]);
            $arResult["Item"]["Presentation_file"] = $_REQUEST["presentation_file"];
            $arResult["Item"]["Members_file"] = $_REQUEST["members_file"];
            $arResult["Item"]["Events_plan"] = $_REQUEST["events_plan"];
            $arResult["Item"]["Seating_plan"] = $_REQUEST["seating_plan"];
            $arResult["Item"]["Partis_list"] = HtmlSpecialCharsbx($_POST["partis_list_select"]);
            $arResult["Item"]["Zafk_value"] = HtmlSpecialCharsbx($_REQUEST["zafk_value"]);
            $arResult["Item"]["Partis_file"] = $_REQUEST["partis_file"];




            $arResult["Item"]["Make_video"] = HtmlSpecialCharsbx($_REQUEST["make_video"]);
            $arResult["Item"]["Make_audio"] = HtmlSpecialCharsbx($_REQUEST["make_audio"]);
            $arResult["Item"]["Connection_list"] = HtmlSpecialCharsbx($_POST["connection_list"]);
            $arResult["Item"]["Information_list"] = HtmlSpecialCharsbx($_POST["information_list"]);


            $arResult["Item"]["CAFK_text"] = HtmlSpecialCharsbx($_REQUEST["CAFK_text"]);
            $arResult["Item"]["Dept_text"] = HtmlSpecialCharsbx($_REQUEST["dept_text"]);
            $arResult["Item"]["Resp_text"] = HtmlSpecialCharsbx($_REQUEST["resp_text"]);
            $arResult["Item"]["Chairman_text"] = HtmlSpecialCharsbx($_REQUEST["chairman_text"]);

            $arResult["Item"]["Description"] = HtmlSpecialCharsbx($_REQUEST["description"]);
            $arResult["Item"]["PrepareRoom"] = HtmlSpecialCharsbx($_REQUEST["prepare_room"]);

            $arResult["Item"]["Option_1"] = HtmlSpecialCharsbx($_REQUEST["option_1"]);
            $arResult["Item"]["Option_2"] = HtmlSpecialCharsbx($_REQUEST["option_2"]);
            $arResult["Item"]["Option_3"] = HtmlSpecialCharsbx($_REQUEST["option_3"]);
            $arResult["Item"]["Done"] = HtmlSpecialCharsbx($_REQUEST["done"]);
            $arResult["Item"]["Regularity"] = HtmlSpecialCharsbx($_REQUEST["regularity"]);
            $arResult["Item"]["RegularityCount"] = HtmlSpecialCharsbx($_REQUEST["regularity_count"]);
            $arResult["Item"]["RegularityEnd"] = HtmlSpecialCharsbx($_REQUEST["regularity_end"]);
            $arResult["Item"]["RegularityAdditional"] = HtmlSpecialCharsbx(Implode(",", $_REQUEST["regularity_additional"]));
        }
    }
}


if (StrLen($arResult["FatalError"]) <= 0)
{
    $arResult["MEETING"] = $arMeeting;

    if ($arParams["SET_TITLE"] == "Y")
        $APPLICATION->SetTitle(GetMessage("INTASK_C36_PAGE_TITLE").": ".$arMeeting["NAME"]);

    if ($arParams["SET_NAVCHAIN"] == "Y")
        $APPLICATION->AddChainItem($arMeeting["NAME"]);

    if (!$bVarsFromForm)
    {
        //        state:
        if ($arItem)
        {
            $ft1 = MakeTimeStamp($arItem["DATE_ACTIVE_FROM"], FORMAT_DATETIME);
            $ft2 = MakeTimeStamp($arItem["DATE_ACTIVE_TO"], FORMAT_DATETIME);

            $arResult["Item"]["StartDate"] = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), $ft1);
            $arResult["Item"]["StartTime"] = Date("H:i", $ft1);

            $arResult["Item"]["Name"] = $arItem["NAME"];
            $arResult["Item"]["Persons"] = $arItem["PROPERTY_UF_PERSONS_VALUE"];
            $arResult["Item"]["Members_list"] = $arItem["PROPERTY_UF_MEMBERS_LIST_VALUE"];
            $arResult["Item"]["ResType"] = $arItem["PROPERTY_UF_RES_TYPE_ENUM_ID"];

            $arResult["Item"]["CAFK"] = $arItem["PROPERTY_UF_CAFK_ENUM_ID"];
            $arResult["Item"]["Resp"] = $arItem["PROPERTY_UF_RESP_ENUM_ID"];
            $arResult["Item"]["Chairman"] = $arItem["PROPERTY_UF_CHAIRMAN_ENUM_ID"];
            $arResult["Item"]["Ext_resp"] = $arItem["PROPERTY_UF_EXT_RESP_VALUE"];

            $arResult["Item"]["Department"] = $arItem["PROPERTY_UF_DEPARTMENT_ENUM_ID"];
            $arResult["Item"]["Other_avks"] = $arItem["PROPERTY_UF_OTHER_AVKS_ENUM_ID"];

            $arResult["Item"]["Presentation_file"] = $arItem["PROPERTY_UF_PRESENTATION_FILE_VALUE"];
            $arResult["Item"]["Members_file"] = $arItem["PROPERTY_UF_MEMBERS_FILE_VALUE"];
            $arResult["Item"]["Events_plan"] = $arItem["PROPERTY_UF_EVENTS_PLAN_VALUE"];
            $arResult["Item"]["Seating_plan"] = $arItem["PROPERTY_UF_SEATING_PLAN_VALUE"];
            $arResult["Item"]["Partis_list"] = $arItem["PROPERTY_UF_PARTIS_LIST_VALUE"];
            $arResult["Item"]["Zafk_value"] = $arItem["PROPERTY_UF_ZAFK_VALUE_VALUE"];
            $arResult["Item"]["Partis_file"] = $arItem["PROPERTY_UF_PARTIS_FILE_VALUE"];

            $arResult["Item"]["Make_video"] = $arItem["PROPERTY_UF_MAKE_VIDEO_ENUM_ID"];
            $arResult["Item"]["Make_audio"] = $arItem["PROPERTY_UF_MAKE_AUDIO_ENUM_ID"];

            $arResult["Item"]["Connection_list"] = $arItem["PROPERTY_UF_CONNECTION_LIST_VALUE"];
            $arResult["Item"]["Information_list"] = $arItem["PROPERTY_UF_INFORMATION_LIST_VALUE"];


            $arResult["Item"]["CAFK_text"] = $arItem["PROPERTY_UF_CAFK_TEXT_VALUE"];
            $arResult["Item"]["Dept_text"] = $arItem["PROPERTY_UF_DEPT_TEXT_VALUE"];
            $arResult["Item"]["Resp_text"] = $arItem["PROPERTY_UF_RESP_TEXT_VALUE"];
            $arResult["Item"]["Chairman_text"] = $arItem["PROPERTY_UF_CHAIRMAN_TEXT_VALUE"];



            $arResult["Item"]["Description"] = $arItem["DETAIL_TEXT"];
            $arResult["Item"]["PrepareRoom"] = $arItem["PROPERTY_UF_PREPARE_ROOM_VALUE"];

            $arResult["Item"]["Option_1"] = $arItem["PROPERTY_UF_OPTION_1_VALUE"];
            $arResult["Item"]["Option_2"] = $arItem["PROPERTY_UF_OPTION_2_VALUE"];
            $arResult["Item"]["Option_3"] = $arItem["PROPERTY_UF_OPTION_3_VALUE"];
            $arResult["Item"]["Done"] = $arItem["PROPERTY_UF_DONE_VALUE"];

            $arResult["Item"]["Regularity"] = $arItem["PROPERTY_PERIOD_TYPE_VALUE"];
            $arResult["Item"]["RegularityCount"] = $arItem["PROPERTY_PERIOD_COUNT_VALUE"];
            $arResult["Item"]["RegularityAdditional"] = $arItem["PROPERTY_PERIOD_ADDITIONAL_VALUE"];

            if ($arItem["PROPERTY_PERIOD_TYPE_VALUE"] == "NONE")
            {
                $ft = ($ft2 - $ft1) / 3600.0;
                $dt = ($ft - IntVal($ft))*60;
                $dt = ($dt < 10) ? '0'.$dt : $dt;
                $arResult["Item"]["TimeoutTime"] = IntVal($ft).':'.$dt;
            }
            else
            {
                $ft = $arItem["PROPERTY_EVENT_LENGTH_VALUE"] / 3600.0;
                $dt = ($ft - IntVal($ft))*60;
                $dt = ($dt < 10) ? '0'.$dt : $dt;
                $arResult["Item"]["TimeoutTime"] = IntVal($ft).':'.$dt;

                $arResult["Item"]["RegularityEnd"] = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE), $ft2);
            }
        }
        else
        {
            $arResult["Item"]["StartDate"] = HtmlSpecialCharsbx($_REQUEST["start_date"]);
            if (StrLen($arResult["Item"]["StartDate"]) <= 0)
                $arResult["Item"]["StartDate"] = Date($GLOBALS["DB"]->DateFormatToPHP(FORMAT_DATE));

            $arResult["Item"]["StartTime"] = HtmlSpecialCharsbx($_REQUEST["start_time"]);
            $arResult["Item"]["TimeoutTime"] = HtmlSpecialCharsbx($_REQUEST["timeout_time"]);
            $arResult["Item"]["Name"] = HtmlSpecialCharsbx($_REQUEST["name"]);
            $arResult["Item"]["Persons"] = HtmlSpecialCharsbx($_REQUEST["persons"]);
            $arResult["Item"]["Members_list"] = HtmlSpecialCharsbx($_REQUEST["members_list"]);
            $arResult["Item"]["ResType"] = HtmlSpecialCharsbx($_REQUEST["res_type"]);

            $arResult["Item"]["CAFK"] = HtmlSpecialCharsbx($_REQUEST["cafk"]);
            $arResult["Item"]["Resp"] = HtmlSpecialCharsbx($_REQUEST["resp"]);
            $arResult["Item"]["Ext_resp"] = HtmlSpecialCharsbx($_REQUEST["ext_resp"]);
            $arResult["Item"]["Chairman"] = HtmlSpecialCharsbx($_REQUEST["chairman"]);

            $arResult["Item"]["Department"] = HtmlSpecialCharsbx($_REQUEST["department"]);
            $arResult["Item"]["Other_avks"] = HtmlSpecialCharsbx($_REQUEST["other_avks"]);

            $arResult["Item"]["Presentation_file"] = $_REQUEST["presentation_file"];
            $arResult["Item"]["Members_file"] = $_REQUEST["members_file"];
            $arResult["Item"]["Events_plan"] = $_REQUEST["events_plan"];
            $arResult["Item"]["Seating_plan"] = $_REQUEST["seating_plan"];
            $arResult["Item"]["Partis_list"] = HtmlSpecialCharsbx($_POST["partis_list_select"]);
            $arResult["Item"]["Zafk_value"] = HtmlSpecialCharsbx($_REQUEST["zafk_value"]);
            $arResult["Item"]["Partis_file"] = $_REQUEST["partis_file"];

            $arResult["Item"]["Make_video"] = HtmlSpecialCharsbx($_REQUEST["make_video"]);
            $arResult["Item"]["Make_audio"] = HtmlSpecialCharsbx($_REQUEST["make_audio"]);
            $arResult["Item"]["Connection_list"] = HtmlSpecialCharsbx($_POST["connection_list"]);
            $arResult["Item"]["Information_list"] = HtmlSpecialCharsbx($_POST["information_list"]);

            $arResult["Item"]["CAFK_text"] = HtmlSpecialCharsbx($_REQUEST["CAFK_text"]);
            $arResult["Item"]["Dept_text"] = HtmlSpecialCharsbx($_REQUEST["dept_text"]);
            $arResult["Item"]["Resp_text"] = HtmlSpecialCharsbx($_REQUEST["resp_text"]);
            $arResult["Item"]["Chairman_text"] = HtmlSpecialCharsbx($_REQUEST["chairman_text"]);

            $arResult["Item"]["Description"] = HtmlSpecialCharsbx($_REQUEST["description"]);
            $arResult["Item"]["PrepareRoom"] = HtmlSpecialCharsbx($_REQUEST["prepare_room"]);

            $arResult["Item"]["Option_1"] = HtmlSpecialCharsbx($_REQUEST["option_1"]);
            $arResult["Item"]["Option_3"] = HtmlSpecialCharsbx($_REQUEST["option_3"]);
            $arResult["Item"]["Option_2"] = HtmlSpecialCharsbx($_REQUEST["option_2"]);
            $arResult["Item"]["Done"] = HtmlSpecialCharsbx($_REQUEST["done"]);

            $arResult["Item"]["Regularity"] = HtmlSpecialCharsbx($_REQUEST["regularity"]);
            $arResult["Item"]["RegularityCount"] = HtmlSpecialCharsbx($_REQUEST["regularity_count"]);
            $arResult["Item"]["RegularityEnd"] = HtmlSpecialCharsbx($_REQUEST["regularity_end"]);
            $arResult["Item"]["RegularityAdditional"] = HtmlSpecialCharsbx($_REQUEST["regularity_additional"]);
            if (StrLen($arResult["Item"]["RegularityAdditional"]) <= 0)
            {
                $z = Date("w", MakeTimeStamp($arResult["Item"]["StartDate"], FORMAT_DATE));
                $arResult["Item"]["RegularityAdditional"] = ($z == 0 ? 6 : $z - 1);
            }
        }
    }
    //var_dump($arResult['Item']['StartTime']);



    if ($arItem)
    {
        $arResult["Item"]["Author"] = "-";
        $dbUser = CUser::GetByID($arItem["CREATED_BY"]);
        if ($arUser = $dbUser->GetNext())
        {
            $arResult["Item"]["Author_ID"] = $arUser["ID"];
            $arResult["Item"]["Author"] = CUser::FormatName($arParams['NAME_TEMPLATE'], $arUser, $bUseLogin);
            $arResult["Item"]["Author_NAME"] = $arUser["NAME"];
            $arResult["Item"]["Author_LAST_NAME"] = $arUser["LAST_NAME"];
            $arResult["Item"]["Author_SECOND_NAME"] = $arUser["SECOND_NAME"];
            $arResult["Item"]["Author_LOGIN"] = $arUser["LOGIN"];
        }
    }
    else {
        $arResult["Item"]["Author_ID"] = $GLOBALS["USER"]->GetID();
        $arResult["Item"]["Author_NAME"] = $GLOBALS["USER"]->GetFirstName();
        $arResult["Item"]["Author_LAST_NAME"] = $GLOBALS["USER"]->GetLastName();
        $arResult["Item"]["Author_SECOND_NAME"] = $GLOBALS["USER"]->GetParam("SECOND_NAME");
        $arResult["Item"]["Author_LOGIN"] = $GLOBALS["USER"]->GetLogin();
        $arTmpUser = array(
            "NAME" => $arResult["Item"]["Author_NAME"],
            "LAST_NAME" => $arResult["Item"]["Author_LAST_NAME"],
            "SECOND_NAME" => $arResult["Item"]["Author_SECOND_NAME"],
            "LOGIN" => $arResult["Item"]["Author_LOGIN"],
        );
        $arResult["Item"]["Author"] = CUser::FormatName($arParams['NAME_TEMPLATE'], $arTmpUser, $bUseLogin);
    }


    //state:
    if(strlen($p) > 0){

        if(!isset($_GET['change']) && isset($_GET['create'])){ // когда создаем
            LocalRedirect($p."&create=Y");
        }
        else {
            LocalRedirect($p."&change=Y"."&item_id=".$_GET['item_id']);
        }
    }

}



$this->IncludeComponentTemplate();

<?
$MESS ['INTDT_GRAPH'] = "Schedule";
$MESS ['INTDT_NO_TASKS'] = "No meeting rooms";
$MESS ['INTST_CLOSE'] = "Close";
$MESS ['INTST_FOLDER_NAME'] = "Folder Name";
$MESS ['INTST_DELETE'] = "Delete";
$MESS ['INTST_SAVE'] = "Save";
$MESS ['INTDT_ACTIONS'] = "Actions";
$MESS ['INTST_CANCEL'] = "Cancel";
$MESS ['INTASK_C23T_LOAD'] = "Loading...";
?>
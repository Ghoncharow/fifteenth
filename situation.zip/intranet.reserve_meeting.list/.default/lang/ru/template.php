<?
$MESS ['INTDT_GRAPH'] = "График";
$MESS ['INTDT_NO_TASKS'] = "Переговорных нет";
$MESS ['INTST_CLOSE'] = "Закрыть";
$MESS ['INTST_FOLDER_NAME'] = "Название папки";
$MESS ['INTST_DELETE'] = "Удалить";
$MESS ['INTST_SAVE'] = "Сохранить";
$MESS ['INTDT_ACTIONS'] = "Действия";
$MESS ['INTST_CANCEL'] = "Отмена";
$MESS ['INTASK_C23T_LOAD'] = "Загрузка...";
?>
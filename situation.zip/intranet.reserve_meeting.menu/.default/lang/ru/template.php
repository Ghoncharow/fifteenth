<?
$MESS ['ITSRM1_MEETING_LIST_DESCR'] = "Перейти в список переговорных";
$MESS ['ITSRM1_MEETING_LIST'] = "Список переговорных";
$MESS ['ITSRM1_MEETING_SEARCH_DESCR'] = "Перейти в поиск переговорных";
$MESS ['ITSRM1_MEETING_SEARCH'] = "Поиск переговорных";
$MESS ['INTASK_C27T_RESERVE_TITLE'] = "Забронировать переговорную";
$MESS ['INTASK_C27T_RESERVE'] = "Забронировать";
$MESS ['INTASK_C27T_GRAPH_TITLE'] = "График резервирования переговорной";
$MESS ['INTASK_C27T_GRAPH'] = "График";
$MESS ['INTASK_C27T_EDIT_TITLE'] = "Изменить параметры переговорной";
$MESS ['INTASK_C27T_EDIT'] = "Изменить переговорную";
$MESS ['INTASK_C27T_CRAETE_TITLE'] = "Создать новую переговорную";
$MESS ['INTASK_C27T_CREATE'] = "Создать переговорную";
?>
<?
$MESS ['ITSRM1_MEETING_LIST_DESCR'] = "View All Meeting Rooms";
$MESS ['ITSRM1_MEETING_LIST'] = "Meeting Rooms";
$MESS ['ITSRM1_MEETING_SEARCH_DESCR'] = "Search Meeting Rooms";
$MESS ['ITSRM1_MEETING_SEARCH'] = "Search Meeting Rooms";
$MESS ['INTASK_C27T_RESERVE_TITLE'] = "Book a meeting room";
$MESS ['INTASK_C27T_RESERVE'] = "Book";
$MESS ['INTASK_C27T_GRAPH_TITLE'] = "Meeting room reservation schedule";
$MESS ['INTASK_C27T_GRAPH'] = "Schedule";
$MESS ['INTASK_C27T_EDIT_TITLE'] = "Edit meeting room parameters";
$MESS ['INTASK_C27T_EDIT'] = "Edit Meeting Room";
$MESS ['INTASK_C27T_CRAETE_TITLE'] = "Create meeting room";
$MESS ['INTASK_C27T_CREATE'] = "Create Meeting Room";
?>
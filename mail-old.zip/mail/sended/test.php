<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("description", "Банк резюме");
$APPLICATION->SetTitle("Банк резюме - Почта");
?>
<style>
.workarea-content-paddings {
    padding: 0;
}
#hr_department_post {
	width: 180px;
    height: 39px;
    margin: 20px 15px 15px 20px;
    padding: 2px;
    vertical-align: top;
    border: 1px solid #d5dde0;
    border-radius: 2px;
}
</style>
<select id="hr_department_post">
    <option value="0">Выберите пункт меню</option>
    <option value="1">Полученная почта</option>
    <option value="2">Отправленная почта</option>
    <option value="3">Тестовая почта</option>
    <option value="4">Все пользователи</option>                             
</select>
<script>
    $(document).ready(function () {
        var hrDepartment = $("#hr_department_post");
        hrDepartment.change(function () {
            switch (hrDepartment.val()) {
            case '1':
                document.location.href = "/mail/";
                break;
            case '2':
                document.location.href = "/mail/sended/";
                break;
            case '3':
                // document.location.href = "/mail/sended/test.php";
                break;
            case '4':
                document.location.href = "/mail/everybody.php";
                break;
        	default:
                console.log(hrDepartment);
            }
        });
    });
</script>
<?
$APPLICATION->IncludeComponent(
	"custom:mail.list", 
	"resumes", 
	array(
		"FIELDS" => [
        "0" => "SUBJECT",
		"1" => "SETTINGS",
		"2" => "CREATED"],
		"COMPONENT_TEMPLATE" => ""
	),
	false
);
?><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
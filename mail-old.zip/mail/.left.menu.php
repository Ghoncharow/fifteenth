<?
CJSCore::Init(array('jquery2'));
$aMenuLinks = Array(
	Array(
		"Почта", 
		"/mail", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Категории банка", 
		"/mail/categories/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"На рассмотрении", 
		"/mail/await.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Архив", 
		"/mail/archive/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
<?php
if ($_GET["grid_id"] != "tbl_user") {
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
$APPLICATION->SetPageProperty("description", "Банк резюме");
$APPLICATION->SetTitle("Архив неактуальных карточек");
?>
<style>
#hr_department_post {
	width: 235px;
    height: 39px;
    margin: 15px 15px 15px 20px;
    padding: 2px;
    border: 1px solid #d5dde0;
    border-radius: 2px;
}
</style>
<select id="hr_department_post">
    <option value="0">Выберите карточки кандидатов:</option>
    <option value="1">- информация о которых не обновляется в течении полугода;</option>
    <option value="2">- которые были приняты на работу.</option>                        
</select>
<script>
    $(document).ready(function () {
        var hrDepartment = $("#hr_department_post");
        hrDepartment.change(function () {
            switch (hrDepartment.val()) {
            case '1':
                document.location.href = "/mail/archive/";
                break;
            case '2':
                // document.location.href = "/mail/archive/taken.php";
                break;
        	default:
                console.log(hrDepartment);
            }
        });
    });
</script>
<?
}
$GLOBALS["HR_SELECTING_STATUS"] = array(2);
$GLOBALS["HR_FILTRATION"] = array("UF_HR_STATUS" => "62");
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_admin.php");
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');


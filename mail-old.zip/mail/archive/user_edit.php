<?
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_edit.php");
?>
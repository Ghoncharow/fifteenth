<?php
if ($_GET["grid_id"] != "tbl_user") {
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
$APPLICATION->SetPageProperty("description", "Банк резюме");
$APPLICATION->SetTitle("Рассматриваемые к трудоустройству кандидаты");

$userStatusDb = CUser::GetList(($by = "NAME"), ($order = "desc"), 
        array("UF_HR_STATUS" => "60", "<UF_HR_ALLOTMENT" => date('d.m.Y', (time() - (60*60*24*30)))), 
        array("SELECT" => array("UF_HR_STATUS", "UF_HR_ALLOTMENT"))
    );
$userProperties = new CUser;
while ($userStatus = $userStatusDb->Fetch()) {
    $userProperties->Update($userStatus["ID"], array("UF_HR_STATUS" => "61"));
}

// $userProperties = new CUser;
// $fields01 = array("UF_HR_ALLOTMENT" => '25.05.2020'); 
// $userProperties->Update('13', $fields01);
// $userProperties->Update('260', $fields01);
// $userProperties->Update('257', $fields01);

?>
<style>
.adm-toolbar-panel-container {
    margin: -4px 0 18px 0 !important;
}
</style>
<?
}
// echo date('d.m.Y', (time() - (60*60*24*184)));
// echo date('d.m.Y', (time() - (60*60*24*30)));
$GLOBALS["HR_SELECTING_STATUS"] = array(3, 4);
$GLOBALS["HR_FILTRATION"] = array("UF_HR_STATUS" => "60");
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_admin.php");
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
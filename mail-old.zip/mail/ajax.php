<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

$queryResult = array( "method" => $_POST["METHOD"], "userId" => $_POST["USER_ID"], "statusId" => $_POST["STATUS_ID"] );

if ($_POST["METHOD"] == '@UPDATE') {
    $arFields["UF_HR_STATUS"] = $_POST["STATUS_ID"];
	if (IsModuleInstalled("im") && CModule::IncludeModule("im") && $_POST["STATUS_ID"] == "60") {
        $arFields["UF_HR_ALLOTMENT"] = date('d.m.Y', time());
		// $fromSender = (CUser::GetByID($GLOBALS["USER"]->GetID()))->Fetch()["EMAIL"];
		// $lettersHeader = "Федеральное казначейство";
		// $protocolHeaders  = 'MIME-Version: 1.0' . "\r\n";
		// $protocolHeaders .= 'Content-type: text/html; charset=utf-8' . "\r\n";
		// $protocolHeaders .= "From: <".$fromSender.">\r\n";
        $arrFields = CUser::GetByID($_POST["USER_ID"])->Fetch();
		$candidatName = $arrFields["LAST_NAME"].' '.$arrFields["NAME"].' '.$arrFields["SECOND_NAME"];
		if (empty($arrFields["LAST_NAME"])) $candidatName = $arrFields["NAME"];
		$notifyMessageOut = "$candidatName претендует на замещение вакантной должности.";
		$notifyMessageOut .= ' Дата рассмотрения заявки отделом кадров: '.$arFields["UF_HR_ALLOTMENT"].'.';
		$arMessageFieldsToChat = array(
			// получатель
		   "TO_USER_ID" => '1',
		   // отправитель
		   "FROM_USER_ID" => $GLOBALS["USER"]->GetID(), 
		   // тип уведомления
		   "NOTIFY_TYPE" => IM_NOTIFY_FROM, 
		   // модуль запросивший отправку уведомления
		   "NOTIFY_MODULE" => "calendar",
		   // текст уведомления на сайте
		   "NOTIFY_MESSAGE" => $notifyMessageOut, 
		   // текст уведомления для отправки на почту (или XMPP), если различий нет - не задаем параметр
		   "NOTIFY_MESSAGE_OUT" => $notifyMessageOut 
		);
		$dataGroups1 = CUser::GetList(($by="ID"), ($order="ASC"), array('GROUPS_ID' => array(9), 'ACTIVE' => 'Y'));
		while($arUserGroups = $dataGroups1->Fetch()) {
			$arMessageFieldsToChat["TO_USER_ID"] = $arUserGroups['ID'];
			CIMNotify::Add($arMessageFieldsToChat);
			// mail($arUserGroups["EMAIL"], $lettersHeader, $notifyMessageOut, $protocolHeaders);
		}
	}
    (new CUser)->Update($_POST["USER_ID"], $arFields);        
} else {
    $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);
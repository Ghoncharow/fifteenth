<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Структура Казначейства");
$APPLICATION->SetAdditionalCSS("/company/telephones.css", true);
IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/intranet/public/company/telephones.php");
CJSCore::Init(array('jquery2'));
global $USER;

$curPageLink = "/company/telephones.php?&SHOW_MODE=";
if (empty($_GET["SHOW_MODE"])) $_GET["SHOW_MODE"] = "fed";

$accordionsMenu = array(
    array("NAME" => "ЦАФК", 
        "LINK_URL" => $curPageLink."fed",
        "TITLE" => "Центральный аппарат федерального казначейства", 
        "SHOW_MODE" => "fed"
    ),
    array(
        "NAME" => "ЦОКР", 
        "LINK_URL" => $curPageLink."zokr",
        "TITLE" => "Центр по обеспечению деятельности казначейства России", 
        "SHOW_MODE" => "zokr"
    ),
    array(
        "NAME" => "ТОФК", 
        "LINK_URL" => $curPageLink."tofk", 
        "TITLE" => "Территориальные органы федерального казначейства",
        "SHOW_MODE" => "tofk"
    ),
    array(
        "NAME" => "СКАЧАТЬ СПРАВОЧНИК", 
        "LINK_URL" => "/company/unity-telephones.php?generationType=generateFile&SHOW_MODE=".$_GET["SHOW_MODE"], 
        "TITLE" => "Скачать телефонный справочник в формате Excel",
        "FILE" => "download", 
        "ICON" => true
    ),
);

if (($_GET["SHOW_MODE"] == "tofk")) {    
    $accordionsMenu[3]["LINK_URL"] = htmlentities(file_get_contents("telephones.txt"));
    if (empty($accordionsMenu[3]["LINK_URL"])) $accordionsMenu[3]["LINK_URL"] = "tofk.xlsx";
    $isContentManager = $USER->IsAdmin() || in_array("9", CUser::GetUserGroup($USER->GetId()));
    if($isContentManager) $accordionsMenu[] = array(
            "NAME" => "ЗАГРУЗИТЬ НОВЫЙ",
            "TITLE" => "Загрузить телефонный справочник в формате Excel", 
            "ICON" => true
        );
}
// echo '<script type="text/javascript">console.log('.json_encode($accordionsMenu).');</script>';
?>

<table class="tabs-wrapper" cellpadding="0" cellspacing="0" border="0">
	<tbody><tr>						
        <?foreach ($accordionsMenu as $menuItem) {?>
            <td class="bx-disk-interface-toolbar<?=($_GET["SHOW_MODE"] == $menuItem['SHOW_MODE']) ? ' active' : '';?>">
                <?if (empty($menuItem["LINK_URL"])) {?>
                    <form id="fileUploadForm" class="bx-disk-context-button" title="<?=$menuItem['TITLE']?>">
                        <span class="menu-popup-item-icon show"></span>
                        <span class="bx-disk-context-button-text"><?=$menuItem["NAME"]?></span>
                        <input type="file" id="inputContainerFolder" name="inputContainerFolder">
                    </form>
                <?} else {?>
                    <a <?=$menuItem["FILE"]?> href="<?=$menuItem["LINK_URL"]?>" title="<?=$menuItem['TITLE']?>" 
                                            class="bx-disk-context-button<?=($menuItem['FILE']) ? ' ajaxUpdated' : '';?>">
                        <span class="menu-popup-item-icon<?=($menuItem['ICON']) ? ' show' : '';?>"></span>
                        <span class="bx-disk-context-button-text"><?=$menuItem["NAME"]?></span>
                    </a>
                <?}?>
	        </td>
        <?}?>
    </tr></tbody>
</table>

<?$APPLICATION->IncludeComponent(
    "bitrix:intranet.search",
    "structure",
    Array(
        "AJAX_MODE" => "Y",
        "AJAX_OPTION_ADDITIONAL" => "",
        "AJAX_OPTION_HISTORY" => "Y",
        "AJAX_OPTION_JUMP" => "N",
        "AJAX_OPTION_SHADOW" => "Y",
        "AJAX_OPTION_STYLE" => "Y",
        "ALPHABET_LANG" => array(0=>"",1=>(LANGUAGE_ID=="en")?"en":((LANGUAGE_ID=="de")?"en":"ru"),2=>"",),
        "CACHE_TIME" => "3600000",
        "CACHE_TYPE" => "A",
        "COMPONENT_TEMPLATE" => "structure",
        "DATE_FORMAT" => "d.m.Y",
        "DATE_FORMAT_NO_YEAR" => "d.m",
        "DATE_TIME_FORMAT" => "d.m.Y H:i:s",
        "DEFAULT_VIEW" => "table",
        "DISPLAY_USER_PHOTO" => "N",
        "EXTRANET_TYPE" => "",
        "FILTER_1C_USERS" => "N",
        "FILTER_DEPARTMENT_SINGLE" => "Y",
        "FILTER_NAME" => "users",
        "FILTER_SECTION_CURONLY" => "N",
        "FILTER_SESSION" => "N",
        "LIST_VIEW" => "list",
        "NAME_TEMPLATE" => "",
        "NAV_TITLE" => GetMessage("COMPANY_NAV_TITLE"),
        "PATH_TO_CONPANY_DEPARTMENT" => "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#",
        "PATH_TO_USER_EDIT" => "/company/personal/user/#user_id#/edit/",
        "PATH_TO_VIDEO_CALL" => "/company/personal/video/#USER_ID#/",
        "PM_URL" => "/company/personal/messages/chat/#USER_ID#/",
        "SHOW_DEP_HEAD_ADDITIONAL" => "N",
        "SHOW_ERROR_ON_NULL" => "Y",
        "SHOW_LOGIN" => "Y",
        "SHOW_NAV_BOTTOM" => "Y",
        "SHOW_NAV_TOP" => "N",
        "SHOW_UNFILTERED_LIST" => "Y",
        "SHOW_YEAR" => "Y",
        "STRUCTURE_FILTER" => "structure",
        "STRUCTURE_PAGE" => "structure.php",
        "TABLE_VIEW" => "group_table",
        "USERS_PER_PAGE" => "700",
        "USER_PROPERTY_EXCEL" => array(0=>"FULL_NAME",1=>"EMAIL",2=>"WORK_POSITION",3=>"WORK_PHONE",4=>"UF_DEPARTMENT",5=>"UF_PHONE_INNER",6=>"UF_SKYPE",),
        "USER_PROPERTY_LIST" => array(0=>"PERSONAL_PHOTO",1=>"FULL_NAME",2=>"EMAIL",3=>"PERSONAL_MOBILE",4=>"WORK_PHONE",5=>"UF_SKYPE",),
        "USER_PROPERTY_TABLE" => array(0=>"FULL_NAME",1=>"EMAIL",2=>"UF_ADDRESS",3=>"WORK_POSITION",4=>"WORK_PHONE",5=>"UF_PHONE_INNER",),
        "USE_VIEW_SELECTOR" => "N",
        "SHOW_MODE" => (isset($_GET["SHOW_MODE"]) ? $_GET["SHOW_MODE"] : "fed"),
    )
);?>
<div class='support-telephones'>
	<h3>Телефонные номера службы эксплуатации и охраны:</h3>
	<p>+7(495)214-71-02, 5273 – Начальник охраны объекта (Правдин Андрей Евгеньевич)</p>
	<p>+7(495)214-81-17, 5606 – Служба экплуатации ФКУ "ЦОКР" (диспетчерская)</p>
	<p>+7(495)214-70-00 – Ответственный дежурный (круглосуточно)</p>
	<p>1578 – Бюро пропусков</p>
	<p>1579 – Пост охраны</p>
</div>
<script type="text/javascript">
    $(function() {
        $("#inputContainerFolder").change(function() {
            // console.log(6);
            var form = $('#fileUploadForm')[0];
            var formData = new FormData(form);		
            formData.append('METHOD', '@UPLOAD');
            $.ajax("telephones_ajax.php", {
                method: 'POST',
                processData: false,
                contentType: false,
                data: formData
            }).done(function(data) {
                try {
                    var result = JSON.parse(data);
                    // console.log(result);
                    if (result.OKEY) $('a.ajaxUpdated').attr('href', result.PATH);
                    // location.reload();
                } catch(e) {
                    console.log(e);
                }
            }).fail(function(data) {
                console.log(data);
            });

        });
    });
</script>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
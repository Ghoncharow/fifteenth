<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

unset($queryResult);
if ($_POST["METHOD"] == '@UPLOAD') {

	if (isset($_FILES) && ($_FILES['inputContainerFolder']['error'] == 0)) {
		// Директория для размещения файла
		$destiationDir = dirname(__FILE__).'/'.$_FILES['inputContainerFolder']['name'];
		$queryResult["PATH"] = '/company/'.$_FILES['inputContainerFolder']['name'];
		// Перемещаем файл из каталога для временного хранения в желаемую директорию
        move_uploaded_file($_FILES['inputContainerFolder']['tmp_name'], $destiationDir);
        $fd = fopen("telephones.txt", 'w') or die("Не удалось создать файл.");
        fwrite($fd, $queryResult["PATH"]);
        fclose($fd);
	}
	// AddMessage2Log("\$_FILES<script>console.log(".json_encode($_FILES).");</script><br>", '', 0);

	$queryResult["OKEY"] = true;
	// AddMessage2Log("queryResult<script>console.log(".json_encode($queryResult).");</script><br>", '', 0);

} else {
    $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);
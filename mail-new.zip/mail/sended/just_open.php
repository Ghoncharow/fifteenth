<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

$queryResult = array( "method" => $_POST["METHOD"], "mailId" => $_POST["MAIL_ID"] );

if ($_POST["METHOD"] == '@UPDATE') {	
	global $DB;
	$DB->Query("UPDATE `b_crm_act` SET `UNREAD`='N' WHERE `ID`= " . $_POST["MAIL_ID"] . ";");
} else {
    $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);
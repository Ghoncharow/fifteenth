<?
$MESS["DATE"] = 'Дата';
$MESS["MAIL_FROM"] = 'Отправитель';
$MESS["SUBJECT"] = 'Тема письма';
$MESS["NEW_MAIL"] = 'Новое письмо';
$MESS["CHECK_ALL"] = 'Отметить все/снять отметку у всех';
?>
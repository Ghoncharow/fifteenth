<? require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
if ($_POST['action'] && $_POST['action'] == 'delete mails' && !empty($_POST['mailsID'])) {
    if (!CModule::IncludeModule("crm")) {
        echo json_encode("crm not install");
        die();
    }
    $success = true;
    foreach ($_POST['mailsID'] as $ID) {
        if(!CCrmActivity::Delete($ID)) {
            $success = false;
        }
    }
    echo json_encode($success);
} elseif ($_POST['action'] && ($_POST['action'] == 'read mails' || $_POST['action'] == 'unread mails') && !empty($_POST['mailsID'])) {
    global $DB;
    foreach ($_POST['mailsID'] as $ID) {
        if(!$DB->Query("UPDATE `b_crm_act` SET `UNREAD`='". ($_POST['action'] == 'read mails' ? 'N' : 'Y') ."' WHERE `ID`= " . $ID . ";")) {

        }
    }
    echo json_encode("success");

}
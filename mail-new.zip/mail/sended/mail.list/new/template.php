<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<div class="main-grid">
    <? //debug($arResult);?>
    <table class="mail-list-table main-grid-table" id="mail-list">
        <thead class="main-grid-header">
        <tr class="main-grid-row-head">
            <td class="main-grid-cell-head main-grid-cell-static main-grid-cell-checkbox">
            <span class="main-grid-cell-content">
                <input type="checkbox" id="check-all" title="<?= GetMessage("CHECK_ALL"); ?>">
            </span>
            </td>
            <td class="main-grid-cell-head main-grid-cell-static main-grid-cell-action"></td>

            <? foreach ($arParams['FIELDS'] as $field) {
                switch ($field) {
                    case "SUBJECT": ?>
                        <th><?= GetMessage("SUBJECT"); ?></th><?
                        break;
                    case "SETTINGS": ?>
                        <th><?= GetMessage("MAIL_FROM"); ?></th><?
                        break;
                    case "CREATED": ?>
                        <th><?= GetMessage("DATE"); ?>

                        </th><?
                        break;
                }
            } ?>
        </tr>
        <tr>
            <td>
                <div class="add-new-mail"><?= GetMessage("NEW_MAIL"); ?></div>
            </td>
        </tr>
        </thead>
        <tbody>
        <? foreach ($arResult['mail-list'] as $mail) {
            if (!$mail) continue; ?>
        <tr class="main-grid-row main-grid-row-body <?= $mail['UNREAD'] == 'Y' ? "unread" : ""; ?>"
            id="mail_<?= $mail['ID'] ?>">
            <td class="select main-grid-cell main-grid-cell-checkbox">
                <span class="main-grid-cell-content">
                    <input id="checkbox_<?= $mail['ID'] ?>" class="mail-select" type="checkbox">
                </span>
            </td>
            <td class="main-grid-cell main-grid-cell-action">
                <span class="main-grid-cell-content">
                    <a href="#" class="main-grid-row-action-button"></a>
                </span>
            </td>
            <?
            //foreach
            $names = $mail;
//debug($names);
            $countOnPage = 10;

// Исходный массив данных для списка
            $elements = $mail;//$rsUsers;

// Получаем номер текущей страницы из реквеста
            $page = intval($_GET['PAGEN_1']);
            if(empty($page)) $page=1;

// Отбираем элементы текущей страницы
            $elementsPage = array_slice($elements, ($page-1) * $countOnPage, $countOnPage);

// Вывод страницы
//foreach ($elementsPage as $item) {
//    echo "<br>$item";
//}
            foreach ($elementsPage as $field => $value) {
                if ($field[0] === '~') continue;
                $content = "";
                switch ($field) {
                    case "CREATED":
                        $content = $value;
                        break;
                    case "SUBJECT":
                        $content = '<div class="open-mail" id="' . $mail['ID'] . '">' . $value . '</div>';
                        break;
                    case "SETTINGS":
                        $from = $mail[$field]['EMAIL_META']['from'];
                        $content = "<a href='mailto:" . $from . "'>" . $from . "</a>";
                        break;
                }
                if ($content != "") { ?>
                <td class="<?= $field ?> main-grid-cell main-grid-cell-left">
                    <span class="main-grid-cell-content">
                        <?= $content ?>
                    </span>
                    </td><?
                }
            }

// Подготовка параметров для пагинатора
            $navResult = new CDBResult();
            $navResult->NavPageCount = ceil(count($elements) / $countOnPage);
            $navResult->NavPageNomer = $page;
            $navResult->NavNum = 1;
            $navResult->NavPageSize = $countOnPage;
            $navResult->NavRecordCount = count($elements);

// Вывод пагинатора
            $APPLICATION->IncludeComponent('bitrix:system.pagenavigation', '', array(
                'NAV_RESULT' => $navResult,
            ));
            ?>
            </tr><?
        } ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="3">
                <button id="delete">Удалить</button>
                <button id="read">Прочитано</button>
            </td>
        </tr>
        </tfoot>
    </table>
</div>


<div id="mail-frame-container" class="mail-frame-container"><span id="mail-frame-close"></span></div>
<div id="overlay"></div>
<script type="text/javascript" src="/bitrix/js/jquery-plagins/tablesorter/jquery.tablesorter.min.js"></script>

<script>
    var pathToAjax = "<?=str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);?>/ajax.php";
    var sessid = "<?=bitrix_sessid_get()?>";
</script>
<?

?>
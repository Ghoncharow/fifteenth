<?
$MESS["DATE"] = 'Дата';
$MESS["MAIL_FROM"] = 'Отправитель';
$MESS["SUBJECT"] = 'Тема письма';
$MESS["NEW_MAIL"] = 'Новое письмо';
$MESS["CHECK_ALL"] = 'Отметить все/снять отметку у всех';
$MESS["DELETE"] = 'Удалить';
$MESS["READ"] = 'Прочитано';
$MESS["UNREAD"] = 'Не прочитано';
$MESS["MAKE_READ"] = 'Отметить прочитанным';
$MESS["MAKE_UNREAD"] = 'Отметить непрочитанным';
$MESS["MAKE_UNREAD"] = 'Отметить непрочитанным';
$MESS["MAKE_UNREAD"] = 'Отметить непрочитанным';
$MESS["DO_YOU_WANT_TO_DELETE"] = 'Вы уверены, что хотите удалить письмо?';

?>
<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<?// Задаем количество элементов на странице
$countOnPage = 2;
// Исходный массив данных для списка
$elements = $arResult["mail-list"];
// Получаем номер текущей страницы из реквеста
$page = intval($_GET['PAGEN_1']);
if (empty($page)) $page = 1;
// Отбираем элементы текущей страницы
$elementsPage = array_slice($elements,$page * $countOnPage, $countOnPage);
// Вывод страницы
?>
<div class="main-grid-container" style="overflow:visible;">
    <?// debug($arResult);?>
    <table class="mail-list-table main-grid-table" id="mail-list">
        <thead class="main-grid-header">
        <tr class="main-grid-row-head">
            <td class="main-grid-cell-head main-grid-cell-static main-grid-cell-checkbox">
            <span class="main-grid-cell-head-container">
                <span class="main-grid-checkbox-container main-grid-head-checkbox-container">
                    <input type="checkbox" id="check-all" title="<?= GetMessage("CHECK_ALL"); ?>">
                </span>
            </span>
            </td>
            <td class="main-grid-cell-head main-grid-cell-static main-grid-cell-action">

            </td>

            <? foreach ($arParams['FIELDS'] as $field) {
                switch ($field) {
                    case "SUBJECT": ?>
                        <th class="main-grid-cell-head main-grid-cell-left main-grid-col-sortable  main-grid-draggable">
                        <span class="main-grid-cell-head-container">
                            <span class="main-grid-head-title">
                                <?= GetMessage("SUBJECT"); ?>
                            </span>
                            <span class="main-grid-resize-button" onclick="event.stopPropagation(); " title=""></span>
                            <span class="main-grid-control-sort"></span>
                        </span>

                        </th><?
                        break;
                    case "SETTINGS": ?>
                        <th class="main-grid-cell-head main-grid-cell-left main-grid-col-sortable  main-grid-draggable">
                        <span class="main-grid-cell-head-container">
                            <span class="main-grid-head-title">
                                <?= GetMessage("MAIL_FROM"); ?>
                            </span>
                            <span class="main-grid-resize-button" onclick="event.stopPropagation(); " title=""></span>
                            <span class="main-grid-control-sort"></span>
                        </span>
                        </th><?
                        break;
                    case "CREATED": ?>
                        <th class="main-grid-cell-head date main-grid-cell-left main-grid-col-sortable  main-grid-draggable">
                        <span class="main-grid-cell-head-container">
                            <span class="main-grid-head-title">
                                <?= GetMessage("DATE"); ?>
                            </span>
                            <span class="main-grid-resize-button" onclick="event.stopPropagation(); " title=""></span>
                            <span class="main-grid-control-sort"></span>
                        </span>
                        </th><?
                        break;
                }
            } ?>
		<th class="main-grid-cell-head main-grid-cell-static main-grid-special-empty"></th>
        </tr>
        <tr>
            <td>
                <div class="add-new-mail"><?= GetMessage("NEW_MAIL"); ?></div>
            </td>
        </tr>
        </thead>
        <tbody>
        <? foreach ($arResult['mail-list'] as $mail) {
            if (!$mail) continue; ?>
        <tr class="main-grid-row main-grid-row-body <?= $mail['UNREAD'] == 'Y' ? "unread" : ""; ?>"
            id="mail_<?= $mail['ID'] ?>">
            <td class="select main-grid-cell main-grid-cell-checkbox">
                <span class="main-grid-cell-content">
                    <input id="checkbox_<?= $mail['ID'] ?>" class="mail-select" type="checkbox">
                </span>
            </td>
            <td class="main-grid-cell main-grid-cell-action" style="overflow: visible">
                <span class="main-grid-cell-content">
                    <a href="#" id="action-button_<?= $mail['ID'] ?>" class="main-grid-row-action-button"></a>
                </span>
                <div class="popup-action-menu-container">
                    <div class="popup-action-menu" id ="popup-action-menu_<?=$mail['ID'];?>">
                        <div id="forward-mail_<?=$mail['ID'];?>" title="Переслать письмо" class="menu-popup-item forward">
                            <span class="menu-popup-item-text">Переслать письмо</span>
                        </div>
                        <div id="delete-mail_<?=$mail['ID'];?>" title="Удалить письмо" class="menu-popup-item delete">
                            <span class="menu-popup-item-text">Удалить письмо</span>
                        </div>
                        <div style="border-bottom: 1px solid rgba(200, 200, 200, 0.5)"></div>
                        <div class="popup-window-angly popup-window-angly-left" style="top: 10px;"></div>
                    </div>
                </div>
            </td>
            <?
            foreach ($mail as $field => $value) {
                if ($field[0] === '~') continue;
                $content = "";
                switch ($field) {
                    case "CREATED":
                        $content = $value;
                        break;
                    case "SUBJECT":
                        $content = '<div class="open-mail" id="' . $mail['ID'] . '">' . $value . '</div>';
                        break;
                    case "SETTINGS":
                        $from = $mail[$field]['EMAIL_META']['from'];
                        $content = "<a href='mailto:" . $from . "'>" . $from . "</a>";
                        break;
                }
                if ($content != "") { ?>
                <td class="<?= $field ?> main-grid-cell main-grid-cell-left">
                    <span class="main-grid-cell-content">
                        <?= $content ?>
                    </span>
                    </td><?
                }
            } ?>
            </tr><?
        } ?>
        </tbody>
    </table>
    <div class="main-grid-action-panel main-grid-disable">
        <div class="main-grid-control-panel-wrap">
            <table class="main-grid-control-panel-table">
                <tbody>
                <tr class="main-grid-control-panel-row">
                    <td class="main-grid-control-panel-cell">
                        <span id="delete" class="main-grid-buttons icon remove deactivated" title="<?=GetMessage('DELETE');?>">
                           <?=GetMessage('DELETE');?>
                        </span>
                        <span id="read"  class="custom-icon deactivated" title="<?=GetMessage('MAKE_READ');?>">
                            <span><?=GetMessage('READ');?></span>
                            <div class="icon-read"></div>
                        </span>
                        <span id="unread"  class="custom-icon deactivated hide" title="<?=GetMessage('MAKE_UNREAD');?>">
                            <?=GetMessage('UNREAD');?>
                            <div class="icon-unread"></div>
                        </span>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?
$navResult = new CDBResult();
$navResult->NavPageCount = ceil(count($elements) / $countOnPage);
$navResult->NavPageNomer = $page;
$navResult->NavNum = 1;
$navResult->NavPageSize = $countOnPage;
$navResult->NavRecordCount = count($elements);
// Вывод пагинатора
$APPLICATION->IncludeComponent('bitrix:system.pagenavigation', '', array(
    'NAV_RESULT' => $navResult,
));
?>

<div id="mail-frame-container" class="mail-frame-container"><span id="mail-frame-close"></span></div>
<div id="overlay"></div>
<script type="text/javascript" src="/bitrix/js/jquery-plagins/tablesorter/jquery.tablesorter.min.js"></script>

<script>
    var pathToAjax = "<?=str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);?>/ajax.php";
    var sessid = "<?=bitrix_sessid_get()?>";

    function wantToDelete() {
        return(confirm("<?=GetMessage("DO_YOU_WANT_TO_DELETE");?>"));
    }
</script>
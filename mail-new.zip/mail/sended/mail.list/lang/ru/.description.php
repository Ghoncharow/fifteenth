<?
$MESS["COMPONENT_NAME"] = 'Интегрированная почта';
$MESS["COMPONENT_DESCRIPTION"] = 'Вывод списка писем';
$MESS["MAIL_LIST"] = 'Список писем';

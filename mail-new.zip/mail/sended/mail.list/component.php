<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
if(!CModule::IncludeModule('crm')) {
    echo "Can`t start module crm";
    die();
}

global $DB;
function array_multisort_value()
{
	$args = func_get_args();
	$data = array_shift($args);
	foreach ($args as $n => $field) {
		if (is_string($field)) {
			$tmp = array();
			foreach ($data as $key => $row) {
				$tmp[$key] = $row[$field];
			}
			$args[$n] = $tmp;
		}
	}
	$args[] = &$data;
	call_user_func_array('array_multisort', $args);
	return array_pop($args);
}
$arFilter = array("RESPONSIBLE_ID" => $GLOBALS['USER']->GetID(), "PROVIDER_TYPE_ID" => "EMAIL");
$arSelect = array("ID", "SUBJECT", "CREATED", "SETTINGS", "STORAGE_ELEMENT_IDS", "DESCRIPTION");
$messageListDB = CCrmActivity::getList(array('ID' => 'asc'), $arFilter, false, false, $arSelect, ["UNREAD"] );
while ($arRes = $messageListDB->GetNext()) {
    $unread = $DB->Query("SELECT UNREAD FROM b_crm_act WHERE ID = " . $arRes['ID'], false,"ERROR")->Fetch();
    $attachments = explode(':', $arRes["STORAGE_ELEMENT_IDS"]);
    $mailList = array(        
        'ATTACHMENTS' => $attachments[1],
        'FIELD_DATE' => $arRes["CREATED"],
        'FIELD_FROM' => $arRes["SETTINGS"]["EMAIL_META"]["from"],
        'ID' => $arRes["ID"],
        'MAILBOX_NAME' => $arRes["SETTINGS"]["EMAIL_META"]["to"],
        'NEW_MESSAGE' => $unread["UNREAD"],
        'SUBJECT' => $arRes["SUBJECT"],
    );
    $arResult['mail-list'][] = array_merge($arRes, $unread);
    $arResult['mails'][] = $mailList;
}
$sortParameter = ($order == 'asc') ? SORT_ASC : SORT_DESC;
$arResult['mails'] = array_multisort_value($arResult['mails'], 'ID', $sortParameter);
$messageList = new CDBResult;
$messageList->InitFromArray($arResult['mails']);
$messageList->NavStart(4, true, 2);
$arResult['COUNT'] = $messageList->SelectedRowsCount();

$this->IncludeComponentTemplate();
<?php
$MESS['HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_EDIT'] = 'Highload-блок "#NAME#": Редактирование записи ##NUM#';
$MESS['HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_NEW'] = 'Highload-блок "#NAME#": Создание записи';
$MESS['HLBLOCK_ADMIN_ROW_EDIT_NOT_FOUND'] = 'Информация о Highload-блоке не найдена';
$MESS['HLBLOCK_ADMIN_ROWS_COPY'] = 'Копировать';
$MESS['HLBLOCK_ADMIN_ROWS_ACTIONS'] = 'Действия';
$MESS['HLBLOCK_ADMIN_ROWS_ADD'] = 'Добавить';
$MESS['HLBLOCK_ADMIN_ROWS_DEL'] = 'Удалить';
$MESS['HLBLOCK_ADMIN_ROWS_DEL_CONF'] = 'Действительно удалить?';
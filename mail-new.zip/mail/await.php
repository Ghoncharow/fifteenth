<?php
if ($_GET["grid_id"] != "tbl_user1") {
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
$APPLICATION->SetPageProperty("description", "Банк резюме");
$APPLICATION->SetTitle("Рассматриваемые к трудоустройству кандидаты");
$currentUser = CUser::GetUserGroup($GLOBALS["USER"]->GetId());
if (!($GLOBALS["USER"]->IsAdmin() || in_array("47", $currentUser))) {
    echo "К разделу имеют доступ только сотрудники отдела кадров. Приносим свои извинения.";
    echo "<br><br><br><br><br><br><br><br><br><br><br><br>";
    require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
    die();
}

?>
<style>
.adm-toolbar-panel-container {
    margin: -4px 0 18px 0 !important;
}
</style>
<?
}
// echo date('d.m.Y', (time() - (60*60*24*184)));
// echo date('d.m.Y', (time() - (60*60*24*30)));
// echo date('d.m.Y H:i:s');
$GLOBALS["HR_SELECTING_STATUS"] = array(3, 4);
$GLOBALS["HR_FILTRATION"] = array("UF_HR_STATUS" => "81");
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_admin.php");
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
<?
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

if ($_POST["METHOD"] == '@INSERT') {
	
	$ajaxFields = $_POST;
	$queryResult["EMAIL"] = $_POST["EMAIL"];
	unset($ajaxFields["METHOD"]);
	unset($ajaxFields["Update"]);
	unset($ajaxFields["autosave_id"]);
	unset($ajaxFields["sessid"]);
	unset($ajaxFields["user_edit_active_tab"]);
	unset($ajaxFields["MAX_FILE_SIZE"]);

	$connection = Bitrix\Main\Application::getConnection();
	$bName = $_POST["NAME"];
	$bSecondName = $_POST["SECOND_NAME"];
	$bLastName = $_POST["LAST_NAME"];
	$bMail = $_POST["EMAIL"];
	$sql1 = "INSERT b_user(NAME, SECOND_NAME, LAST_NAME, EMAIL) VALUES ('$bName', '$bSecondName', '$bLastName', '$bMail')";
	$connection->query($sql1);
	$sql2 = "SELECT ID, EMAIL FROM b_user ORDER BY ID DESC LIMIT 1";
	$recorded = $connection->query($sql2)->fetch();
	usleep(100); // значение аргумента в микросекундах, например 3000000 мкс = 3 с
	// AddMessage2Log("recorded<script>console.log(".json_encode($recorded).");</script><br>", '', 0);

	if (isset($_FILES) && ($_FILES['UPLOAD_FILE']['error'] == 0) && ($_FILES["file"]["size"] < 5000000)) {
		// Директория для размещения файла
		$destiationDir = str_replace('mail', '', dirname(__FILE__));
		$destiationDir = $destiationDir.'upload/mail/hr/user_'.$recorded["ID"].'/';
		if (!file_exists($destiationDir)) mkdir($destiationDir, 0777, true);
		$destiationDir .= $_FILES['UPLOAD_FILE']['name'];
		// Перемещаем файл из каталога для временного хранения в желаемую директорию
		move_uploaded_file($_FILES['UPLOAD_FILE']['tmp_name'], $destiationDir);
		$ajaxFields["UF_HR_UPLOADS"] = serialize($_FILES['UPLOAD_FILE']);
	}
	// AddMessage2Log("\$_FILES<script>console.log(".json_encode($_FILES).");</script><br>", '', 0);

	$userProperties = new CUser;
	$requireFields = array(
		"LOGIN" => $recorded["EMAIL"],
		"TIMESTAMP_X" => date('d.m.Y H:i:s'),
		"DATE_REGISTER" => date('d.m.Y H:i:s'),
		"LAST_ACTIVITY_DATE" => date('d.m.Y H:i:s'),
		"UF_HR_ALLOTMENT" => date('d.m.Y H:i:s'),
	);	
	foreach($requireFields as $key => $value) {
		$ajaxFields[$key] = $value;
	}
	$queryResult["OKEY"] = $userProperties->Update($recorded["ID"], $ajaxFields);
	// AddMessage2Log("ajaxFields<script>console.log(".json_encode($ajaxFields).");</script><br>", '', 0);
	// AddMessage2Log("queryResult<script>console.log(".json_encode($queryResult).");</script><br>", '', 0);

} else {
    $queryResult = array( "error" => "This is wrong method" );
}

echo json_encode($queryResult);
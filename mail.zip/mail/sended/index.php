<?
if ($_GET["mode"] == "frame") {
	$currentUrl = explode('?', $_SERVER['REQUEST_URI']);
	header('Location: '.$currentUrl[0]."?nav-mail-message=".$_GET["nav-mail-message"]);
}
if ($_GET["mode"] != "list") {
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("description", "Банк резюме");
$APPLICATION->SetTitle("Банк резюме - отправление писем");
?>
<style>
	#hr_department_post {		
		width: 190px;
    	font-size: 15px;
		height: 39px;
		margin: 15px 15px 15px 20px;
		padding: 2px;
		border: 1px solid #d5dde0;
		border-radius: 2px;
	}
	.add-new-mail {
		position: relative;
		display: inline-block;
		vertical-align: top;
		height: 39px;
		padding: 0 19px;
		margin: 15px;
		border-radius: 2px;
		text-align: center;
		background-color: #3bc8f5;
		color: #fff;
		text-transform: uppercase;
		font: 600 12px/39px "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
		cursor: pointer;
		transition: 160ms color linear, 160ms background-color linear, 160ms opacity linear, 160ms padding linear;
	}
	.add-new-mail:hover {
		background-color: rgba(59, 210, 255, 0.9);
	}	
	.mail-frame-container {
		z-index:1000;
		position: relative;
	}
	.mail-frame {
		position: fixed;
		top: 0;
		right: -50%;
		height: 100%;
		min-width: 80%;
		display: none;
		opacity: 0;
		padding: 1px 1px;
	}
	.mail-frame-container #mail-frame-close {
		width: 21px;
		height: 21px;
		position: absolute;
		top: 10px;
		right: 10px;
		cursor: pointer;
		display: block;
	}
	#overlay {
		z-index:999;
		position:fixed;
		background-color:#000;
		opacity:0.8;
		-moz-opacity:0.8;
		filter:alpha(opacity=80);
		width:100%;
		height:100%;
		top:0;
		left:0;
		cursor:pointer;
		display:none;
	}
</style>
<select id="hr_department_post">
    <option value="0">Выберите пункт меню:</option>
    <option value="1">- Полученная почта;</option>
    <option value="2">- Отправленная почта;</option>
    <option value="3">- Настройка прав доступа;</option>
    <option value="4">- Все пользователи.</option>
</select>
<div onclick="function(e){e.stopPropagation();}" class="add-new-mail"><?= GetMessage("NEW_MAIL"); ?></div>
<div id="mail-frame-container" class="mail-frame-container"><span id="mail-frame-close"></span></div>
<div id="overlay"></div>
<script>
    $(document).ready(function () {
        var hrDepartment = $("#hr_department_post");
        hrDepartment.change(function () {
            switch (hrDepartment.val()) {
            case '1':
                document.location.href = "/mail/";
                break;
            case '2':
                // document.location.href = "/mail/sended/";
                break;
            case '3':
                document.location.href = "/crm/configs/perms/";
                break;
            case '4':
                document.location.href = "/mail/everybody.php";
                break;
        	default:
                console.log(hrDepartment);
            }
        });
    });
</script>
<?
}
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/bx_root.php");

define("START_EXEC_PROLOG_BEFORE_1", microtime());
$GLOBALS["BX_STATE"] = "PB";
unset($_REQUEST["BX_STATE"]);
unset($_GET["BX_STATE"]);
unset($_POST["BX_STATE"]);
unset($_COOKIE["BX_STATE"]);
unset($_FILES["BX_STATE"]);
// if (!empty($_COOKIE["PREVIOUS_PAGE_MAIL"])) unset($_COOKIE["PREVIOUS_PAGE_MAIL"]);
// setcookie('PREVIOUS_PAGE_MAIL', '', (time()-3600));

define("NEED_AUTH", true);
define("ADMIN_SECTION", false);

if (isset($_REQUEST['bxpublic']) && $_REQUEST['bxpublic'] == 'Y' && !defined('BX_PUBLIC_MODE'))
	define('BX_PUBLIC_MODE', 1);

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include.php");
if(!headers_sent())
	header("Content-type: text/html; charset=".LANG_CHARSET);
	
if (defined('BX_PUBLIC_MODE') && BX_PUBLIC_MODE == 1)
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST')
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_jspopup.php");
}

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/admin_tools.php");
require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mail/prolog.php");

CMain::PrologActions();

$MOD_RIGHT = $APPLICATION->GetGroupRight("mail");
if ($MOD_RIGHT<"R") $APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));
IncludeModuleLangFile(__FILE__);
Bitrix\Main\Loader::includeModule('mail');
if (!CModule::IncludeModule('crm')) echo "Module crm can`t start.";
global $DB;
$err_mess = "File: ".__FILE__."<br>Line: ";

$sTableID = "t_message_admin";
$oSort = new CAdminSorting($sTableID, "field_date", "desc");
$lAdmin = new CAdminList($sTableID, $oSort);


$filter = new CAdminFilter(
	$sTableID."_filter_id",
	array(
		GetMessage("MAIL_MSG_ADM_FILTER_SUBJECT"),
		GetMessage("MAIL_MSG_ADM_DATE"),
		GetMessage("MAIL_MSG_ADM_FILTER_FROM"),
		GetMessage("MAIL_MSG_ADM_FILTER_TO"),
		GetMessage("MAIL_MSG_ADM_FILTER_TEXT"),
	)
);

$arFilterFields = Array(
	"find_subject",
	"find_date",
	"find_from",
	"find_to",
	"find_body",
);

$lAdmin->InitFilter($arFilterFields);

$arFilter = Array(
	'SUBJECT'      => $find_subject,
	'FIELD_DATE'   => $find_date,
	'FIELD_FROM'   => $find_from,
	'MAILBOX_NAME' => $find_to,
	'BODY'         => $find_body,
);

if($MOD_RIGHT=="W" && $arID = $lAdmin->GroupAction())
{
	foreach($arID as $ID)
	{
		if(strlen($ID)<=0)
			continue;

		$ID = intval($ID);

		switch($_REQUEST['action'])
		{			
			case "mark_as_read":
				$DB->Query("UPDATE `b_crm_act` SET `UNREAD`='N' WHERE `ID`= " . $ID . ";");
				// AddMessage2Log("mark_as_read<script>console.log(".json_encode($ID).");</script><br>", '', 0);
				break;
			case "mark_as_unread":
				$DB->Query("UPDATE `b_crm_act` SET `UNREAD`='Y' WHERE `ID`= " . $ID . ";");
				// AddMessage2Log("mark_as_unread<script>console.log(".json_encode($ID).");</script><br>", '', 0);
				break;
			case "delete":
				CCrmActivity::Delete($ID);
				// AddMessage2Log("delete<script>console.log(".json_encode($ID).");</script><br>", '', 0);
				break;
			// case "refilter":
			// 	CMailFilter::FilterMessage($ID, "M", $filter_id);
			// 	break;
		}
	}
}

$nav = new Bitrix\Main\UI\AdminPageNavigation('nav-mail-message');

// $messageList = Bitrix\Mail\MailMessageTable::getList(array(
// 	'select'      => array(
// 		'ID', 'MAILBOX_ID', 'MAILBOX_NAME' => 'MAILBOX.NAME', 'NEW_MESSAGE', 'SUBJECT', 'MESSAGE_SIZE', 'SPAM', 'SPAM_RATING', // required
// 		'FIELD_FROM', 'FIELD_REPLY_TO', 'FIELD_CC', 'FIELD_BCC', 'FIELD_DATE', 'DATE_INSERT', 'ATTACHMENTS', 'MSG_ID' // optional
// 	),
// 	'filter'      => array_filter($arFilter),
// 	'order'       => array(strtoupper($by) => $order),
// 	'offset'      => $nav->getOffset(),
// 	'limit'       => $nav->getLimit(),
// 	'count_total' => true,
// ));

function array_multisort_value()
{
	$args = func_get_args();
	$data = array_shift($args);
	foreach ($args as $n => $field) {
		if (is_string($field)) {
			$tmp = array();
			foreach ($data as $key => $row) {
				$tmp[$key] = $row[$field];
			}
			$args[$n] = $tmp;
		}
	}
	$args[] = &$data;
	call_user_func_array('array_multisort', $args);
	return array_pop($args);
}
$arFilterDB = array("RESPONSIBLE_ID" => $GLOBALS['USER']->GetID(), "PROVIDER_TYPE_ID" => "EMAIL");
$arSelect = array("ID", "SUBJECT", "CREATED", "SETTINGS", "STORAGE_ELEMENT_IDS", "DESCRIPTION");
$messageListDB = CCrmActivity::getList(array('ID' => 'asc'), $arFilterDB, false, false, $arSelect, ["UNREAD"] );
$mailList = array();
while ($arRes = $messageListDB->GetNext()) {
    $unread = $DB->Query("SELECT UNREAD FROM b_crm_act WHERE ID = " . $arRes['ID'], false,"ERROR")->Fetch();
    $attachments = explode(':', $arRes["STORAGE_ELEMENT_IDS"]);
    $mailFields = array(        
        'ATTACHMENTS' => $attachments[1],
        'FIELD_DATE' => $arRes["CREATED"],
        'FIELD_FROM' => $arRes["SETTINGS"]["EMAIL_META"]["from"],
        'ID' => $arRes["ID"],
        'MAILBOX_NAME' => $arRes["SETTINGS"]["EMAIL_META"]["to"],
        'NEW_MESSAGE' => $unread["UNREAD"],
        'SUBJECT' => $arRes["SUBJECT"],
        'BODY' => $arRes["~DESCRIPTION"]
    );
    $mailList[] = $mailFields;
}
foreach($arFilter as $index => $value) {
	if (!empty($value)) $mailList = array_filter($mailList, function ($mail) use ($index, $value) {
		$pos = strpos(strtolower($mail[$index]), strtolower($value));
		return ($pos !== false);
	});
}
$sortParameter = ($order == 'asc') ? SORT_ASC : SORT_DESC;
$mailList = array_multisort_value($mailList, strtoupper($by), $sortParameter);
$messageList = new CDBResult;
$messageList->InitFromArray($mailList);

// $permissions = CCrmPerms::IsAccessEnabled();
// $permissions = CCrmRole::GetRolePerms(4);
// $permissions = CCrmRole::GetUserPerms($GLOBALS['USER']->GetID());
// echo '<script type="text/javascript">console.log('.json_encode($permissions).');</script>';
// $tableName = \CCrmActivity::TABLE_NAME;
// echo '<script type="text/javascript">console.log('.json_encode($tableName).');</script>';

$listOffset = $nav->getOffset();
$listCount = $nav->getLimit();
$listNumber = ($listOffset/$listCount) + 1;
$messageList->NavStart($listCount, true, $listNumber);
$nav->setRecordCount($messageList->SelectedRowsCount());
// AddMessage2Log("\$getOffset3<script>console.log(".json_encode($getOffset1).");</script><br>", '', 0);
// AddMessage2Log("\$getLimit3<script>console.log(".json_encode($getLimit1).");</script><br>", '', 0);

$lAdmin->setNavigation($nav, Bitrix\Main\Localization\Loc::getMessage("MAIL_MSG_ADM_NAVIGATION"));

$arHeaders = Array();
$arHeaders[] = Array("id"=>"ID", "content"=>"ID", "sort" => "id");
$arHeaders[] = Array("id"=>"SUBJECT", "content"=>GetMessage("MAIL_MSG_ADM_SUBJECT"), "default"=>true, "sort" => "subject");
$arHeaders[] = Array("id"=>"FIELD_FROM", "content"=>GetMessage("MAIL_MSG_ADM_FROM"), "default"=>true, "sort" => "field_from");
$arHeaders[] = Array("id"=>"FIELD_DATE", "content"=>GetMessage("MAIL_MSG_ADM_DATE"), "default"=>true, "sort" => "field_date");
$arHeaders[] = Array("id"=>"MAILBOX_NAME", "content"=>GetMessage("MAIL_MSG_ADM_MBOX"), "default"=>true, "sort" => "mailbox_name");
$arHeaders[] = Array("id"=>"ATTACHMENTS", "content"=>GetMessage("MAIL_MSG_ADM_SPAM_ATTCH"), "default"=>true, "sort" => "attachments");
$arHeaders[] = Array("id"=>"MESSAGE_SIZE", "content"=>GetMessage("MAIL_MSG_ADM_SIZE"), "sort" => "message_size", "align" => "right");
$arHeaders[] = Array("id"=>"FIELD_REPLY_TO", "content"=>GetMessage("MAIL_MSG_ADM_REPLY_TO"), "sort" => "field_reply_to");
$arHeaders[] = Array("id"=>"FIELD_CC", "content"=>GetMessage("MAIL_MSG_ADM_CC"), "sort" => "field_cc");
$arHeaders[] = Array("id"=>"FIELD_BCC", "content"=>GetMessage("MAIL_MSG_ADM_BCC"), "sort" => "field_bcc");
$arHeaders[] = Array("id"=>"DATE_INSERT", "content"=>GetMessage("MAIL_MSG_ADM_RECEIVED"), "sort" => "date_insert");
$arHeaders[] = Array("id"=>"MSG_ID", "content"=>"Message-ID");

$lAdmin->AddHeaders($arHeaders);

while($arRes = $messageList->fetch())
{
	$arrMails[] = $arRes;
	$row =& $lAdmin->AddRow($arRes['ID'], $arRes);

	$str = "";

	if($arRes['NEW_MESSAGE']!="Y"):
		$str .= '<div class="mail-message adm-list-mail-icon" title="'.GetMessage("MAIL_MSG_ADM_READ").'"></div>';
	else:
		$str .= '<div class="mail-message-unread adm-list-mail-icon" title="'.GetMessage("MAIL_MSG_ADM_NOTREAD").'"></div>';
	endif;
	
	$str .= '<a onclick="window.openLetterNow(' . $arRes['ID'] . ')">';
	$str .= (strlen($arRes['SUBJECT']) > 0) ? $arRes['SUBJECT'] : GetMessage("MAIL_MSG_ADM_NOSUBJ");
	$str .= '</a>';

	$row->AddViewField("SUBJECT", $str);

	$arActions = Array();

	$arActions[] = array(
			"DEFAULT" => "Y",
			"TEXT" => GetMessage("MAIL_MSG_ADM_VIEW"),
			"ACTION" => 'window.openLetterNow(' . $arRes['ID'] . ');'
		);

	if ($MOD_RIGHT=="W")
	{
		$arActions[] = Array("SEPARATOR" => true);

		$arActions[] = array(
				"TEXT" => "Переслать письмо",
				"ACTION" => 'window.sendLetterAgain(' . $arRes['ID'] . ');'
			);		

		if ($arRes['NEW_MESSAGE'] == "Y")
		{
			$arActions[] = array(
				"TEXT"=>GetMessage("MAIL_MSG_ADM_PROC_ACT_READ"),
				"ACTION"=>$lAdmin->ActionAjaxReload($APPLICATION->GetCurPage()."?nav-mail-message=".$_GET["nav-mail-message"]."&action=mark_as_read&ID=".$arRes['ID']."&lang=ru&".bitrix_sessid_get())
			);
			// AddMessage2Log("\$arActions<script>console.log(".json_encode($arActions).");</script><br>", '', 0);
		}
		else
		{
			$arActions[] = array(
				"TEXT"=>GetMessage("MAIL_MSG_ADM_PROC_ACT_NOTREAD"),
				"ACTION"=>$lAdmin->ActionAjaxReload($APPLICATION->GetCurPage()."?nav-mail-message=".$_GET["nav-mail-message"]."&action=mark_as_unread&ID=".$arRes['ID']."&lang=ru&".bitrix_sessid_get())
			);
		}

		$arActions[] = Array("SEPARATOR" => true);

		$arActions[] = array(
				"ICON" => "delete",
				"TEXT"=>GetMessage("MAIL_MSG_ADM_PROC_ACT_DELETE"),
				"ACTION"=>"if(confirm('".GetMessage('MAIL_MSG_ADM_FILTER_CONFIRM10')."')) ".$lAdmin->ActionAjaxReload($APPLICATION->GetCurPage()."?nav-mail-message=".$_GET["nav-mail-message"]."&action=delete&ID=".$arRes['ID']."&lang=ru&".bitrix_sessid_get())
			);
	}

	$row->AddActions($arActions);
}
// echo '<script type="text/javascript">console.log('.json_encode($arrMails).');</script>';

$arActions = Array();
$arActions["mark_as_read"] = GetMessage("MAIL_MSG_ADM_PROC_ACT_READ");
$arActions["mark_as_unread"] = GetMessage("MAIL_MSG_ADM_PROC_ACT_NOTREAD");
$arActions["delete"] = GetMessage("MAIL_MSG_ADM_PROC_ACT_DELETE");
// $arActions["refilter"] = GetMessage("MAIL_MSG_ADM_PROC_ACT_RULES");

// $res = CMailFilter::GetList(Array("NAME"=>"ASC"), Array("ACTIVE"=>"Y", "WHEN_MANUALLY_RUN"=>"Y"));
// while($flt_arr = $res->Fetch())
// 	$arActions["refilter_num_".$flt_arr["ID"]] = GetMessage("MAIL_MSG_ADM_PROC_ACT_RULE")." ".htmlspecialcharsbx(substr($flt_arr["NAME"], 0, 30));

if ($MOD_RIGHT=="W") $lAdmin->AddGroupActionTable($arActions);

$lAdmin->CheckListMode();

define("START_EXEC_PROLOG_AFTER_1", microtime());
$GLOBALS["BX_STATE"] = "PA";

if(!defined("BX_ROOT"))
	define("BX_ROOT", "/bitrix");

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");

if (!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1)
{
	if (!defined('BX_AUTH_FORM') || !BX_AUTH_FORM)
		require_once($_SERVER["DOCUMENT_ROOT"]."/mail/prolog_main_admin.php");
		// require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_main_admin_custom.php");
	else
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_auth_admin.php");
}
else
	require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_jspopup_admin.php");

define("START_EXEC_PROLOG_AFTER_2", microtime());
$GLOBALS["BX_STATE"] = "WA";

?>

<form name="form1" method="GET" action="<?echo $APPLICATION->GetCurPage()?>?">
<?$filter->Begin();?>
<tr>
	<td nowrap><?echo GetMessage("MAIL_MSG_ADM_FILTER_SUBJECT")?>:</td>
	<td nowrap><input type="text" name="find_subject" value="<?echo htmlspecialcharsbx($find_subject)?>" size="47"><?=ShowFilterLogicHelp()?></td>
</tr>
<tr>
	<td nowrap><?echo GetMessage("MAIL_MSG_ADM_DATE")?>:</td>
	<td nowrap><input type="text" name="find_date" value="<?echo htmlspecialcharsbx($find_date)?>" size="47"><?=ShowFilterLogicHelp()?></td>
</tr>
<tr>
	<td nowrap><?echo GetMessage("MAIL_MSG_ADM_FILTER_FROM")?>:</td>
	<td nowrap><input type="text" name="find_from" value="<?echo htmlspecialcharsbx($find_from)?>" size="47"><?=ShowFilterLogicHelp()?></td>
</tr>
<tr>
	<td nowrap><?echo GetMessage("MAIL_MSG_ADM_FILTER_TO")?>:</td>
	<td nowrap><input type="text" name="find_to" value="<?echo htmlspecialcharsbx($find_to)?>" size="47"><?=ShowFilterLogicHelp()?></td>
</tr>
<tr>
	<td nowrap><?echo GetMessage("MAIL_MSG_ADM_FILTER_TEXT")?>:</td>
	<td nowrap><input type="text" name="find_body" value="<?echo htmlspecialcharsbx($find_body)?>" size="47"><?=ShowFilterLogicHelp()?></td>
</tr>
<?$filter->Buttons(array("table_id"=>$sTableID, "url"=>$APPLICATION->GetCurPage(), "form"=>"form1"));$filter->End();?>
</form>

<?
$lAdmin->DisplayList();
// $lAdmin->Display();
?>

<script>
var pathToOpen = "<?=str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);?>/just_open.php";
var pathToSlider = "<?=str_replace($_SERVER['DOCUMENT_ROOT'], "", __DIR__);?>/slider.php";
var sessid = "<?=bitrix_sessid_get()?>";

function letterWasOpened(mailId) {
    $.post(pathToOpen, { METHOD: '@UPDATE', MAIL_ID: mailId }, function (data) {
		// console.log(data);
		if (data.mailId == mailId) {			
			t_message_admin.GetAdminList(window.location.href);
		}
    }, "json");
}
	
$(document).ready(function() {
		
	//open mail in frame

	function animationOpenIframe() {
		$('#overlay').fadeIn(20,
            function() {
                $('#mail-frame')
                    .css({'display' : 'block', 'padding-left':'10px', 'background-color':'#eef2f4'})
                    .animate({opacity: 1, right: '0'}, 110);
            });
	}
	
	window.sendLetterAgain = function(forward) {
		$('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='" + pathToSlider + "?site_id=s1&ajax_action=ACTIVITY_EDIT&TYPE_ID=4&FROM_ACTIVITY_ID=" + forward + "&MESSAGE_TYPE=FWD&IFRAME=Y&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        animationOpenIframe();
	}
    window.openLetterNow = function(mailId) {
		letterWasOpened(mailId);
        $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='" + pathToSlider + "?site_id=s1&sessid=" + sessid + "&ajax_action=ACTIVITY_VIEW&activity_id=" + mailId + "&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        animationOpenIframe();
    }
    $('div.add-new-mail').click(function(e) {
        e.preventDefault();
        $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='" + pathToSlider + "?site_id=s1&sessid=" + sessid + "&ajax_action=ACTIVITY_EDIT&activity_id=0&TYPE_ID=4&OWNER_ID=0&OWNER_TYPE=&OWNER_PSID=0&FROM_ACTIVITY_ID=0&MESSAGE_TYPE=&__post_data_hash=0&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        animationOpenIframe();
    });

    //close frame

    $('#mail-frame-close, #overlay').click(function() {
        $('#overlay').css('display', 'none');
        $('#mail-frame').animate(
			{opacity: 0.9, right: '-100%'}, 
			130,
            function() {
				$('#mail-frame').remove();
            }
        );
	});
	
    $(this).keydown(function(event) {
        // console.log(event.which);
        if (event.which == 27) {
            $('#overlay').click();
        }
	});

});
</script>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
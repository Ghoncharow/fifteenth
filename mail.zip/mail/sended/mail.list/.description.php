<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arComponentDescription = [
    "NAME" => GetMessage("COMPONENT_NAME"),
    "DESCRIPTION" => GetMessage("COMPONENT_DESCRIPTION"),
    "PATH" => array(
        "ID" => "custom_components",
        "CHILD" => array(
            "ID" => "MailList",
            "NAME" => GetMessage("MAIL_LIST"),
        )
    ),
];
<?
$MESS["FULL_NAME"] = "ФИО";
$MESS["WORK_POSITION"] = "Должность";
$MESS["WORK_PHONE"] = "Рабочий телефон";
$MESS["INNER_PHONE"] = "Внутренний телефон";
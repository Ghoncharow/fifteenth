$(document).ready(function () {

    //$("#mail-list").tablesorter();

    //open mail in frame

    $('div.open-mail, div.add-new-mail, .menu-popup-item.forward').click(function (event) {
        event.preventDefault();
        if (this.className == 'open-mail') {
            $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='/bitrix/components/bitrix/crm.activity.planner/slider.php?site_id=s1&sessid=" + sessid + "&ajax_action=ACTIVITY_VIEW&activity_id=" + this.id + "&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        } else if (this.className == "add-new-mail") {
            $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='/bitrix/components/bitrix/crm.activity.planner/slider.php?site_id=s1&sessid=" + sessid + "&ajax_action=ACTIVITY_EDIT&activity_id=0&TYPE_ID=4&OWNER_ID=0&OWNER_TYPE=&OWNER_PSID=0&FROM_ACTIVITY_ID=0&MESSAGE_TYPE=&__post_data_hash=0&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        } else if ($('#' + this.id).hasClass("forward")){
            $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='/bitrix/components/bitrix/crm.activity.planner/slider.php?site_id=s1&ajax_action=ACTIVITY_EDIT&TYPE_ID=4&FROM_ACTIVITY_ID=" + (this.id).replace("forward-mail_", "") + "&MESSAGE_TYPE=FWD&IFRAME=Y&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        }
        $('#overlay').fadeIn(20,
            function () {
                $('#mail-frame')
                    .css({'display' : 'block', 'padding-left':'10px', 'background-color':'#eef2f4'})
                    .animate({opacity: 1, right: '0'}, 110);
            });
    });

    //close frame

    $('#mail-frame-close, #overlay').click(function () {
        $('#mail-frame')
            .animate({opacity: 0, right: '-100%'}, 100,
                function () {
                    $(this).css('display', 'none');
                    $('#overlay').fadeOut(100);
                }
            );
        $(this).css('display', 'none');//bagfix
        $('#mail-frame').remove();
    });
    $(this).keydown(function(event){
        // console.log(event.which);
        if (event.which == 27) {
            $('#mail-frame')
                .animate({opacity: 0, right: '-100%'}, 100,
                    function () {
                        $(this).css('display', 'none');
                        $('#overlay').fadeOut(100);
                    }
                );
            $('#mail-frame-close, #overlay').css('display', 'none');
            $('#mail-frame').remove();
        }
    });

    //functions for checkboxes

    //check-all

    var checkAll = $('#check-all');
    var hasChecked = function () {
        var arCheckboxes = $("input.mail-select:checked");
        if (arCheckboxes.length > 0) {
            var unread = false;
            arCheckboxes.each(function (key, value) {
                if (value.checked) {
                    id = value.id.replace('checkbox_', "");
                    if ($('#mail_' + id).hasClass('unread')) {
                        unread = true;
                    }
                    swichReadButton(unread);
                }
            });
            return true;
        } else return false;
    };

    //checkboxes

    checkAll.change(function () {
        var switcher = !!$(this).prop('checked');
        $.each($('.mail-select'), function (index, value) {
            value.checked = switcher;
        });
        checkActive();
    });

    $('.mail-select').change(function () {
        if (checkAll.prop("checked") && this.checked === false) {
            checkAll.prop('checked', false);
        }
        checkActive();
    });

    // for switching read button

    function checkActive() {
        if (hasChecked()) {
            $("#delete").removeClass('deactivated');
            $("#read").removeClass('deactivated');
            $("#unread").removeClass('deactivated');
        } else {
            $("#delete").addClass('deactivated');
            $("#read").addClass('deactivated');
            $("#unread").addClass('deactivated');
        }
    }

    function swichReadButton(read) {
        if (read) {
            $('#unread').addClass("hide");
            $('#read').removeClass("hide");
        } else {
            $('#unread').removeClass("hide");
            $('#read').addClass("hide");
        }
    }

    // Delete, read, unread mails
        //functions
    function ajaxQuery(action, cheсkedMailsID) {
        $.post(pathToAjax, {action: action, 'mailsID[]': cheсkedMailsID}, function (data) {
            if (data) {
                switch (action) {
                    case "delete mails":
                        deleteMails(cheсkedMailsID);
                        break;
                    case  "read mails":
                        markMails(true, cheсkedMailsID);
                        break;
                    case "unread mails":
                        markMails(false, cheсkedMailsID);
                        break;
                    default:
                        console.log("Error");
                }
            }
        }, "json");
    }

    function getCheckedMails() {
        var checkedMailsID = [];

        $.each($('.mail-select'), function (index, value) {
            if (value.checked) {
                checkedMailsID.push(value.id.replace('checkbox_', ""));
            }
        });
        return checkedMailsID;

    }

    function deleteMails(arID) {
        $.each(arID, function (index, value) {
            $("#mail_" + value).remove();
        });
    }

    function markMails(read, arID) {
        $.each(arID, function (index, id) {
            if (read) {
                $('#mail_' + id).removeClass("unread");
            } else {
                $('#mail_' + id).addClass("unread");
            }
            $('#checkbox_' + id).attr("checked", false);
            checkAll.prop('checked', false);
        });
    }

        //on user actions

    $('.delete').click(function () {
        console.log([(this.id).replace("delete-mail_", "")]);
        if(wantToDelete()) {
            ajaxQuery("delete mails", [(this.id).replace("delete-mail_", "")]);
        }
            $(popupID).css("z-index", "-1");
            popupID = "";
    })

    $('#delete').click(function () {
        if (!hasChecked()) return false;
        if(wantToDelete()) {
            ajaxQuery("delete mails", getCheckedMails());
        }
    });

    $('#read').click(function () {
        if (!hasChecked()) return false;
        ajaxQuery("read mails", getCheckedMails());
    });

    $('#unread').click(function () {
        if (!hasChecked()) return false;
        ajaxQuery("unread mails", getCheckedMails());

    })

    // Popup action menu

    var popupID = "";

    $(document).mouseup(function (e) {
        if (popupID != "") {
            var div = $(popupID);
            if (!div.is(e.target) && div.has(e.target).length === 0) {
                div.css("z-index", "-1");
                popupID = "";
            }
        }
    })

    $('.main-grid-row-action-button').click(function (event) {
        event.preventDefault();
        popupID = (this.id).replace('action-button_', "#popup-action-menu_");
        $(popupID).css("z-index", "1");
        console.log($(popupID));
    });

});
$(document).ready(function () {

    $("#mail-list").tablesorter();

    //open mail in frame

    $('div.open-mail, div.add-new-mail').click(function (event) {
        event.preventDefault();
        if (this.className == 'open-mail') {
            $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='/bitrix/components/bitrix/crm.activity.planner/slider.php?site_id=s1&sessid=" + sessid +"&ajax_action=ACTIVITY_VIEW&activity_id=" + this.id + "&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        }
        else {
            $('#mail-frame-container').append("<iframe id='mail-frame' name='mail-frame' class='mail-frame' src='/bitrix/components/bitrix/crm.activity.planner/slider.php?site_id=s1&sessid=" + sessid + "&ajax_action=ACTIVITY_EDIT&activity_id=0&TYPE_ID=4&OWNER_ID=0&OWNER_TYPE=&OWNER_PSID=0&FROM_ACTIVITY_ID=0&MESSAGE_TYPE=&__post_data_hash=0&IFRAME=Y&IFRAME_TYPE=SIDE_SLIDER' frameborder='0'></iframe>");
        }
        $('#overlay').fadeIn(200,
            function () {
                $('#mail-frame')
                    .css('display', 'block')
                    .animate({opacity: 1, right: '0'}, 300);
            });
    });

    //close frame

    $('#mail-frame-close, #overlay').click(function () {
        $('#mail-frame')
            .animate({opacity: 0, right: '-100%'}, 100,
                function () {
                    $(this).css('display', 'none');
                    $('#overlay').fadeOut(100);
                }
            );
        $(this).css('display', 'none');//bagfix
        $('#mail-frame').remove();
    });

    //functions for checkboxes
        //check-all

    var checkAll = $('#check-all');

    checkAll.change(function () {
        var switcher = !!$(this).prop('checked');
        $.each($('.mail-select'), function (index, value) {
            value.checked = switcher;
        });
    });

    $('.mail-select').change(function () {
        if(checkAll.prop("checked") && this.checked === false) {
            checkAll.prop('checked', false);
        }
    })

    // Delete, read, unread mails
        //functions
    function ajaxQuery(action, cheсkedMailsID) {
        $.post(pathToAjax, {action: action, 'mailsID[]': cheсkedMailsID}, function (data) {
            console.log(action);
            if (action == "delete mails") {
                if (data) {
                    $.each(checkedMailsID, function (index, value) {
                        $("#mail_" + value).remove();
                    });
                } else {
                    console.log("Error");
                    location.reload();
                }
            } else if (action == "read mails") {
                markMails(true, cheсkedMailsID);
                console.log("ok read");
            } else if (action == "unread mails") {
                markMails(false, cheсkedMailsID);
                console.log("ok unread");
            } else {
                console.log("Error");
            }
        }, "json");
    }

    function getCheckedMails(checkReadOrNot) {
        var checkedMailsID = [];
        if (checkReadOrNot === true) {
            var unread = false;
            $.each($('.mail-select'), function (index, value) {
            var id = 0;
                if (value.checked) {
                    id = value.id.replace('checkbox_', "");
                    if ($('#mail_' + id).hasClass('unread')) {
                        unread = true;
                    }
                    checkedMailsID.push(id);
                }
            });
            checkedMailsID.push(unread);
            return checkedMailsID;
        } else {
            $.each($('.mail-select'), function (index, value) {
                if (value.checked) {
                    checkedMailsID.push(value.name.replace('#checkbox_', ""));
                }
            });
            return checkedMailsID;
        }
    }

    function markMails(read, arID) {
        $.each(arID, function (index, id) {
            $('#mail_' + id).toggleClass("unread");
            $('#checkbox_' + id).attr("checked", false);
            checkAll.prop('checked', false);
        });
    }

        //on user actions

    $('#delete').click(function () {
        ajaxQuery("delete mails", getCheckedMails(false));
    });

    $('#read').click(function () {
        checkedMailsID = getCheckedMails(true);
        console.log(checkedMailsID);
        var read = checkedMailsID.pop();
        ajaxQuery((read === true ? "read mails" : "unread mails"), checkedMailsID);
    });
});
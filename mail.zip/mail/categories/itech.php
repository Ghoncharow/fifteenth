<?php
if ($_GET["grid_id"] != "tbl_user") {
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
$APPLICATION->SetPageProperty("description", "Банк резюме - категории");
$APPLICATION->SetTitle("Информационные технологии");
?>
<style>
    #hr_department_post {
        width: 270px;
    	font-size: 15px;
        height: 39px;
        margin: 15px 15px 15px 20px;
        padding: 2px;
        border: 1px solid #d5dde0;
        border-radius: 2px;
    }
	#button-all-categories {
		position: relative;
		display: inline-block;
		vertical-align: top;
		height: 39px;
		padding: 0 19px;
		margin: 15px;
		border-radius: 2px;
		text-align: center;
		background-color: #3bc8f5;
		color: #fff;
		text-transform: uppercase;
		font: 600 12px/39px "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
		cursor: pointer;
		transition: 160ms color linear, 160ms background-color linear, 160ms opacity linear, 160ms padding linear;
	}
	#button-all-categories:hover {
		background-color: rgba(59, 210, 255, 0.9);
	}
</style>
<select id="hr_department_post">
    <option value="0">Выберите категорию соискателей:</option>
    <option value="1">- Исполнение бюджета и казначейское сопровождение;</option>
    <option value="2">- Бухгалтерский учет и отчетность;</option>
    <option value="3">- Контроль, аудит, бюджетный мониторинг;</option>
    <option value="4">- Юриспруденция;</option>
    <option value="5">- Контрактная система;</option>
    <option value="6">- Информационные технологии;</option>
    <option value="7">- Обеспечение деятельности.</option>                        
</select>
<div onclick="redirectToAllCategories()" id="button-all-categories">Все категории</div>
<script>
	function redirectToAllCategories() {
		document.location.href = "/mail/categories/everything.php";
	}
    $(document).ready(function () {
        var hrDepartment = $("#hr_department_post");
        hrDepartment.change(function () {
            switch (hrDepartment.val()) {
            case '1':
                document.location.href = "/mail/categories/";
                break;
            case '2':
                document.location.href = "/mail/categories/accountant.php";
                break;
            case '3':
                document.location.href = "/mail/categories/audit.php";
                break;
            case '4':
                document.location.href = "/mail/categories/jurisprudence.php";
                break;
            case '5':
                document.location.href = "/mail/categories/contracts.php";
                break;
            case '6':
                // document.location.href = "/mail/categories/itech.php";
                break;
            case '7':
                document.location.href = "/mail/categories/provision.php";
                break;
        	default:
                console.log(hrDepartment);
            }
        });
    });
</script>
<?
}
$GLOBALS["HR_SELECTING_STATUS"] = array(2);
$GLOBALS["HR_FILTRATION"] = array("UF_HR_CATEGORY" => "68", 
        "UF_HR_STATUS" => ["59", "61"], 
        ">TIMESTAMP_X" => date('d.m.Y', (time() - (60*60*24*184)))
    );
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_admin.php");
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');


<?php

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mail/prolog.php");
CJSCore::Init(array('jquery2'));
?>
<style>
tr.adm-footer-wrap, #main_navchain, 
#tabControl_tabs .adm-detail-pin-btn-tabs {
	display: none;
}
.adm-main-wrap > tbody > tr:first-child {
	height: 15px;
}
</style>
<?
$MOD_RIGHT = $APPLICATION->GetGroupRight("mail");
if($MOD_RIGHT<"R") $APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));
IncludeModuleLangFile(__FILE__);
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mail/include.php");
$err_mess = "File: ".__FILE__."<br>Line: ";

ClearVars("str_");

$ID = IntVal($ID);


if($ID<=0 && $_REQUEST["MSG_ID"]!='')
	$dbr = CMailMessage::GetList(array(), array("MSG_ID"=>$_REQUEST["MSG_ID"]));
else
	$dbr = CMailMessage::GetByID($ID);

if($dbr_arr = $dbr->ExtractFields("str_")):
	// AddMessage2Log("\$dbr_arr<script>console.log(".json_encode($dbr_arr).");</script><br>", '', 0);

	$dbr_arr["SPAM_RATING"] = CMailMessage::GetSpamRating($ID, $dbr_arr);
	if($dbr_arr["NEW_MESSAGE"]=="Y")
		CMailMessage::Update($ID, Array("NEW_MESSAGE"=>"N"));

	if($_REQUEST['show']=='original' && COption::GetOptionString("mail", "save_src", B_MAIL_SAVE_SRC)=="Y")
	{
		echo "<pre>".nl2br(htmlspecialcharsbx($dbr_arr["FULL_TEXT"]))."</pre>";
		die();
	}

	$APPLICATION->SetTitle(GetMessage("MAIL_MSG_VIEW_TITLE"));

	define("START_EXEC_PROLOG_AFTER_1", microtime());
	$GLOBALS["BX_STATE"] = "PA";
	
	if(!defined("BX_ROOT"))
		define("BX_ROOT", "/bitrix");
	
	require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");
	
	if (!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1)
	{
		if (!defined('BX_AUTH_FORM') || !BX_AUTH_FORM)
			require_once($_SERVER["DOCUMENT_ROOT"]."/mail/prolog_main_admin.php");
			// require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_main_admin_custom.php");
		else
			require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_auth_admin.php");
	}
	else
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_jspopup_admin.php");
	
	define("START_EXEC_PROLOG_AFTER_2", microtime());
	$GLOBALS["BX_STATE"] = "WA";

	$aMenu = array(
		array(
			"ICON" => "btn_list",
			"TEXT"=>GetMessage("MAIL_MSG_VIEW_BACK_LINK"),
			"LINK"=>"/mail/"
		)
	);
	$aMenu[] = array("SEPARATOR"=>true);
	setcookie("PREVIOUS_PAGE_MAIL", $_SERVER['REQUEST_URI']);
	$aMenu[] = array(
		"ICON" => "",
		"TEXT" => "Зарегистрировать кандидата",
		"TITLE" => "Перейти к созданию карточки кандидата",
		"LINK" => "/mail/categories/user_edit.php?lang=".LANGUAGE_ID."&mailId=".$ID
	);

	$context = new CAdminContextMenu($aMenu);
	$context->Show();



	$aTabs = array(
		array("DIV" => "edit1", "TAB" => GetMessage("MAIL_MSG_MESSAGE"), "ICON"=>"main_user_edit", "TITLE"=>GetMessage("MAIL_MSG_VIEW_TITLE")),
	);
	$tabControl = new CAdminTabControl("tabControl", $aTabs);


?>
<form method="POST" action="<?echo $APPLICATION->GetCurPage()?>">
<?=bitrix_sessid_post()?>
<input type="hidden" name="lang" value="<?echo LANG?>">
<input type="hidden" name="ID" value="<?echo $ID?>">
<a name="tb"></a>

<?$tabControl->Begin();?>
<?$tabControl->BeginNextTab();?>

	<tr>
		<td width="25%"><?echo GetMessage("MAIL_MSG_VIEW_DATE")?></td>
		<td width="75%"><?=$str_FIELD_DATE?></td>
	</tr>
	<?if(strlen($dbr_arr["FIELD_FROM"])>0):?>
	<tr>
		<td><?echo GetMessage("MAIL_MSG_VIEW_FROM")?></td>
		<td><?=TxtToHTML($dbr_arr["FIELD_FROM"])?></td>
	</tr>
	<?endif?>
	<?if(strlen($dbr_arr["FIELD_TO"])>0):?>
	<tr>
		<td><?echo GetMessage("MAIL_MSG_VIEW_TO")?></td>
		<td><?=TxtToHTML($dbr_arr["FIELD_TO"])?></td>
	</tr>
	<?endif?>
	<?if(strlen($dbr_arr["FIELD_CC"])>0):?>
	<tr>
		<td><?echo GetMessage("MAIL_MSG_VIEW_CC")?></td>
		<td><?=TxtToHTML($dbr_arr["FIELD_CC"])?></td>
	</tr>
	<?endif?>
	<?if(strlen($dbr_arr["FIELD_BCC"])>0):?>
	<tr>
		<td><?echo GetMessage("MAIL_MSG_VIEW_BCC")?></td>
		<td><?=TxtToHTML($dbr_arr["FIELD_BCC"])?></td>
	</tr>
	<?endif?>
	<tr>
		<td>Тема сообщения:</td>
		<td><?=TxtToHTML($dbr_arr["SUBJECT"])?></td>
	</tr>
	<?
	function _ConvReplies($str1, $str2)
	{
		$str2 = str_replace('\"', '"', $str2);
		if(substr_count($str1, "&gt;")%2 == 1)
			$clr = "#770000";
		else
			$clr = "#CC9933";
		return '<font color="'.$clr.'">'.$str1.$str2.'';
	}
	?>
	<tr>
		<td>Текст сообщения:</td>
		<td colspan="2" style="background:white; padding: 15px;"><?=preg_replace_callback("'(^|\r\n)[\s]*([A-Za-z]*(&gt;)+)([^\r\n]+)'", create_function('$m', "return _ConvReplies(\$m[2], \$m[4]);"), TxtToHTML($dbr_arr["BODY"]))?></td>
	</tr>
	<?
	if($dbr_arr["ATTACHMENTS"]>0):

		$dbr_attach = CMailAttachment::GetList(Array("NAME"=>"ASC", "ID"=>"ASC"), Array("MESSAGE_ID"=>$dbr_arr["ID"]));
	?>
	<tr>
		<td><?echo GetMessage("MAIL_MSG_VIEW_ATTACHMENTS")?></td>
		<td>
		<?while($dbr_attach_arr = $dbr_attach->GetNext()):?>
			<a target="_blank" href="/bitrix/admin/mail_attachment_view.php?lang=<?=LANG?>&amp;ID=<?=$dbr_attach_arr["ID"]?>">
			<?=(strlen($dbr_attach_arr["FILE_NAME"])>0?$dbr_attach_arr["FILE_NAME"]:GetMessage("MAIL_MSG_VIEW_NNM"))?>
			</a> (<? echo CFile::FormatSize($dbr_attach_arr["FILE_SIZE"]); ?>)<br>
		<?endwhile?>
		</td>
	</tr>
	<?endif?>
	<tr>
		<td><?echo GetMessage("MAIL_MSG_VIEW_STATUS")?></td>
		<td>			
			<?if($dbr_arr["NEW_MESSAGE"]!="Y"):?>
				<div class="mail-message" title="<?echo GetMessage("MAIL_MSG_VIEW_READ")?>"></div> &nbsp; <?echo GetMessage("MAIL_MSG_VIEW_READ")?>
			<?else:?>
				<div class="mail-message-unread" title="<?echo GetMessage("MAIL_MSG_VIEW_NOTREAD_STATUS")?>"></div> &nbsp; <?echo GetMessage("MAIL_MSG_VIEW_NOTREAD_STATUS")?>
			<?endif?>			
		</td>
	</tr>

<?if(false):?>
<?$tabControl->Buttons();?>

<input type="hidden" name="save_form" value="Y">

<input <?if ($MOD_RIGHT<"W") echo "disabled" ?> type="submit" name="save"  class="adm-btn-save" value="<?echo GetMessage("MAIL_MSG_VIEW_SAVE")?>">
&nbsp;<input <?if ($MOD_RIGHT<"W") echo "disabled" ?> type="submit" name="apply" value="<?echo GetMessage("MAIL_MSG_VIEW_APPLY")?>">
&nbsp;<input <?if ($MOD_RIGHT<"W") echo "disabled" ?> type="submit" name="prev" value="&lt;&lt;" title="<?echo GetMessage("MAIL_MSG_VIEW_SAVE_PREV")?>">
&nbsp;<input <?if ($MOD_RIGHT<"W") echo "disabled" ?> type="submit" name="next" value="&gt;&gt;" title="<?echo GetMessage("MAIL_MSG_VIEW_SAVE_NEXT")?>">
<?endif?>
<?$tabControl->End();?>
</form>
<?
else:
	$APPLICATION->SetTitle(GetMessage("MAIL_MSG_VIEW_TITLE"));

	define("START_EXEC_PROLOG_AFTER_1", microtime());
	$GLOBALS["BX_STATE"] = "PA";
	
	if(!defined("BX_ROOT"))
		define("BX_ROOT", "/bitrix");
	
	require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/init_admin.php");
	
	if (!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1)
	{
		if (!defined('BX_AUTH_FORM') || !BX_AUTH_FORM)
			require_once($_SERVER["DOCUMENT_ROOT"]."/mail/prolog_main_admin.php");
			// require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_main_admin_custom.php");
		else
			require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_auth_admin.php");
	}
	else
		require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/interface/prolog_jspopup_admin.php");
	
	define("START_EXEC_PROLOG_AFTER_2", microtime());
	$GLOBALS["BX_STATE"] = "WA";
	
	CAdminMessage::ShowMessage(GetMessage("MAIL_MSG_NOTFOUND"));
endif;
?>
<script>
$(document).ready(function() {
	$('#btn_list').click(function(e) {
		e.preventDefault();
		// location.reload();
		if(parent.jQuery) parent.$(parent.document).find('#overlay').click();
		// console.log(e);
	});
});
</script>
<?require($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/include/epilog_admin.php");?>

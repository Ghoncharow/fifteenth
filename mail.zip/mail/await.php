<?php
if ($_GET["grid_id"] != "tbl_user") {
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
$APPLICATION->SetPageProperty("description", "Банк резюме");
$APPLICATION->SetTitle("Рассматриваемые к трудоустройству кандидаты");

$userStatusDb = CUser::GetList(($by = "NAME"), ($order = "desc"), 
        array("UF_HR_STATUS" => "60", "<UF_HR_ALLOTMENT" => date('d.m.Y', (time() - (60*60*24*30)))), 
        array("SELECT" => array("UF_HR_STATUS", "UF_HR_ALLOTMENT"))
    );
$userProperties = new CUser;
while ($userStatus = $userStatusDb->Fetch()) {
    $userProperties->Update($userStatus["ID"], array("UF_HR_STATUS" => "61"));
}

// $userProperties = new CUser;
// $fields01 = array(
//     "TIMESTAMP_X" => date('d.m.Y H:i:s'),
//     "DATE_REGISTER" => date('d.m.Y H:i:s', (time() - (60*60*24*30))),
//     "LAST_ACTIVITY_DATE" => date('d.m.Y H:i:s'),
//     "UF_HR_ALLOTMENT" => date('d.m.Y H:i:s', (time() - (60*60*24*2))),
//     "UF_HR_STATUS" => "60"
// ); 
// $userProperties->Update('5630', $fields01);
// $userProperties->Update('5631', $fields01);

?>
<style>
.adm-toolbar-panel-container {
    margin: -4px 0 18px 0 !important;
}
</style>
<?
}
// echo date('d.m.Y', (time() - (60*60*24*184)));
// echo date('d.m.Y', (time() - (60*60*24*30)));
// echo date('d.m.Y H:i:s');
$GLOBALS["HR_SELECTING_STATUS"] = array(3, 4);
$GLOBALS["HR_FILTRATION"] = array("UF_HR_STATUS" => "60");
require_once($_SERVER["DOCUMENT_ROOT"]."/mail/user_admin.php");
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
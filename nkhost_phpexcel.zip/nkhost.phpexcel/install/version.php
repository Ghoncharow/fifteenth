<?
$arModuleVersion = array(
	"VERSION" => "2.1.4",
	"VERSION_DATE" => "2017-12-13 00:00:00"
);
?>
